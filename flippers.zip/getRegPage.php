<?php
//include_once "../header.php";
//include_once "./includes/session.php";
 session_start();
 include_once "./includes/config.class.php";
include_once "./includes/Handler.class.php";






/*$obj = new RealMeet;
$obj->getLocation();
*/
//print_r($obj->countries);
//echo $obj::startReg();
if(isset($_POST["nextPage"])){

if($_POST["nextPage"] == "dataValidation"){
$err = [];
$age = $_SESSION["age"];
$userName = $_SESSION["userName"];
$email = $_SESSION["email"];
$tmp_id = $_SESSION["tmp_id"];
$lookingFor = $_SESSION["lookingFor"];
$gender = $_SESSION["gender"];
$country = $_SESSION["country"];
$state= $_SESSION["state"];
$pwd = $_SESSION["pwd"];
$fullName = $_SESSION["fullName"];


if(!$obj->checkAge($age)){
    array_push($err, "User must be <b>18</b> or older");
}else{
 $age = $obj->checkAge($age);
}

if(!$obj->userExist($userName)){
    array_push($err, "User must be <b>18</b> or older");
}else{
  $userName = $obj->userExist($userName);
}

if(!$obj->pwd($pwd)){
    array_push($err, "User must be <b>18</b> or older");
}else{
  $pwd = $obj->pwd($pwd);
}

if(!$obj->email($email)){
    array_push($err, "User must be <b>18</b> or older");
}else{
  $email = $obj->email($email);
}

if(!$obj->fullName($fullName)){
    array_push($err, "User must be <b>18</b> or older");
}else{
  $fullName = $obj->fullName($fullName);
}



if(count($err) < 1){
   if($obj->con->query("insert into biodata (fullName,age,gender,country,state,lookingFor,email,pwd,userName) 
   values ('".$fullName."','".$age."','".$gender."','".$country."','".$state."','".$lookingFor."','".$email."','".$pwd."','".$userName."')")){
    if(file_exists("./regPageList/success.php")){
    $data = ["status"=>file_get_contents("../regPageList/success.php")];
    echo json_encode($data);
    //print_r($_SESSION);
      session_destroy();  
    }
    }else{
    if(file_exists("./regPageList/fail.php")){
    $data = ["status"=>file_get_contents("../regPageList/fail.php")];
    echo json_encode($data);
    //print_r($_SESSION);
      session_destroy();  
    }
    }
}else{
    if(file_exists("./regPageList/fail.php")){
    $data = ["status"=>file_get_contents("../regPageList/fail.php")];
    echo json_encode($data);
    //print_r($_SESSION);
      session_destroy();  
    }
    }
}

if($_POST["nextPage"] == "nextPage"){
$formName = $_POST["formName"];
$formValue = $_POST["formValue"];
$nextForm = "./regPageList/".$_POST["address"];
$_SESSION[$formName] = $formValue;
if(file_exists($nextForm)){
//echo("exist");
$data = ["nextPage"=>file_get_contents($nextForm)];
}else{
//echo("not exist");
$data = ["data"=>false];
}
echo json_encode($data);
}
}





if(isset($_POST["loadCountry"])){
$obj->loadCountriesAndStates(); //Default === Nigeria
echo(json_encode($obj->countries)); //count($obj->loadCountries());
}

if(isset($_POST["loadState"])){
$obj->loadCountriesAndStates($_SESSION["country"]);
echo(json_encode($obj->states)); //count($obj->loadCountries());
}


?>