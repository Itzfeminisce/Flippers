<?php


class Core {

private $path;

public function __construct(){
  //$this->path = $path;
}


public function getPath($dir){
return '../p/'.$dir;
}


public function getFile($file){
$fullPath = $this->getPath().'/'.$file.'.php';
if(file_exists($fullPath)){
return file_get_contents($fullPath);
}
return $this->setFile();
}



}


