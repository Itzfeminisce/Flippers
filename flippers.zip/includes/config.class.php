<?php declare(strict_types=1);


class Config {
	
	private $db ="realmeet";
	private $dbPwd = "";
	private $dbName = "root";
	private $host = "localhost";
	
	public $con;
	
	public $siteName;
	public $siteAddress;
	
	
	
	
	public function __construct(){
		$sql = new mysqli($this->host, $this->dbName, $this->dbPwd);
		$sql->select_db($this->db);
		$sql->set_charset("utf8mb4");
		if(mysqli_connect_errno()){
		 $this->logger($sql->connect_err(), $sql->connect_errno());
		}else{
		//echo "Connection established";
		$this->con = $sql;
		$this->siteName = "Flippers";
		
		$this->siteAddress = $_SERVER["HTTP_HOST"];
		
		}
	}	
		
	protected function logger($err, $errCode) {	
		$file = "logger.txt";
		$msg = date("Ymd/h:i:sa")."<errMsg>".$err."--------".$errCode."--------";
		file_put_contents($file, $msg, FILE_APPEND);
		echo "Error";
		/*if($create_file)
			return $err;	
		else
			return "";*/
	}
		
}



?>