<?php

session_start();


echo (!isset($_SESSION["id"])) ? header("location: ../signin?q=Logged out") : false;



?>