<?php
//Lets prefetch Users data into User Class
//We need configuration class
//Hence, extend configuration class
/*
namespace User;

use \Root;
*/
require './config.class.php';

class User extends Config {


 
public function __construct()
{
parent::__construct();
}

public static function setup($uid)
{
$user = new User(); 
$user->data = $user->fetchData($uid);
return $user;
}

public function fetchData($uid)
{
$q = 'SELECT * FROM biodata WHERE uid = '.$uid;
$query = $this->con->query($q);
$result = $query->fetch_object();
return $result;
}

public function followers()
{
$q = 'SELECT * FROM followers WHERE uid = '.$this->data->uid;
$q = $this->con->query($q);
if($q->num_rows > 0)
{
while($rows = $q->fetch_object()){ return $rows; }
$this->hasFollowers = true;
}
}

public function following()
{
$q = 'SELECT * FROM following WHERE uid = '.$this->user->uid;
$q = $this->con->query($q);
if($q->num_rows > 0)
{
while($rows = $q->fetch_object()){ return $rows; }
$this->hasFollowing = true;
}
}


}


$user = new User;
$user::setup(6);
print_r($user->data);