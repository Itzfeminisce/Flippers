<?php declare(strict_types=1);
 
 include_once "config.class.php";
 
 class RealMeet extends Config {
 
 	 public $id;
 	 public $countries = [];
 	 public $states = [];
 	 //public $location;	
 	 public $confg;
 	 public $data;
 	 public $url = "../location/getLocation.json";
 	 public $profilePicDir = "../uploads/profile/";
 	 public $feedsDir = "../uploads/feeds/";
 	  
 	public function __construct(int $id = null){
 	parent::__construct();
 	if($id !== null):
 		$this->id = $id;
 		$query = $this->con->query("SELECT * FROM biodata WHERE uid=".$id);
 		$this->data = $query->fetch_object();
 	endif;		
 	}
 	
 	
 public function getLocation(){
 $data = (file_exists($this->url)) ? file_get_contents($this->url) : null; 
 $data = ($data == null )? die("Some file missing"):json_decode($data);
 return $data;
 }
 	
 public	function loadCountriesAndStates($country = "Nigeria"){
 	 $loc = $this->getLocation();
 	 foreach($loc->countries as $obj){
 	  array_push($this->countries, $obj->country);	 
 	 // print_r("<br>".$obj->country);
 	 if($obj->country == $country){
 	  // print_r($obj->states);
 	   array_push($this->states, $obj->states);
 	   //break;
 	 }
 	 }
 	}
     
     
     public function loadCountries(){
     return $this->countries;
     }
     
     
     public function loadStates(){
     return $this->states;
     }
     
     
     
     
 	//*******GET USER IP ADDRESS******
 	 // Function to get the client IP address
 	public function getRealUserIp() {
 	$ipaddress = '';
 	if (isset($_SERVER['HTTP_CLIENT_IP']))
 	$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
 	else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
 	$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
 	else if(isset($_SERVER['HTTP_X_FORWARDED']))
 	$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
 	else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
 	$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
 	else if(isset($_SERVER['HTTP_FORWARDED']))
 	$ipaddress = $_SERVER['HTTP_FORWARDED'];
 	else if(isset($_SERVER['REMOTE_ADDR']))
 	$ipaddress = $_SERVER['REMOTE_ADDR'];
 	else
 	$ipaddress = 'UNKNOWN';
 	return $ipaddress;
 	}
 //	$ip = getRealUserIp();
 		
 	
 	public static function startReg(){
 	 $ip = hash_hmac("sha1",self::getRealUserIp(), "");
 	// self::save([]);
 	return $ip;
 	}
 	
 	
 	
   	public function load(){
   		return $this->data;
   }
   	

	public function uploadFiles($file, $where="feeds"){
		if(isset($file)){
		$array = [];
		if(count($file["name"]) > 0){
		for($i = 0; $i < count($file["name"]); $i++){
		$ext = strtolower(end(explode(".",$file["name"][$i])));
		
		$ext = (in_array($ext,["mp4","mpeg","mkv","3gp"]))?"VID":"IMG";
		
	//	array_push($array,$ext);
		array_push($array, 	"RM_".$ext."_".date("ymdhis").substr(md5(uniqid()), 10).".".strtolower(end(explode(".", $file["name"][$i]))));
		//$fileNewName = "RM_".date("ymdhis").substr(md5(uniqid()), 10).".".strtolower(end(explode(".", $file["name"][$i])));
		move_uploaded_file($file["tmp_name"][$i], "../uploads/".$where."/".$array[$i]);
		}
		return $array;
		}	
	}else{
	return [null,null];
	}
}
	
	
	
	public function uploadFile($file, $where="profile",$desc=""){
	if(isset($file)){
	$fileNewName = "RM_".$desc."_".date("ymdhis").substr(md5(uniqid()), 10).".".strtolower(end(explode(".", $file["name"])));
	move_uploaded_file($file["tmp_name"], "../uploads/".$where."/".$fileNewName);
	}
	return $fileNewName;
	}
	
	
	
	public function save(array $arg){
	  list($formName, $formValue, $and) = $arg;
	  $sql = $this->con->query("INSERT INTO biodata (".$formName.") VALUES('".$formValue."') ".$and);
	  if($sql){
	  return $sql;
	  }else{
	  return false;
	  }
	}

  public function select(array $arg){
    list($field, $tbl, $key, $val, $and) = $arg;
    if($sql = $this->con->query("SELECT ".$field." FROM ".$tbl." WHERE ".$key."='".$val."' ".$and)){
    return $sql;
    }else{
    return $sql->error;
    }
  }
  
  
 public function checkAge($val){
    if($val <= 17)
       return false;
    else
       return $this->cleanInput($val);
 }
 
 public function userExist($val){
    if($this->con->query("select userName from biodata where userName='".$val."'")->num_rows > 0){
      return false;
    }else{
    return $this->cleanInput($val);;
    }
 }
 
public function pwd($val){
  if(strlen($val) < 5){
     return false;
  }else{
    $pwd = hash_hmac("sha512", $this->cleanInput($val), "");
    return $pwd;
  }
}

public function email($val){
  if(filter_var($val, FILTER_VALIDATE_EMAIL) === false){
     return false;
  }elseif($this->con->query("select email from biodata where email='".$val."'")->num_rows > 0){
    return false;
  }else{
    return $this->cleanInput($val);
  }
}


public function fullName($val){
  return $this->cleanInput($val);
}


public function cleanInput($var){
$var = trim($var);
$var = $this->con->real_escape_string($var);
$var = htmlspecialchars($var);
$var = stripslashes($var);
return $var;
}

}
 

class Maintenance extends RealMeet{
public $data;
public function __construct($id = 0){
parent::__construct(intval($id));
}

public function search($field, $id,$params=""){
if(isset($id)){
$result = $this->con->query("select * from biodata where uid=".$id." ".$params);
if($result->num_rows > 0){
return $result->fetch_object()->$field;
}else{
return "Null:[".$id."]";
//Not found.
}
}
}


public function checkIfFollowing($uid){
if($this->con->query("select * from activity where sid=".$_SESSION["id"]." and uid=".$uid)->num_rows > 0){
return ["bgStyle"=>"background:rgb(255,0,255);color:white;", "innerText"=>"following"];
}else{
return ["bgStyle"=>"", "innerText"=>"follow"];
}
}


public function getActions($sid, $uid="uid", $what="sid", $action="following"){
$sql = $this->con->query("select ".$uid." from activity where ".$what."=".$sid." and action='".$action."'");
return $sql->num_rows;
}



/*
This method $this->isUserPage() is no longer in use.
*/
public function isUserPage($ivid = 0, $post = 0, $follower=0,$following=0){
$data = $this->data;
if(isset($ivid) && $ivid !== $data->uid){
echo '<div class="poke" onclick="pageUrl = $(this); $.realMeet.loadContent(this); return false;"><br><br><br><p>'.$post.'<p style="padding:2px 0 5px 0;font-weight:400;">Posts</p><span>
<button onclick="$.load.loadChat({card:$(this)}); return false;" data-uid="'.$ivid.'" data-sid="'.$_SESSION["id"].'" data-name="'.$this->search("fullName",$ivid).'" data-pic="'.$this->search("profilePic",$ivid).'" value="2" name="poke" id="actionButton">Message</button></span></p></div>';
echo '<div class="followers" onclick="pageUrl = $(this); return $.realMeet.loadContent(this);"  data-href="../views?'.$this->search("fullName",$ivid).'=request&p=follower&token='.md5($ivid).'&key='.$ivid.'"><br><br><br><p data-page="profile">'.$this->getActions($ivid, "sid", "uid").'<p style="padding:2px 0 5px 0;font-weight:400;">Followers</p><span>
<button id="actionButton" style="'.$this->checkIfFollowing($ivid)["bgStyle"].'" data-name="followuser" data-pid="" data-who="'.$ivid.'" data-href="../views/followers" name="follow">'.$this->checkIfFollowing($ivid)["innerText"].'</button></span></p></div>';
echo '<div class="following" onclick="pageUrl = $(this); return $.realMeet.loadContent(this);" data-href="../views?'.$this->search("fullName",$ivid).'=request&p=following&token='.md5($ivid).'&key='.$ivid.'"><br><br><br><p>'.$following.'<p style="padding:2px 0 5px 0;font-weight:400;">Following</p><span>
<button value="2" name="poke" id="actionButton">Poke</button></span></p></div>';
}else{
echo '<div onclick="pageUrl = $(this); $.realMeet.loadContent(this); return false;" data-href="../views?post='.$_SESSION["id"].'" class="uploads" ><p id="postCount">'.$post.'<span>Posts</span></p></div>';
echo '<div onclick="pageUrl = $(this); return $.realMeet.loadContent(this);" data-href="../views?'.$this->search("fullName",$ivid).'=request&p=follower&token='.md5($ivid).'&key='.$ivid.'" class="followers" ><p id="postFollowers">'.$follower.'<span>Followers</span></p></div>';
echo '<div onclick="pageUrl = $(this); return $.realMeet.loadContent();" data-href="../views?'.$this->search("fullName",$ivid).'=request&p=following&token='.md5($ivid).'&key='.$ivid.'" class="following" ><p id="postFollowing">'.$following.'<span>Following</span></p></div>';
}
}


public function sendAction($pid, $action="liked"){
if($this->con->query("select doerID from likes where doerID=".$_SESSION["id"]." and pid=".$pid)->num_rows > 0){
//..User already liked post
}else{
$sql = $this->con->query("insert into likes (pid,action,doerID) values (".$pid.", '".$action."',".$_SESSION["id"].")");
if($sql){
$count = $this->con->query("select * from likes where pid=".$pid);
$data = [];
if($count->num_rows > 0){
while($rows = $count->fetch_object()){
array_push($data, $rows);
}
return $data;
}else{
return "0";
}
}
}
}



public function setActivity($uid, $action, $pid=0, $parent_id=0){
$this->sid = $_SESSION["id"];
$this->uid = $uid;
$this->action = $action;
$this->pid = $pid;

switch($this->action){
case 'following': 
if($this->con->query("select * from activity where uid=".$this->uid." and sid=".$this->sid." and action='".$this->action."' LIMIT 1")->num_rows > 0){
//already following
return false;
}else{
$this->con->query("INSERT INTO activity (sid, uid, action, pid) 
				VALUES (".$this->sid.",".$this->uid.", '".$this->action."',".$this->pid.")");
$this->con->query("INSERT INTO following (sid, uid) VALUES (".$this->sid.",".$this->uid.")");
return true;
}


break;

case 'unfollow': 
if($this->con->query("SELECT * FROM activity WHERE uid=".$this->uid." AND sid=".$this->sid." AND action='following' LIMIT 1")->num_rows > 0){

$this->con->query("DELETE FROM activity WHERE uid=".$this->uid." AND sid=".$this->sid." AND action='following'");
$this->con->query("DELETE FROM following WHERE sid=".$this->sid." AND uid=".$this->uid);
return true;
}else{
return false;
}

break;


case "liked": 
if($this->con->query("select * from activity where uid=".$this->uid." and sid=".$this->sid." and action='".$this->action."' and pid=".$this->pid." limit 1")->num_rows > 0){

return false;
}else{
$this->con->query("INSERT INTO activity (sid, uid, action, pid) 
				VALUES (".$this->sid.",".$this->uid.", '".$this->action."',".$this->pid.")");
$this->con->query("INSERT INTO likes (sid, uid, pid) 
				VALUES (".$this->sid.",".$this->uid.", ".$this->pid.")");

return true;
}
break;

case "comment": 

$q = $this->con->query("insert into activity (sid, uid, action, pid) 
				values (".$this->sid.",".$this->uid.", '".$this->action."',".$this->pid.")");
return true;

break;

case "replied": 
$this->parent_id = $parent_id;
$q = $this->con->query("insert into activity (sid, uid, action, pid, parent_id) 
				values (".$this->sid.",".$this->uid.", '".$this->action."',".$this->pid.",".$this->parent_id.")");
return true;

break;
case "shared": 
$this->parent_id = $parent_id;
$q = $this->con->query("insert into activity (sid, uid, action, pid, parent_id) 
				values (".$this->sid.",".$this->uid.", '".$this->action."',".$this->pid.",".$this->parent_id.")");

$this->con->query("insert into retweet (sid, uid, pid) 
				values (".$this->sid.",".$this->uid.",".$this->pid.")");

return true;
break;
case "mentioned": 
$this->parent_id = $parent_id;
$q = $this->con->query("insert into activity (sid, uid, action, pid, parent_id) 
				values (".$this->sid.",".$this->uid.", '".$this->action."',".$this->pid.",".$this->parent_id.")");
return "\n\n".$this->action." ".$this->pid." ".$this->uid;

break;

case "remove":
if($this->con->query("SELECT * FROM activity WHERE sid=".$this->uid." AND uid=".$this->sid." AND action='following' LIMIT 1")->num_rows > 0){
$this->con->query("DELETE FROM activity WHERE sid=".$this->uid." AND uid=".$this->sid." AND action='following'");
$this->con->query("DELETE FROM following WHERE sid=".$this->uid." AND uid=".$this->sid);
return true;
}else{
return false;
}
break;
}
}

public function isRead($pid, $action){
$isRead = "1";
if(
$this->con->query("update activity set read='".$isRead."' where action='".$action."' and pid=".$pid)
){
return true;
}else{
return false;
}
}




function isFollowing($me,$you){
$q = "SELECT tid FROM following WHERE sid=".$me." AND uid = ".$you." LIMIT 1";
$q = $this->con->query($q);
if($q->num_rows > 0){
 return true;
 }else{
 return false;
}
}

function follow($who){
$pid = rand();
$q = "INSERT INTO follower (sid, fid) VALUES (".$this->id.",".$who.")";
if($this->con->query($q)
&& $this->setActivity($who, "following", $pid)
){
return true;
}else{
return false;
}
}



function createFileTag($fileName, $content= "Hello world "){
$fileExt = "../hash/".$fileName.".php";
if(file_exists($fileExt)){
file_put_contents($fileExt,$content."\n", FILE_APPEND);
//file_get_contents($fileExt);
}else{
file_put_contents($fileExt,$content);
//file_get_contents($fileExt);
}

return $fileName;
}

/* Deprecated */
function searchTag($comment, $needle = "#"){
$c = explode(" ", $comment);
$return = [];
for($i = 0 ; $i < count($c); ++$i){
preg_match("/$needle(\w+)/", $c[$i], $matches);
if($matches[1] !== null):
foreach(explode(" ",$matches[1]) as $key => $match){
array_push($return,$this->createFileTag($match));
//echo substr($matches[0], 0,1);
return $return;
}
endif;
}

}
}


class Privacy extends RealMeet {
// 0 => public
// 1 => private
private static $setup;
private static $instance = null;
public $profileVisibility = 0;
public $privacy;


public static function getInstance($id){
if(!isset(self::$instance)){
self::$instance = new self($id);
}
return self::$instance;
}

public function __construct($id = null){
parent::__construct(intval($id));
}

public function setup(){
$this->setVisibility('public');
return $this->getVisibility();
}


public function fetchPrivacy(){
$privacy = $this->con->query('SELECT * FROM privacy WHERE uid = '.$this->data->uid);
return $privacy;
}

public function userIsPresent(){
return  ($this->fetchPrivacy()->num_rows > 0)?true:false;
}


public function getVisibility(){
if($this->userIsPresent()){
$isVisible = $this->fetchPrivacy()->fetch_object()->profileVisibility;
return ($isVisible > 0)? 'public':'private';
}
}

/*public function visibleTo($p,$callback){
$this->callback = $callback;
if(!$this->isFollowing($p, $this->data->uid)){
$this->callback();
}
}*/

public function setVisibility($visibilityType){
// 1 => visible
// 0 => hidden
$this->visibilityType = $visibilityType;
if($this->userIsPresent()){
$this->con->query('UPDATE privacy SET profileVisibility = '.$this->visibilityType.' WHERE uid = '.$this->data->uid);
}else{
$this->con->query('INSERT INTO privacy (uid,profileVisibility) VALUES ('.$this->data->uid.','.$this->visibilityType.')');
}
}

}

 ?>