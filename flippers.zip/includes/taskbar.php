


<div class="taskbar" >
<button class="active" data-href="./home" ><i class="fa fa-users" ></i></button>
<button class="" data-href="./explore" ><i class="fa fa-search" ></i></button>
<button class="" data-href="./create" ><i class="fa fa-plus" ></i></button>
<button class="" data-href="./chats" ><i class="fa fa-envelope" ></i></button>
<button class="" data-href="./p/<?php echo $_SESSION['userName']; ?>" ><i class="fa fa-user" ></i></button>
</div>

<script src="../script/jquery.js"></script>
<script src="https://rawgit.com/mervick/emojionearea/master/dist/emojionearea.js"></script>
<script src="../script/Handler.Java.js"></script>

