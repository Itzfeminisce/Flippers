
<p class="animated slideInLeft faster suggestion">Choose a username?</p>
<input name="userName" type="text" class="animated slideInRight faster" placeholder="Enter username" required="required" autocomplete="off" >


<script type="text/javascript">

var userName = $("input[name='userName']");

var p = $(".suggestion");
var pTxt = p.html();

userName.on("keyup", function(){
var uName = $(this).val();

if(uName == "")
p.html(pTxt);

else

$.ajax({
url: "../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
data:{userNameExist:uName},
success: function(data){
p.html(data.output)
},
fail:function(xhr, textStatus){
alert(textStatus);
}
});
});


function chooseSuggestedUserName(val){
var suggested = val.textContent;
var inputElement = val.parentElement.nextElementSibling;
inputElement.value = suggested;
}
</script>