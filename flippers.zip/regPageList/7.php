
<p class="animated slideInLeft faster">How do you want us to contact you?</p>
<input name="email" type="email" class="animated slideInRight faster" placeholder="Enter your valid email" required="required" autocomplete="off" >


