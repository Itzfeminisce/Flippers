
<p class="animated slideInLeft faster">Please tell us your full name? <font style="font-size:8px;border-bottom:1px solid white;" >FFirst name Last name, Other names</font></p>
<input name="fullName" type="text" class="animated slideInRight faster" placeholder="Enter full name" required="required" autocomplete="off" >