
<p class="animated slideInLeft faster">Which country are you from? </p>
<select name="country" class="animated slideInRight faster" >
<option value="" >Select location</option>
</select>



<script type="text/javascript">

$(function(e){

var ageCont = $("select[name='country']");
$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
data:{loadCountry:true},
success:function(data){
//alert(typeof data);
//alert(data.length);
//alert(data[0]);
for(var i = 0; i<data.length; i++){
ageCont.append("<option value='"+data[i]+"'>"+data[i]+"</option>");
}
},
fail:function(xhr, textStatus){
//alert(xhr.textStatus);
}
});

});

</script>