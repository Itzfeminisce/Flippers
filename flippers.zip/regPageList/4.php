
<p class="animated slideInLeft faster">Which state are you from?</p>
<select name="state" class="animated slideInRight faster" >
<option value="" >Select state</option>
</select>


<script type="text/javascript">
$(function(e){
var ageCont = $("select[name='state']");
$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
data:{loadState:true},
success:function(data){
//alert(data);
for(var i = 0; i<data[0].length; i++){
ageCont.append("<option value='"+data[0][i]+"'>"+data[0][i]+"</option>");
}
},
fail:function(xhr, textStatus){
alert(textStatus);
}
});
});
</script>