<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="utf-8" />
<title>Flippers•Registration successful!</title>
<!--<meta name="theme-color" content="rgb(255, 0, 255)" >-->
<meta name="viewport" content="width:device-width, initial-scale=1.0, user-scalable=no" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="../animate/animate.css" rel="stylesheet" />
<link href="../styles/fa/css/all.css" rel="stylesheet" />
<link href="../styles/index-files.inc.css" rel="stylesheet" />
<link href="../styles/login.min.css" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css?family=Quicksand|Open+Sans&display=swap" rel="stylesheet">
</head>
<body class="body" >
<!--<img class="bg-image" src="../img/pp7.jpeg"  >-->
<div class="bg-container" >
<div class="bg-console" >
<h1 class="animated slideInRight" >Flippers</h1>
<div class="bg-login-box" >
<fieldset class="animated bounceIn" >
<!--<legend>Signup, Chat and Meet</legend>-->
<form>
<!--<h1 class="animated slideInDown faster">Let's know you better?</h1>-->
<!--<input name="uname" type="text" id="uname" placeholder="Email/username"  >-->
<div class="nextFormContainer" >

<div style="border:1px solid red;" class="x animated bounceInRight" >
<i style="color:red;"  class="fa fa-exclamation-triangle animated pulse fast" ></i>
</div>

<div class="y animated bounceInLeft faster" >
<p style="color:red;text-align:center;" class="animated slideInLeft faster">Failed!</p>
</div>


<div class="y z animated pulse" >
<div class="f" >
<p class="animated slideInLeft faster">
Your registration failed. Some of the reasons you're seeing this page
are:
<p>Email already exist.</p>
<p>Username not available</p>
<p>Your network connection was disconnected</p>
<p>You already have an account with us</p>
</p>
</div>
</div>



</div>
<!--<input name="pwd" type="password" id="pwd" placeholder="Password"  >-->
<!--<button class="animated slideInUp faster" name="proceed" >Proceed</button>-->
</form>
<p class="creat-account" ><a href="../register.php" rel="index follow" >Try again</a> <span><a href="/" >Report an issue?</a></span></p>
</fieldset>
<br>
<div style="display:none;" class="bg-more animated bounceInUp" >
<h1>Kindly read the <a href="tnq" >terms and condition</a> guiding the use of
this site.
You are to note that this website does not allow
person under the age of 18.
</h1>
</div>
</div>
</div>


</div>




<script src="../script/jquery.js"></script>
<script src="../script/Handler.Java.js"></script>
</body>

</html>