



<p class="animated slideInLeft faster">Who do you want to meet? </p>
<select name="lookingFor" class="animated slideInRight faster" >
<option value="male" >Male</option>
<option value="female" >Female</option>
<option value="both" >Both</option>
</select>


