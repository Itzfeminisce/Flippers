<p class="animated slideInLeft faster">
Welcome! Your data is now being reviewed. Click button below to proceed.
</p>
<select name="proceed" style="border:none;"  disabled="disabled" class="animated slideInRight faster" >
<option value="proceed" >Click 'Proceed'</option>
</select>
<script type="text/javascript">
