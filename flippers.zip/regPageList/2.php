<p class="animated slideInLeft faster">How old are you?</p>
<select name="age" class="animated slideInRight faster" >
<option value="25" >25</option>
</select>
<script type="text/javascript">
var ageCont = $("select[name='age']");

for(var i = 19; i<120; i++){
ageCont.append("<option value='"+i+"'>"+i+"</option>");
}

</script>