<?php
//include_once "../header.php";
 include_once "../includes/config.class.php";
include_once "../includes/Handler.class.php";

//include_once "../includes/session.php";

session_start();


$obj = new RealMeet;
$Main = new Maintenance;
$privacy = Privacy::getInstance($Main->data->uid);
$obj->getLocation();

//print_r($obj->countries);
//echo $obj::startReg();


if(isset($_POST["userNameExist"])){
$userName = $obj->cleanInput($_POST["userNameExist"]);
$sql = $obj->con->query("select userName from biodata where userName='".$userName."'");
if($sql->num_rows > 0){
$sug = (isset($_SESSION["fullName"]))?explode(" ",$_SESSION["fullName"]):null;
if($sug !== null){
$sug = implode("_", $sug).rand(100, 10000);
}else{
$sug = $userName.rand(100, 99999);
}
$data = ["output"=>"<span onclick='chooseSuggestedUserName(this)' class='animated slideInLeft faster' style='border:1px solid white;padding:5px;border-radius:5px;font-size:10px;color:white;'>".$sug."</span>"];
echo(json_encode($data));
}else{
$data = ["output"=>"<span class='animated slideInLeft faster' style='font-size:10px;color:green;'>Available <i class='fa fa-check'></i></span>"];
echo(json_encode($data));
}
}


if(isset($_POST["loadCountry"])){
$obj->loadCountriesAndStates(); //Default === Nigeria
echo(json_encode($obj->countries)); //count($obj->loadCountries());
}

if(isset($_POST["loadState"])){
$obj->loadCountriesAndStates($_SESSION["country"]);
echo(json_encode($obj->states)); //count($obj->loadCountries());
}



if(isset($_POST["createFeeds"])){
//$fileNames = [];
$fileName = (count($_FILES["post_files"]) < 1) ? [] : $obj->uploadFiles($_FILES["post_files"]);
//print_r($fileName);
$uid = $_SESSION["id"];
$pid = rand();
$tmp_pic = (count($fileName) < 1) ? "" : $fileName[0];

$text = $_POST["content"];
if(count(explode(' ',$text)) > 250){
$data['status'] = false;
$data['msg'] = 'Maximum word length exceeded. Please adjust and try again.';
echo json_encode($data);
exit();
}
//$text = $obj->cleanInput($text);
$text = strip_tags($text);
$text = $obj->con->real_escape_string($text);
$text = wordwrap($text, 500, "<br />\n");

//$tagName = implode(",",$Main->searchTag($text));


$text = preg_replace('/@(\\w+)/','<a class="hashTag" href="../hash/$1.php">$0</a>',$text);

$text = preg_replace('/#(\\w+)/','<a class="hashTag" href="../hash/$1.php">$0</a>',$text);

$comment = $text;

$comment = preg_replace('/`(\\w+)/','<font style="font-family:cursive;font-size:large;">$1</font>',$comment);

$comment = preg_replace('/del-(\\w+)/','<del>$1</del>',$comment);

$comment = preg_replace('/~(\\w+)/','<b>$1</b>',$comment);

$comment = preg_replace('/_(\\w+)/','<i>$1</i>',$comment);

$comment = preg_replace('/<script>(\\w+)/','<b>••</b>',$comment);

$comment = preg_replace('/<a>(\\w+)/','<a href="$1">$0</a>',$comment);

$text = $comment;

$text = nl2br($text);

if($obj->con->query("insert into feeds (uid,pid,text,tmp_pic)
 values (".$uid.",".$pid.",'".$text."','".$tmp_pic."')")){


//$dir = $obj->data->userName; // $obj->search('userName',$obj->data->uid);

//$fileName = sha1($dir);

//mkdir('/contents/'.$dir,0700);
/*if(mkdir('../p/'.$dir,0700,true)){
$file = '../p/'.$dir.'/'.$fileName.'.php';
file_put_contents($file,$text);
}*/




preg_match_all('/@(\\w+)/',$text,$match);
//print_r($match[1]);
if(count($match[1]) > 0){
foreach($match[1] as $tag){
$isMentioned = $obj->con->query('SELECT uid FROM biodata WHERE userName = "'.$tag.'"')->fetch_object()->uid;
if($isMentioned == $uid) continue; //$uid here is the session id
$Main->setActivity($isMentioned, "mentioned", $pid);
$obj->con->query("INSERT INTO tags (uid, tagName,pid) 
				VALUES (".$isMentioned.", '".$tag."',".$pid.")");
}
}
if(count($fileName) > 0){
for($i=0; $i<count($fileName); $i++){
$obj->con->query("insert into feeds_pics (uid,pid,pic) values (".$uid.",".$pid.",'".$fileName[$i]."')");
}

$obj->con->query("INSERT INTO tags (uid, pid, tagName) 
						VALUES (".$uid.",".$pid.",'".$tagName."')");

} 
 
$data = [
"status"=>true,
"msg"=>"Your post has been uploaded."
];
}else{
$data = [
"status"=>false,
"msg"=>"Your post could not be uploaded. Please re-try again."
];
}
echo json_encode($data);
}

if(isset($_POST["nextPage"])){

if($_POST["nextPage"] == "dataValidation"){
$err = [];
$age = $_SESSION["age"];
$userName = $_SESSION["userName"];
$email = $_SESSION["email"];
$tmp_id = $_SESSION["tmp_id"];
$lookingFor = $_SESSION["lookingFor"];
$gender = $_SESSION["gender"];
$country = $_SESSION["country"];
$state= $_SESSION["state"];
$pwd = $_SESSION["pwd"];
$fullName = $_SESSION["fullName"];
$uniqvar = substr(hash_hmac('sha512',$userName,$userName),0,7);

if(!$obj->checkAge($age)){
    array_push($err, "User must be <b>18</b> or older");
}else{
 $age = $obj->checkAge($age);
}

if(!$obj->userExist($userName)){
    array_push($err, "User must be <b>18</b> or older");
}else{
  $userName = $obj->userExist($userName);
}

if(!$obj->pwd($pwd)){
    array_push($err, "User must be <b>18</b> or older");
}else{
  $pwd = $obj->pwd($pwd);
}

if(!$obj->email($email)){
    array_push($err, "User must be <b>18</b> or older");
}else{
  $email = $obj->email($email);
}

if(!$obj->fullName($fullName)){
    array_push($err, "User must be <b>18</b> or older");
}else{
  $fullName = $obj->fullName($fullName);
}



if(count($err) < 1){
   if($obj->con->query("insert into biodata (uniqvar,fullName,age,gender,country,state,lookingFor,email,pwd,userName) 
   values ('".$uniqvar."','".$fullName."','".$age."','".$gender."','".$country."','".$state."','".$lookingFor."','".$email."','".$pwd."','".$userName."')")){
   $obj->con->query("INSERT INTO following (sid, uid) VALUES (0,".$obj->insert_id.")");
    if(file_exists("../regPageList/success.php")){
    
    /* create a profile link */
    $plink = '../profile.php';
    $newPlink = '../p/'.$userName.'.php';
    if(file_exists($plink)){
    if(file_exists('../p/'.$userName.'.php')){
       $userName = $userName.rand(1,1000);
       $newPlink = '../p/'.$userName.'.php';
    }
       $pfile = file_get_contents($plink);
       file_put_contents($newPlink, $pfile);
       $privacy::setup();
   }
    
    $data = ["status"=>file_get_contents("../regPageList/success.php")];
    echo json_encode($data);
    //print_r($_SESSION);
      session_destroy();  
    }
    }else{
    if(file_exists("../regPageList/fail.php")){
    $data = ["status"=>file_get_contents("../regPageList/fail.php")];
    echo json_encode($data);
    //print_r($_SESSION);
      session_destroy();  
    }
    }
}else{
    if(file_exists("../regPageList/fail.php")){
    $data = ["status"=>file_get_contents("../regPageList/fail.php")];
    echo json_encode($data);
    //print_r($_SESSION);
      session_destroy();  
    }
    }
}

if($_POST["nextPage"] == "nextPage"){
$formName = $_POST["formName"];
$formValue = $_POST["formValue"];
$nextForm = "../regPageList/".$_POST["address"];
$_SESSION[$formName] = $formValue;
if(file_exists($nextForm)){
//echo("exist");
$data = ["nextPage"=>file_get_contents($nextForm)];
}else{
//echo("not exist");
$data = ["data"=>false];
}
echo json_encode($data);
}
}




if(isset($_POST["accr"])){

$uname = $obj->cleanInput($_POST["uname"]);
$pwd = $obj->cleanInput($_POST["pwd"]);
$pwd = $obj->pwd($pwd);
$_SESSION = [];
$ip = $obj->getRealUserIp();
$sql = $obj->con->query("SELECT * FROM biodata WHERE (userName='".$uname."' OR email='".$uname."') AND pwd='".$pwd."' ");
if($sql->num_rows > 0){
$obj->con->query("UPDATE biodata SET online = '1' WHERE (userName='".$uname."' or email='".$uname."') LIMIT 1");
//session_start();
while($rows = $sql->fetch_object()){
array_push($_SESSION, $rows);
$_SESSION["id"] = $rows->uid;
}
$obj->con->query("INSERT INTO visitor (deviceName, deviceID, accountID)
				VALUES ('unknown','".$ip."',".$_SESSION["id"].")");

$obj->con->query("INSERT INTO activity (sid, uid, action, pid)
				VALUES (".$_SESSION['id'].",".$_SESSION['id'].",'accessed','".rand()."')");


$data = [
"status"=>true,
"msg"=>"Login successful"
];
}else{
$data = [
"status"=>false,
"msg"=>"Invalid login details."
];
}
echo json_encode($data);
}


if(isset($_POST["loadFeeds"])){
//$page = $_POST["feeds"];
//echo (file_exists("../".$page)) ? @file_get_contents("../".$page):null; //"Page ".$page." does not exists.";
$where = ($_POST["where"] === "public") ?"":" where feeds.uid=".$_POST["loadFeeds"];
$limit = $_POST['limit'] ?? '';
//$where = ($_POST["where"] === "management") ?"":" where feeds.uid=".$_POST["loadFeeds"];
$data = [];
//user can only see feeds from people they follow or people who follow them.
//$peopleIFollow = $obj->con->query('SELECT sid FROM following WHERE sid='.$_SESSION['id'].' OR uid = '.$_SESSION['id'])->fetch_object()->uid;
$sql = $obj->con->query("SELECT DISTINCT biodata.profilePic,
								biodata.fullName,
								biodata.uniqvar,
								biodata.userName,
								biodata.uid as myid,
								biodata.country,
								biodata.state,
								biodata.online,
								biodata.age,
								feeds.*,
							    DATE_FORMAT(feeds.date, '%a, %D %h:%i') as date
			
							   FROM biodata 
							   JOIN feeds
							    ON biodata.uid=feeds.uid ".$where."


							   ORDER BY feeds.date DESC");
if($sql->num_rows > 0){
while($rows = $sql->fetch_object()){
$rows->no_of_comments = $obj->con->query("SELECT comment_text FROM comments WHERE pid=".$rows->pid)->num_rows;
$rows->no_of_shared = $obj->con->query("SELECT sid FROM retweet WHERE pid=".$rows->pid)->num_rows;
$feedPic_ = $obj->con->query("SELECT pic FROM feeds_pics WHERE pid=".$rows->pid);
while($p = $feedPic_->fetch_object()){
$rows->feedPic[] = $p->pic;
}
$uiPic = $obj->con->query("SELECT profilePic FROM biodata WHERE uid=".$_SESSION["id"])->fetch_object();
$isPostLiked = $obj->con->query("SELECT action FROM activity WHERE pid=".$rows->pid." AND sid=".$_SESSION["id"]);
$isFollowingUser = $obj->con->query("SELECT action FROM activity WHERE uid=".$rows->uid." AND sid=".$_SESSION["id"]." AND action='following' LIMIT 1" );
$noOfPostLikes = $Main->getActions($rows->pid, "uid", "pid", "liked");
if($isPostLiked->num_rows > 0) {
$rows->isPostLiked = ($isPostLiked->fetch_object()->action == "liked")?"1":"0";
}
if($isFollowingUser->num_rows > 0) {
$rows->isFollow = ($isFollowingUser->fetch_object()->action == "following")?"1":"0";
}
$rows->sessPic = $uiPic->profilePic;
$rows->postLikes = $noOfPostLikes;

if($rows->type == 'shared'){
$rtwt = 'SELECT feeds.uid AS rtwt_uid,feeds.pid AS rtwt_pid,
feeds.text AS rtwt_text, feeds.tmp_pic AS rtwt_tmp_pic,
feeds.type AS rtwt_type, feeds.type_id AS rtwt_type_id,
DATE_FORMAT(feeds.date, "%a, %D %h:%i") AS rtwt_time,
biodata.fullName AS rtwt_fullName,
biodata.userName AS rtwt_username, biodata.profilePic AS rtwt_profilePic
FROM feeds JOIN biodata 
ON feeds.uid = biodata.uid 
WHERE feeds.pid = '.$rows->type_id;
$rtwt = $obj->con->query($rtwt);
$rows->rtwt = $rtwt->fetch_object();

$rtwt_pic = $obj->con->query("SELECT pic FROM feeds_pics WHERE pid=".$rows->type_id);
while($r = $rtwt_pic->fetch_object()){
$rows->rtwt_pic[] = $r->pic;
}
}

$c = $obj->con->query("SELECT biodata.profilePic, biodata.userName, comments.* 
FROM comments 
JOIN biodata 
ON comments.sid = biodata.uid 
WHERE pid=".$rows->pid." ".$limit);
if($c->num_rows > 0){
while($i = $c->fetch_object()){
$rows->fComments[] = $i;
}
}
array_push($data, $rows);
//array_push($data, $noOfPostLikes);
}
}
echo json_encode($data);
}




if(isset($_POST["loadAlbum"])){
$pic = [];
$sql = $obj->con->query("select * from feeds_pics where uid=".$_POST["loadAlbum"]." order by id desc");
if($sql->num_rows > 0){
while($rows = $sql->fetch_object()){
array_push($pic, $rows);
}
}else{
array_push($pic);
}
echo json_encode($pic);
}


if(isset($_POST["loadProfile"])){
$uid = $_POST["loadProfile"];
$data = [];

$sql = $obj->con->query("select *, DATE_FORMAT(regDate, '%M %D, %Y') AS regDate from biodata where uid=".$uid);
if($sql->num_rows > 0){
while($rows = $sql->fetch_object()){
array_push($data, $rows);
}
}
echo json_encode($data);
}



if(isset($_POST["updateProfile"])){
$name = $obj->cleanInput($_POST["name"]);
$value = $obj->cleanInput($_POST["value"]);
$value = $obj->con->real_escape_string($value);
$id = $_POST["updateProfile"];
$q = $obj->con->query("update biodata set ".$name."='".$value."' where uid=".$id);
if($q){
$data = [
"status"=>"success",
"msg"=>"<i style='color:green;' class='fa fa-check  animated bounceIn'></i>"
];
}else{
$data = [
"status"=>"error:[check debugger]",
"msg"=>"<i style='color:red;' class='fa fa-exclamation-triangle  animated bounceIn'></i>"
];
}
echo json_encode($data);
}


if(isset($_FILES["profilePic"])){
//print_r($_FILES);
$fileName = $obj->uploadFile($_FILES["profilePic"], "profile");
if($obj->con->query("update biodata set profilePic='".$fileName."' where uid=".$_SESSION["id"])){
$data = [
"status"=>true,
"file"=>$fileName,
"msg"=>"Profile picture updated successfully"
];
}else{
$data = [
"status"=>false,
"msg"=>"Error uploading file."
];
}
echo json_encode($data);
}




if(isset($_POST["actionOnPost"])){
$action = $_POST["actionOnPost"];
$msg = (isset($_POST['msg']) && !empty($_POST['msg'])) ? $_POST['msg'] : 'shared';
$pid = (isset($_POST["pid"]))?$_POST["pid"]:rand();
$rtwt_pid = rand();
$following = $_POST["who"];
$follower = $_SESSION["id"];
$page = (isset($_POST["page"]))?"profile":"public";
$noOfFollowers = 0;
$post = ($action == 'shared')?'\'s post':'';

$res = $Main->search("fullName",$following);


if($Main->setActivity($following, $action, $pid) === true){
if($page === "profile"){
$noOfFollowers = $Main->getActions($following, "sid", "uid");
}
if($action == 'shared'){
$retweeted = $follower;
$text = $msg;
$text = strip_tags($text);
$text = $obj->con->real_escape_string($text);
$text = wordwrap($text, 500, "<br />\n");

//$tagName = implode(",",$Main->searchTag($text));


$text = preg_replace('/@(\\w+)/','<a class="hashTag" href="../hash/$1.php">$0</a>',$text);

$text = preg_replace('/#(\\w+)/','<a class="hashTag" href="../hash/$1.php">$0</a>',$text);

$comment = $text;

$comment = preg_replace('/`(\\w+)/','<font style="font-family:cursive;font-size:large;">$1</font>',$comment);

$comment = preg_replace('/del-(\\w+)/','<del>$1</del>',$comment);

$comment = preg_replace('/~(\\w+)/','<b>$1</b>',$comment);

$comment = preg_replace('/_(\\w+)/','<i>$1</i>',$comment);

$comment = preg_replace('/<script>(\\w+)/','<b>••</b>',$comment);

$comment = preg_replace('/<a>(\\w+)/','<a href="$1">$0</a>',$comment);

$text = $comment;

$text = nl2br($text);
$msg = $text;
if($obj->con->query("insert into feeds (uid,pid,text,type,type_id)
 values (".$retweeted.",".$rtwt_pid.",'".$msg."','shared',".$pid.")")){

preg_match_all('/@(\\w+)/',$text,$match);
//print_r($match[1]);
if(count($match[1]) > 0){
foreach($match[1] as $tag){
$isMentioned = $obj->con->query('SELECT uid FROM biodata WHERE userName = "'.$tag.'"')->fetch_object()->uid;
if($isMentioned == $uid) continue; //$uid here is the session id
$Main->setActivity($isMentioned, "mentioned", $pid);
$obj->con->query("INSERT INTO tags (uid, tagName,pid) 
				VALUES (".$isMentioned.", '".$tag."',".$pid.")");
}
}
}
}
//public function getActions($sid, $uid="uid", $what="sid", $action="following"){
$noOfPostLikes = $Main->getActions($pid, "uid", "pid", "liked");

$data = [
"status"=>true,
"page"=>$page,
"followers"=>$noOfFollowers,
"msg"=>"You ".$action." ".$res.$post,
"postLikes"=>$noOfPostLikes
];
}else{
$data = [
"status"=>false,
"page"=>$page,
"followers"=>$noOfFollowers,
"msg"=>"Error ".$action." ".$res,
"postLikes"=>$noOfPostLikes
];
}
echo json_encode($data);
}


if(isset($_GET["loadNewNotification"])){
$sessionId = $_SESSION["id"];
$data = [];
$sql = $obj->con->query("select activity.*, 
					biodata.uid,
					 biodata.userName,
					biodata.profilePic, biodata.fullName,
					DATE_FORMAT(activity.time,'%r') as time,
					DATE_FORMAT(activity.time,'%a, %D of %M at %h:%i') as o_time				
					from activity join biodata 
					on activity.uid=biodata.uid
					where (activity.sid='".$sessionId."' 
					or activity.uid='".$sessionId."') 
					and activity.visibility = 1
					order by activity.time desc");


if($sql->num_rows > 0){

while($rows = $sql->fetch_object()){

$arg1 = $obj->con->query("SELECT uid FROM activity WHERE sid=".$sessionId." AND action='following' LIMIT 1");
$arg2 = $obj->con->query("SELECT sid FROM activity WHERE uid=".$arg1->fetch_object()->sid." AND action='following' LIMIT 1");

//$arg3 = $arg1+$arg2;
if($arg2->num_rows > 0){
$rows->msg = "You and ". $Main->search("userName", $arg2->fetch_object()->uid)." started following each other";
$rows->action = "eachOther";
}
$pid = $obj->con->query("SELECT * FROM feeds WHERE pid=".$rows->pid)->fetch_object(); //$Main->getActions($rows->pid, "uid", "pid", "liked");
if($pid->text == "" || $pid->text == null){
$text = "";
}else{
$text = $pid->text;
}
$commentObj = $obj->con->query("SELECT * FROM comments WHERE (uid=".$_SESSION["id"]." AND pid=".$rows->pid.") OR (sid=".$_SESSION["id"]." AND pid=".$rows->pid.")")->fetch_object(); //$Main->getActions($rows->pid, "uid", "pid", "liked");

$fid = $obj->con->query("SELECT fullName, profilePic FROM biodata WHERE uid=".$rows->sid)->fetch_object(); //$Main->getActions($rows->pid, "uid", "pid", "liked");

$whose_post = $obj->con->query('SELECT replies.pid, feeds.uid, 
biodata.gender AS whose_poster_gender, biodata.userName AS whose_poster_uname, biodata.uid AS whose_poster_uid
FROM replies 
JOIN feeds 
ON replies.pid=feeds.pid 
JOIN biodata 
ON feeds.uid=biodata.uid 
WHERE replies.pid='.$rows->pid);

if($whose_post->num_rows > 0){
$whose_poster_object = $whose_post->fetch_object();
$rows->whose_poster_gender = $whose_poster_object->whose_poster_gender;
$rows->whose_poster_gender_pronoun = ($rows->whose_poster_gender == 'male')?'his':'her';
$rows->get_poster_pronoun = ($_SESSION['id'] == $whose_poster_object->whose_poster_uid)?'your':$rows->whose_poster_gender_pronoun;
$rows->get_poster_uname = $whose_poster_object->whose_poster_uname;
$rows->get_poster_uid = $whose_poster_object->whose_poster_uid;
}else{
//continue;
}
$rows->parent_comment = $obj->con->query("SELECT comment_text FROM comments WHERE id=".$rows->parent_id)->fetch_object()->comment_text;
$rows->postPic = $pid->tmp_pic;
$rows->postText = $text;
$rows->comment = $commentObj->comment_text;
$rows->ccidfn = $commentObj->id;
$rows->ssidfn = $commentObj->sid;
$rows->ddfn = $commentObj->date;
$rows->fidName = $fid->fullName;
$rows->fidPic = $fid->profilePic;

array_push($data, $rows);
}
}else{
array_push($data);
}
echo json_encode($data);
}


if(isset($_POST["getNameFromNotification"])){
//$data = [];
$uid = $_POST["getNameFromNotification"];
//for($i = 0; $i<count($_POST["getNameFromNotification"]); $i++){
//$res = array_push (
$data = $Main->search("fullName", $uid);
$data .= $Main->search("profilePic", $uid);
//}
echo $data;
}




if(isset($_POST["isRead"])){
$type = $_POST['isRead'];
$sid = $_SESSION['id'];
$pid = $_POST['pid'] ?? 0;
$action = $_POST['action'];
$res = [];
switch($type){
case 'setRead':
$obj->con->query("UPDATE activity SET `read` = '1' WHERE action='".$action."' AND pid='".$pid."' AND `sid` = ".$sid);
break;
case 'getUnreadNotification':
$unreadNot = $obj->con->query("SELECT `read` FROM `activity` WHERE `read` = '0' AND `sid` = ".$sid);
$unreadMsg = $obj->con->query("SELECT `read` FROM `private_chat` WHERE `read` = '0' AND `uid` = ".$sid);
//if($unreadMsg->fetch_object()->uid == $sid){
$res['unreadMsg'] = $unreadMsg->num_rows;
//}
$res['unreadNot'] = $unreadNot->num_rows;
break;
}
echo json_encode($res);
}


if(isset($_POST["fetchTweet"])){
$uname = $_POST["uname"];
$pid = $_POST["pid"];
$uid = $_POST["uid"];

$data = [];

$q = $obj->con->query("SELECT feeds.*, biodata.*,
			DATE_FORMAT(feeds.date, '%a, %D %h:%i') as date 
						FROM feeds
						JOIN biodata
						 ON feeds.uid=biodata.uid 
						 WHERE feeds.pid=".$pid.
						 " LIMIT 1");
if($q->num_rows > 0){
while($rows = $q->fetch_object()){
$feedPic_ = $obj->con->query("SELECT pic FROM feeds_pics WHERE pid=".$rows->pid);
while($p = $feedPic_->fetch_object()){
$rows->feedPic[] = $p->pic;
}
$rows->sessImg = $Main->search("profilePic", $_SESSION["id"]);
array_push($data, $rows);
}
}else{
$data[] ="COULD NOT FETCH REQUESTED DATA.";
}
echo json_encode($data);
}



if(isset($_POST["storeComment"])){
$uid = $_POST["uid"];
$sid = $_SESSION["id"];
$pid = $_POST["pid"];
//$file = $_FILES["file"];
$comment = $obj->con->real_escape_string($_POST["comment"]);
$comment = nl2br($comment);
//$action = ($_POST["isReply"] === true)?"comment":"replied";
$q = null;
$data = [];
$parent_id = 0;
$action = null;
$done = false;
$containsHash = false;

if(strpos("#",$comment) !== false){
$tagName = implode(",",$Main->searchTag($comment));
$containsHash = true;
}

$comment = preg_replace('/`(\\w+)/','<font style="font-family:cursive;font-size:large;">$1</font>',$comment);

$comment = preg_replace('/del-(\\w+)/','<del>$1</del>',$comment);

$comment = preg_replace('/@(\\w+)/','<a class="hashTag" href="../hash/$1.php">$0</a>',$comment);

$comment = preg_replace('/#(\\w+)/','<a class="hashTag" href="../hash/$1.php">$0</a>',$comment);

$comment = preg_replace('/~(\\w+)/','<b>$1</b>',$comment);

$comment = preg_replace('/_(\\w+)/','<i>$1</i>',$comment);

$comment = preg_replace('/<script>(\\w+)/','<b>••</b>',$comment);

$comment = preg_replace('/<a>(\\w+)/','<a href="$1">$0</a>',$comment);



switch(($_POST["isReply"])){
case "true":
$action = "replied";
$parent_id = $_POST["parent_id"];
if($obj->con->query("INSERT INTO replies (uid,sid,pid,parent_id,comment_text)
						VALUES (".$uid.",".$sid.",".$pid.",'".$parent_id."','".$comment."')")
){
$done = true;
}
break;

case "false":
$action = "comment";
if($obj->con->query("INSERT INTO comments (uid, sid, pid, comment_text) 
						VALUES (".$uid.",".$sid.",".$pid.",'".$comment."')")

){
$done = true;
}
break;
}

if($done){
$Main->setActivity($uid, $action, $pid, $parent_id);
$data['status'] = '<i style="color:green;" class="fa fa-check animated bounceIn"></i>';
if($containsHash){
$obj->con->query("INSERT INTO tags (uid, pid, tagName) 
						VALUES (".$uid.",".$pid.",'".$tagName."')");
}
}else{
$data['status'] = '<i style="color:red;" class="fa fa-exclamation-triangle animated bounceIn"></i>';
}
echo json_encode($data);
}



if(isset($_POST["fetchTweetComment"])){

$uid = $_POST["uid"];
$sid = $_SESSION["id"];
$pid = $_POST["pid"];
$action = "comment";
$limit = $_POST['limit'] ?? '';
$data = [];
$q = $obj->con->query("SELECT DATE_FORMAT(comments.date, '%a, %D %h:%i') as time, comments.* FROM comments WHERE comments.pid=".$pid." ORDER BY comments.date ASC");
if($q->num_rows > 0){
while($rows = $q->fetch_object()){
$rows->no_of_comments = $obj->con->query("SELECT comment_text FROM comments WHERE pid=".$pid)->num_rows;
$rows->noOfReplies = $obj->con->query("SELECT sid FROM replies WHERE parent_id=".$rows->id)->num_rows;
$rows->commenter_pic = $Main->search("profilePic",$rows->sid);
$rows->commenter_userName = $Main->search("userName",$rows->sid);
$rows->commenter_fullName = $Main->search("fullName",$rows->sid);
$rows->poster_userName = $Main->search("userName",$rows->uid);
$rows->commenter_id = $Main->search("uid",$rows->sid);

$c = $obj->con->query("SELECT biodata.profilePic, biodata.userName, replies.* 
FROM replies 
JOIN biodata 
ON replies.uid = biodata.uid 
WHERE replies.parent_id=".$rows->id." ".$limit);
if($c->num_rows > 0){
while($i = $c->fetch_object()){
$rows->fReplies[] = $i;
}
}

array_push($data, $rows);
}
}

echo json_encode($data);
}



if(isset($_POST["sharePost"])){

echo json_encode("got ya");
}



if(isset($_GET["signoutUser"])){
if(isset($_SESSION["id"])){
$obj->con->query("UPDATE biodata SET online = '0' WHERE uid = ".$_SESSION['id']." LIMIT 1");
unset($_SESSION["id"]);
$_SESSION = array();
session_destroy();
}
echo(json_encode(["signedout"=>true]));
}



if(isset($_GET["getSuggestedUser"])){
$return = [];
//$rows = new \stdClass;
$limit = $_GET['limit'] ?? '';
$query = $obj->con->query("SELECT * FROM biodata ORDER BY RAND() ".$limit);
while($rows = $query->fetch_object()){
if($rows->uid === $_SESSION["id"]) continue;


$isFollowing = $obj->con->query("SELECT * FROM activity WHERE uid=".$rows->uid." and sid=".$_SESSION["id"]." and action='following' LIMIT 1")->num_rows;
$followedBy = $obj->con->query("SELECT activity.uid, biodata.* FROM activity JOIN biodata ON activity.uid=biodata.uid WHERE activity.uid=".$rows->uid." AND action='following' LIMIT 5");
$rows->isFollowing = ($isFollowing > 0) ? true : false ;
$rows->followedBy = $followedBy->num_rows;
$rows->isNewUser = (date("d-m-y", strtotime($rows->regDate)) === date("d-m-y"))? true: false;

array_push($return, $rows);

}


echo json_encode($return);
}





if(isset($_GET["getSearchResult"])){
$type = $_GET["type"];
$val = trim($_GET["getSearchResult"]);
$val = $obj->con->real_escape_string($val);
$return = [];
switch($type){
case 'all':
$q = "SELECT * FROM biodata WHERE (userName LIKE '%".$val."%') OR (fullName LIKE '%".$val."%')";
$r = "SELECT * FROM tags WHERE tagName LIKE '%".$val."%' ";
$s = "SELECT * FROM feeds WHERE text LIKE '%".$val."%' ";

$q = $obj->con->query($q);
if($q->num_rows > 0){
while($rows = $q->fetch_object()){
$rows->type = $type;
array_push($return, $rows);
}
}else{
array_push($return);
}
$r = $obj->con->query($r);
if($r->num_rows > 0){
while($rows = $r->fetch_object()){
$rows->type = $type;
array_push($return, $rows);
}
}else{
array_push($return);
}
$s = $obj->con->query($s);
if($s->num_rows > 0){
while($rows = $s->fetch_object()){
$rows->type = $type;
array_push($return, $rows);
}
}else{
array_push($return);
}
break;
case 'people':
$s = "SELECT * FROM biodata WHERE (userName LIKE '%".$val."%') OR (fullName LIKE '%".$val."%')";
$s = $obj->con->query($s);
if($s->num_rows > 0){
while($rows = $s->fetch_object()){
$rows->type = $type;
array_push($return, $rows);
}
}else{
array_push($return);
}
break;
case 'post':
$s = "SELECT * FROM feeds WHERE text LIKE '%".$val."%' ";
$s = $obj->con->query($s);
if($s->num_rows > 0){
while($rows = $s->fetch_object()){
$rows->type = $type;
array_push($return, $rows);
}
}else{
array_push($return);
}
break;
case 'tags':
$s = "SELECT * FROM tags WHERE tagName LIKE '%".$val."%' ";
$s = $obj->con->query($s);
if($s->num_rows > 0){
while($rows = $s->fetch_object()){
$rows->type = $type;
array_push($return, $rows);
}
}else{
array_push($return);
}
break;
}


echo json_encode($return);
}



if(isset($_POST["fetchReplies"])){
$commentId = $_POST["commentId"];
$pid = $_POST["pid"];
$uid = $_POST["uid"];
$sid = $_POST["sid"];
$commenterId = $_POST["commenterId"];

$return = [];
//print_r($commentId);
$q = $obj->con->query("SELECT *, DATE_FORMAT(date, '%d:%i:%s') AS date FROM replies WHERE parent_id=".$commentId." ORDER BY date ASC");

while($rows = $q->fetch_object()){
$rows->no_of_comments = $obj->con->query("SELECT * FROM replies WHERE parent_id=".$commentId)->num_rows;
$rows->commenter_pic = $Main->search("profilePic",$rows->sid);
$rows->commenter_userName = $Main->search("userName",$rows->sid);
$rows->commenter_fullName = $Main->search("fullName",$rows->sid);
$rows->poster_userName = $Main->search("userName",$rows->uid);
$rows->parent_comment_name = $Main->search("fullName",$commenterId);

array_push($return, $rows);
}

echo json_encode($return);
}



if(isset($_POST["updateWallpaper"])){
$realMeet = new RealMeet;
$return = [];
$file = $_FILES["file"];
$fileName = $realMeet->uploadFile($file, "profile");
//$name = $file[];
//print_r($fileName);
$q = $realMeet->con->query("UPDATE biodata SET wallpaper='".$fileName."' WHERE uid=".$_SESSION["id"]);
if($q){
$q = $realMeet->con->query("SELECT wallpaper FROM biodata WHERE uid=".$_SESSION["id"]);
if($q->num_rows > 0){
while($rows = $q->fetch_object()){
array_push($return, $rows);
}
}else{
array_push($return);
}
}
echo json_encode($return);
}



if(isset($_POST["storeMoment"])){
$return = [];
$mComment = $_POST["mComment"];
$mFile = $_FILES["mFile"];
$bg = $_POST["bg"];
$font = $_POST["font"];
$txtColor = $_POST["txtColor"];
$fontSize = $_POST["fontSize"];
$sid = $_SESSION["id"];
$mComment = (isset($mComment))?$mComment:null;
$mComment = $obj->con->real_escape_string($mComment);
$ptn1 = "/\*(.*)\*/i";
$ptn2 = "/\~(.*)\~/i";
$ptn3 = "/\<(.*)/i";
$mComment = preg_replace($ptn1,"<b>$1</b>",$mComment);
$mComment = preg_replace($ptn2,"<i>$1</i>",$mComment);
//$mComment = preg_replace($ptn3," ",$mComment);



$mFile = (isset($mFile))?$mFile:null;
$mFileName = ($mFile != null)?$obj->uploadFile($mFile,"moment","MOMENT"):null;
$q = "INSERT INTO moment (sid, file, text, bg, font, fontSize,txtColor) 
VALUES (".$sid.",'".$mFileName."','".$mComment."','".$bg."','".$font."','".$fontSize."','".$txtColor."')";
$q = $obj->con->query($q);
if($q){
array_push($return, true);
}else{
array_push($return, $q->error);
}
//print_r($_POST);
echo json_encode($return);
}





if(isset($_GET["fetchMoment"])){
$return = [];
$sid = $_SESSION["id"];
if((isset($_GET["where"])) && (($_GET["where"]) == "private")){
$where = "WHERE moment.sid=".$sid;
}else{
$where = "";
}

$q = "SELECT moment.*,
		 biodata.fullName, 
		 biodata.profilePic,
		 biodata.uid 
		 FROM moment 
		 JOIN biodata
		 ON moment.sid=biodata.uid
		 ".$where." ORDER BY moment.time DESC";
$q = $obj->con->query($q);
if($q->num_rows > 0){
while($rows = $q->fetch_object()){
$rows->sessionId = $_SESSION["id"];
$rows->sessPic = $Main->search("profilePic",$rows->sessionId);
array_push($return, $rows);
}
}
echo json_encode($return);
}




if(isset($_GET["fetchMomentOnClick"])){
$return = [];
$sid = $_SESSION["id"];
$clickId = $_GET["where"];
$cardId = $_GET["cardId"];
$where = "WHERE moment.sid=".$clickId." AND moment.id=".$cardId;
$q = "SELECT moment.*,
		 biodata.fullName, 
		 biodata.profilePic,
		 biodata.uid 
		 FROM moment 
		 JOIN biodata
		 ON moment.sid=biodata.uid
		 ".$where." ORDER BY moment.time DESC";
$q = $obj->con->query($q);
if($q->num_rows > 0){
while($rows = $q->fetch_object()){
$rows->sessionId = $_SESSION["id"];
array_push($return, $rows);
}
}
echo json_encode($return);
}



if(isset($_GET["actionOnMoment"])){
$action = $_GET["actionOnMoment"];
$by = $_GET["by"];
$from = $_GET["from"];
$momentId = $_GET["momentID"];
if($action === "view"){
if($obj->con->query("SELECT sid, momentID FROM moment_view WHERE sid=".$by." AND momentID=".$momentId)->num_rows < 1){
$obj->con->query("INSERT INTO moment_view (uid, sid, momentID)
				 VALUES (".$from.",".$by.",".$momentId.")");
}
}elseif($action === "showViewers"){
$return = [];
$q = "SELECT moment_view.*,
		 biodata.fullName, 
		 biodata.uid,
	     DATE_FORMAT(moment_view.time, '%a %h:%i') as time 
		 FROM moment_view
		 JOIN biodata
		 ON moment_view.sid=biodata.uid
		 WHERE momentID=".$momentId."
		 ORDER BY moment_view.tid DESC";
$q = $obj->con->query($q);
if($q->num_rows > 0){
while($rows = $q->fetch_object()){
array_push($return, $rows);
}
}
echo json_encode($return);
}elseif($action === "react"){
$reaction = $_GET["smiley_name"];
//echo $reaction."+++".$momentId."+++".$by;
$obj->con->query("UPDATE moment_view SET reaction = '".$reaction."' WHERE sid=".$by." AND momentID=".$momentId);
}
}




if(isset($_GET["load"])){
$load = $_GET["load"];
$uid = $_GET["uid"];
$sid = $_SESSION["id"];
$return = [];
if($load == "follower"){
$obj = $obj->con->query("SELECT biodata.uid AS fuid, biodata.*, activity.* FROM activity JOIN biodata ON biodata.uid=activity.sid WHERE activity.action='following' AND activity.uid=".$uid);;
}elseif($load == "following"){
$obj = $obj->con->query("SELECT  biodata.uid AS fuid,  biodata.*, activity.* FROM activity JOIN biodata ON biodata.uid=activity.uid WHERE activity.action='following' AND activity.sid=".$uid);;
}

if($obj->num_rows > 0){
while($rows = $obj->fetch_object()){
$rows->isFollowing = $Main->isFollowing($sid,$rows->fuid);
array_push($return, $rows);
}
}else{
array_push($return);
}
echo json_encode($return);
}



if(isset($_POST["storeChatMsg"])){
//print_r($_POST);
$chatMsg = $_POST["chatMsg"]; //Chat message
$sid = $_SESSION["id"]; //From
$uid = $_POST["uid"];   //To
$file = $_FILES["file"]; //Attachment
//print_r($file);
$__detect_type = strtoupper(explode("/",$file["type"])[0]);
//echo($__detect_type);

//$fileType = strtoupper(end(explode(".",$file["name"])));

$file = ($file == "" || count($file) < 1)?null:$obj->uploadFile($file, "chats",$__detect_type."_CHATS");;
$return = [];
$chatMsg = $obj->con->real_escape_string(trim($_POST["chatMsg"])); //Chat message
$q = "INSERT INTO private_chat (sid,uid, message,file) 
			VALUES (".$sid.",".$uid.",'".$chatMsg."','".$file."')";
$q = $obj->con->query($q);
haveCharted($obj->con, $sid,$uid,$obj->con->insert_id);
if($q){
echo json_encode($q);
//echo fetchChats($obj->con, $uid,$sid);
}else{
echo json_encode("Error: ".$q->error);
}
}

if(isset($_POST['fetchChatMsg'])){
$sid = $_SESSION["id"]; //From
$uid = $_POST["uid"];   //To
echo fetchChats($obj->con,$uid,$sid);
}

function fetchChats($con,$uid,$sid){
$query = "SELECT *, DATE_FORMAT(time,'%a, %h:%i') AS time FROM private_chat WHERE (uid=".$uid." AND sid=".$sid.") OR (sid=".$uid." AND uid=".$sid.") ORDER BY tid, time ASC";
$query = $con->query($query);
$return = [];
if($query->num_rows > 0){
while($rows = $query->fetch_object()){
array_push($return, $rows);
}
}else{
array_push($return);
}
return json_encode($return);
}


function haveCharted($c,$sid,$uid,$msg){
if($c->query("SELECT sender, receiver FROM tmp_chat WHERE (sender=".$sid." AND receiver=".$uid.") OR (sender=".$uid." AND receiver=".$sid.")")->num_rows > 0){
$c->query("UPDATE tmp_chat SET last_message=".$msg." WHERE (sender=".$sid." AND receiver=".$uid.") OR (sender=".$uid." AND receiver=".$sid.")");
}else{
$c->query("INSERT INTO tmp_chat (sender,receiver,last_message) VALUES (".$sid.",".$uid.",".$msg.")");
}
}



if(isset($_GET["setMessageInfo"])){
$action = $_GET["action"] ?? null;
$id = $_GET["id"] ?? null;
$status = $_GET["status"] ?? null;

//UPDATE `tmp_chat` SET `is_typing` = $isTrue WHERE `last_message` = $id;


switch($action){
case "isRead":
if(!$obj->con->query("UPDATE `private_chat` SET `read` = '1' WHERE `tid` = '".$id."'")){
echo($obj->con->error);
}else{
echo $id;
}
break;
case "typing":
if(!$obj->con->query("UPDATE `tmp_chat` SET `is_typing` = '".$status."' WHERE `last_message` = '".$id."'")){
echo($obj->con->error);
}else{
echo $status;
}
break;
case "checkIfTyping":
$q = $obj->con->query("SELECT * FROM `tmp_chat` WHERE `last_message` = '".$id."' LIMIT 1");
echo json_encode($q->fetch_object());
break;
}
}


if(isset($_GET['fetchRetweetedPosts'])){
$pid = $_GET['pid'];
$return = [];
$q = 'SELECT feeds.*,DATE_FORMAT(feeds.date,"%a, %r") AS time,biodata.fullName,
biodata.userName, biodata.profilePic
FROM feeds JOIN biodata 
ON feeds.uid = biodata.uid 
WHERE feeds.pid = '.$pid;
$q = $obj->con->query($q);
if($q->num_rows > 0){
while($rows = $q->fetch_object()){
array_push($return,$rows);
}
}else{
array_push($return);
}
echo json_encode($return);
}



if(isset($_GET['CommandList'])){
$command = $_GET['CommandList'];
$pid = $_GET['pid'];
$uid = $_GET['uid'];
$sid = $_GET['sid'];
$response = [];
switch($command){
case 'delete':
$q = 'DELETE FROM feeds WHERE pid = '.$pid;
$q = $obj->con->query($q);
/*$q = 'DELETE FROM comments WHERE pid = '.$pid;
$q = $obj->con->query($q);
$q = 'DELETE FROM feeds_pics WHERE pid = '.$pid;
$q = $obj->con->query($q);
$q = 'DELETE FROM replies WHERE pid = '.$pid;
$q = $obj->con->query($q);
*/
if($q->affected_rows > 0){
$response['text'] = 'Post has been deleted successfully';
$response['bool'] = true;
$response['code'] = 100;
}else{
$response['text'] = 'This post does not exist or have already been deleted.';
$response['bool'] = false;
$response['code'] = 101;
}
break;
case 'isFollowing':


if($_GET['who'] == $_SESSION['id']){
$response['text'] = 'Edit profile';
}else{
$is_f = $Main->isFollowing($_SESSION['id'],$_GET['who']);
if($is_f == true){
$response['text'] = "Unfollow";
$response['isFollowing'] = true;
}else{
$response['text'] = "Follow";
$response['isFollowing'] = false;
}
}
$post = $Main->con->query("SELECT uid FROM feeds WHERE uid=".$_GET['who'])->num_rows;
$following = $Main->con->query("SELECT sid FROM activity WHERE action='following' AND uid=".$_GET['who'])->num_rows;
$follower = $Main->con->query("SELECT uid FROM activity WHERE action='following' AND sid=".$_GET['who'])->num_rows;
$response['post_count'] = $post;
$response['following_count'] = $following;
$response['follower_count'] = $follower;
break;
}
echo json_encode($response);
}



if(isset($_GET['request'])){
$action = $_GET['request'];
$whoid = $_GET['whoid'] ?? null;
$session = $_SESSION['id'] ?? null;
$return = [];

 //$Main->search('userName',$whoid).' and '.$Main->search('userName',$session).' are following each other.';

switch($action){
case 'isFollowingEachOther':
$return['isFollowingEachOther'] = ($Main->isFollowing($session, $whoid) && $Main->isFollowing($whoid, $session)); 
if($return['isFollowingEachOther'] == false){
if($Main->isFollowing($session, $whoid)){
$return['whoFollows'] = $session;
}else{
$return['whoFollows'] = $whoid;
}
}
break;
case 'deleteNotification': 
$data = $_GET['data'];
foreach($data as $i){
if(
$obj->con->query('UPDATE `activity` SET `visibility` = 0 WHERE `tid` = '.$i)
&&
$obj->con->query('UPDATE `activity` SET `read` = 1 WHERE `tid` = '.$i)){
$return['DELETED'] = true;
$return['code'][] = $i;
}else{
$return['DELETED'] = false;
}
}
break;
case 'setAsRead': 
$data = $_GET['data'];
foreach($data as $i){
if($obj->con->query('UPDATE `activity` SET `read` = 1 WHERE `tid` = '.$i)){
$return['READ'] = true;
$return['code'][] = $i;
}else{
$return['READ'] = false;
}
}
break;
case 'setAsUnread': 
$data = $_GET['data'];
foreach($data as $i){
if($obj->con->query('UPDATE `activity` SET `read` = 0 WHERE `tid` = '.$i)){
$return['UNREAD'] = true;
$return['code'][] = $i;
}else{
$return['UNREAD'] = false;
}
}
break;
case 'updateUserData':
$name = $_GET['name'];
$value = $obj->con->real_escape_string(ucfirst($_GET['value']));
if($obj->con->query('UPDATE biodata SET '.$name.' = "'.$value.'" WHERE uid= '.$session)){
$data = $obj->con->query('SELECT '.$name.' FROM biodata WHERE uid = '.$session);
$return['done'] = true;
$return['msg'] = 'Updated successfully';
$return['data'] = $data->fetch_object();
$return['name'] = $name;
$return['value'] = ucfirst($value);
}else{
$return['done'] = false;
$return['msg'] = 'Data could not be updated at the moment. Please try again.';
}

break;
}
echo json_encode($return);
}


if(isset($_GET['modifyPrivacy'])){
$uid = (isset($_GET['uid']) && $_GET['uid'] != null) ? $_GET['uid'] :$_SESSION['id'];
$privacy = Privacy::getInstance($uid);
$type = $_GET['modifyPrivacy'];
switch($type){
case 'setProfileVisibility':
$data = $_GET['val'];
$privacy->setVisibility($data);
break;
case 'getProfileVisibility':
$return['visibility'] = $privacy->getVisibility();
break;
}
echo json_encode($return);
}

?>