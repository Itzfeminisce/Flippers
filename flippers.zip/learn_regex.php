<?php

$str = "This is a http://www.fb.com/Link";
$var = preg_match("/^(http:\/\/)/i",$str, $m);




/*$exp = '/(w+)(\s)(http:\/\/)/i';
$str = "This is a <a href='http://www.fb.com'>Link</a>";
$match = preg_match($exp, $str, $m);
$text = preg_replace('/@(\\w+)/','<a style="color:rgb(255,0,255);font-weight:400;" href="../hash/$1.php">$0</a>',$text);
*/
print_r($m);

?>