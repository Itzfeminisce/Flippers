
<?php

/*include_once "./header.php";*/
include_once "./includes/Handler.class.php";

$main = new Maintenance($_SESSION["id"]);

?>

<style type="text/css">

body{
background:white;
}
.header {
display:flex;
flexFlow:row nowrap;
z-index:20;
}

.header button, .header input  {
width:100%;
padding:10px;
background:#fff;
border-radius:100px;
border:1px solid #eee;
transition:500ms linear;
text-align:left;
}

.header input:focus {
background:#eee;
}

.header button:active {
background:#08a8b8;
}


._console_placeholder_ {
display:flex;
flex-flow:row wrap;
justify-content:flex-start;
align-content:shrink;
align-items:flex-start;
}

._placeholder_1 {
width:24.5%;
max-width:24.5%;
height:100px;
max-height:100px;
background-color:#eee;
margin:1px auto;
background-size:cover;
background-repeat:no-repeat;
background-position:center;
clear:both;
}

._placeholder_1.card_1{
width:49.5%;
max-width:49.5%;
}

._placeholder_1.card_6{
width:49.5%;
max-width:49.5%;
height:100px;
max-height:100px;
}

._placeholder_1.card_7{
width:49.5%;
max-width:49.5%;
height:200px;
max-height:200px;
}

._placeholder_1.card_8{
width:49.5%;
max-width:49.5%;
height:200px;
max-height:200px;
}

._placeholder_1.card_13{
width:99.5%;
max-width:99.5%;
height:200px;
max-height:200px;
}
</style>

<div class="header" >
<button id="searchBtn">Search items..</button>
<!--<input type="text"  id="searchBtn" placeholder="Search..." disabled="disabled"  >-->
<div></div>
</div>
<div class="console" >
<div class="_console_placeholder_" >
<?php 
$q = "SELECT * FROM feeds_pics ORDER BY id DESC";
$q = $main->con->query($q);
$i = 0;
if($q->num_rows > 0):
while($rows = $q->fetch_object()):
//print_r($obj);
$i++;
echo '<div class="_placeholder_1 card_'.$i.'" style="background-image:url(\'../uploads/feeds/'.$rows->pic.'\');"></div>';
if($i == 3) echo '<img src="./img/staysafe-o.png" width="100%" height="200" style="margin:5px auto;display:block;">';
endwhile;
endif;
?>
</div>
</div>


<script type="text/javascript">
$(document).ready(function(){
$("#pageTitle").text("Explore");
$("button#searchBtn").click(function(){

$.load.searchModal();
/*var btn = $(this);
var searchModal = $.load.search(btn);
$("div.console").html(searchModal);
*/
});
});
</script>