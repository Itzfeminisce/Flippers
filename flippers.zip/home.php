<?php
session_start();
include_once "./includes/Handler.class.php";
$main = new Maintenance($_SESSION["id"]);
$sessPic = $main->data->profilePic;
?>
<script type="text/javascript">


$(document).ready(function(){

$.session_id = $("input#session-id").val();
$.session_pic = '<?php echo $sessPic; ?>';
$._parent = $("#_body_");

function loadTweet(use_result){
$("#pageTitle").text("Home");
$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
data:{loadFeeds:$.session_id, where:"public", limit:'LIMIT 3'},

success:function(data){
//alert(data)
//$._parent.html($.load.reload());
use_result(data);

},
error:function(xhr, textStatus, statusCode){
$._parent.html($.load.reload());
}
});
}


//setInterval(function(){
loadTweet(function(tweets){
var p = "", pp = "";
p += '<div class="" id="showMoment"></div>';
if(tweets.length < 1) $._parent.html("<h1 class='_warning_cool _small_txt _site_txt_color'>No post available.</h1>");
for(var i in tweets){
var rows = tweets[i];
var postPic = rows.pic;
var d = (postPic == "")?"none":"";
var online = (rows.online == 1)?"green":"#aaa";
var isPostLiked = (rows.isPostLiked == "1")?"red":"";
var _b = (isPostLiked == 'red')?'1000':'';
var isFollow = (rows.isFollow == "1")?"#08A8B8":"";
var isMyCard = (rows.uid == $.session_id)?"none":"none"; /* Show like / folllow button*/
var _getPage = (rows.uid == $.session_id)?"":rows.fullName;
var _three_pic = '3';
var _one_pic = '1';
var addCssOf = '';
var post_content = rows.text;
var content = '';
//alert(rows.rtwt.rtwt_username)
if(rows.type == 'shared' && rows.rtwt !== null){
content = $.load.reflip(rows);
}else{
content = '<h1 class="_panel_parag_ _large_txt hover" data-click="0" data-href="../comments?u='+rows.userName+'&pid='+rows.pid+'&uid='+rows.uid+'&frm=home" id="text_p">'+nl2br($.load.urlify($.load.reduce_length(post_content)))+'</h1>';
}
for(var e in rows.feedPic){
addCssOf = (rows.feedPic.length == 3)?e:3;
if((addCssOf != 3 && addCssOf != 0 && addCssOf != 2) || rows.feedPic.length > 3){
addCssOf = '';
}
addCssOf = (rows.feedPic.length == 2)?'':addCssOf;


//pp += '<img class="img-responsive card_'+addCssOf+'" style="display:'+d+';" data-pid="'+rows.pid+'" data-who="'+rows.uniqvar+'"  id="card_post_photo" src="../uploads/feeds/'+rows.feedPic[e]+'" >';
pp += '<div data="'+rows.feedPic[e]+'" class="img-responsive card_'+addCssOf+' hover" style="display:'+d+';background-image:url(\'../uploads/feeds/'+rows.feedPic[e]+'\');" data-pid="'+rows.pid+'" data-who="'+rows.uniqvar+'"  id="card_post_photo"></div>';
//style="background-image:url('../uploads/profile/<?php echo $sessPic; ?>');"
}

p += '<div class="_card_ _card_'+i+' animation-elements" >';
p += '<div class="_left_" >';
p += '<div id="_user_dp_" style="background-image:url(\'../uploads/profile/'+rows.profilePic+'\');" class="_img_ _user_card_img_ _site_bg_color" data-page="'+_getPage+'" data-carduid="'+rows.uid+'" data-href="../p/'+rows.userName+'"></div>';
p += '</div>';
p += '<div class="_right_" >';
p += '<div class="_panel_head_ _flex_row" >';
p += '<div class="_name _smallest_txt" >';
p += '<h1 class="_small_txt" >'+rows.fullName+' <font style="color:#687878;font-weight:400;">@'+rows.userName+'</font></h1>';
p += '<p><i class="fa fa-street-view" ></i> '+rows.state+', '+rows.country+'</p>';
p += '<p><i class="fa fa-clock" ></i> '+rows.date+'</p>';
p += '</div>';
p += '<button style="display:'+isMyCard+';" data-name="followuser" data-pid="'+rows.pid+'" data-who="'+rows.uid+'" data-href="" value="" class="_icon_" ><i style="color:'+isFollow+';"class="fa fa-thumbs-up" ></i></button>';
p += '<button style="width:auto;" data-name="" data-href="" name="commandbox" class="_icon_" ><i class="fa fa-angle-down"></i></button>';
p += '</div>';
p += content;
//p += '<h1 class="_panel_parag_ _large_txt" data-click="0" data-href="../comments?u='+rows.userName+'&pid='+rows.pid+'&uid='+rows.uid+'&frm=home" id="text_p">'+nl2br(rows.text, '<br />')+'</h1>';
p += '<div class="_panel_body_ _flex_row" >';
p += pp;
p += '</div>';
//{uname:rows.userName,uid:rows.uid,pid:rows.pid}
p += '<button onclick="$.load.smallComments(rows.fComments,null)" id="showCommentBtn" class="showCommentBtn">Show comments <i class="fa fa-angle-down"></i></button>';
p += '<div></div>';

p += $.load.smallComments(rows.fComments,null);

p += '<div class="_panel_subfooter_ _flex_row" >';
p += '<button class="ufa _icon_" data-pid="'+rows.pid+'" data-who="'+rows.uid+'" data-name="like" data-href="" id="like_btn" name="like_post" >';
p += '<i style="color:'+isPostLiked+';" class="fa fa-heart" > • '+rows.postLikes+'</i></button>';
p += '<button id="fl_retweet_btn" class="ufa _icon_" data-pid="'+rows.pid+'" data-who="'+rows.uid+'" data-name="share" data-href="" name="share_post" ><i class="fa fa-retweet">• '+rows.no_of_shared+'</i></button>';

//<button id="parent-comment-btn" data-postername="<?php echo $uname; ?>" data-pid="<?php echo $pid; ?>" data-uid="<?php echo $uid; ?>" data-action="comment" ><i class="fa fa-comments" ></i></button>

p += '<button data-postername="'+rows.userName+'" data-pid="'+rows.pid+'" data-uid="'+rows.uid+'" data-action="comment" id="loadCommentModal" class="ufa _icon_ hover" name="comment_post" >';
p += '<i class="fa fa-comments" ></i> • '+rows.no_of_comments+'</button>';
p += '</div>';
p += '<div class="_panel_footer_ _flex_row" >';
p += '<div class="_icon_ _user_card_img_" style="background-image:url(\'../uploads/profile/'+rows.sessPic+'\');"></div>';
p += '<div id="loadCom-mentModal" data-action="comment" data-postername="'+rows.userName+'" data-pid="'+rows.pid+'" data-uid="'+rows.uid+'" data-name="comment" name="commentbox" class="_small_round_input _icon_" >Write your comment...</div>';
p += '</div></div></div>';
pp = "";
$._parent.html(p);
/*$('button#showCommentBtn').click(function(){
$(this).next().html($.load.smallComments(.fComments,null));
});
*/

}


//var $animation_elements = $('div.animation-elements');



//$('h1._panel_parag_').after($.load.reflip(tweets));
//alert($.load.reflip());


//$("._card_:first").after($.load.suggestion_card());


params = {
title:'Suggested for you',
limit:'LIMIT 4'
};
$.load.suggestion_card_inline(params, function(cards){
$("._card_3").html(cards);
});




/* Card menu button starts */
$("button[name='commandbox']").click(function(e){
e.preventDefault();
var href = "../profile";
var params = [
{title:"Repost",href:href,fa:"<i class='fa fa-share _obj_commands'></i>"},
{title:"Flag",href:href,fa:"<i class='fa fa-flag _obj_commands'></i>"},
{title:"sendPM",href:href,fa:"<i class='fa fa-comment _obj_commands'></i>"},
{title:"Inquire",href:href,fa:"<i class='fa fa-exclamation-triangle _obj_commands'></i>"},
];
var modal_object = {href:href,params:params};
var modal = $.load.LoadModal(modal_object);
$(document.body).append(modal);
});
/* Card menu button ends */


/* Load comments modals starts*/
$("button#loadCommentModal").on("click", function(){
var btn = $(this);
$.load.animate(btn,'bounceIn');
var objInfo = {
sessImg : "../uploads/profile/"+rows.sessPic,
params :{
		pid:btn.data("pid"),
		uid:btn.data("uid"),
		action:(btn.data("action")=="reply")?"replying to @"+btn.data("postername"):"comment on @"+btn.data("postername")+"`s post",
		name:btn.data("postername")
		}
};
var commentBox = $.load.loadCommentModal(objInfo);
$(document.body).append(commentBox);
commentBox.txtArea.focus();
});
/* Load comments modals ends*/

/* LOAD COMMENT MODAL 2*/
/*$("button#parent-comment-btn").on("click", function(){
  var btn = $(this);
  btn.addClass("animated bounceIn faster");
  var who = (btn.data("uid") == "<?php echo $_SESSION['id']; ?>")?"your ":"@"+btn.data("postername");   
  
  var objInfo = {
  sessImg : sessImg,
  params :{
  pid:btn.data("pid"),
  uid:btn.data("uid"),
  action:(btn.data("action")=="reply")?"replying to "+who+" comment":"comment on "+who+" post",
  name:btn.data("postername")
  }
  };
  
  var commentBox = $.load.loadCommentModal(objInfo);
  $(document.body).append(commentBox);
   btn.on("animationend", function (){
   btn.removeClass("animated bounceIn faster");
    });
  });*/
  
  /* ENDS */



/* open comments modal begins */
$("h1#text_p").on("click",function(e){
var para = $(this);
//if(para.data("click") === 1){
pageUrl = para;
$.ajax({
    url: pageUrl.data("href")+"type=ajaxComment",
    success: function (data) {
        $("#_body_").html(data);
    var pageTitle = '<h4>Comments</h4>';
        $("#pageTitle").html(pageTitle);
    }
});
if (pageUrl.data("href") != window.location) {
 window.history.pushState({ path: pageUrl.data("href") }, '', pageUrl.data("href"));
}
/*}else{
para.css({maxHeight:"none"});
para.data("click",1);
}*/
});
/* open comments modal ends */

/* Like posts when you dblclick post images*/

$("div#card_post_photo").on("dblclick", function(event){
var element = $(this); //$(".card-body>img");
add_animation(element, "bounceIn", function(){
var fa_like = element.parent().next().children(":first");
fa_like.css("color","red");
var pid = element.data("pid");
var who = element.data("who");
$.ajax({
url: "./checkpoint/server.post_content.php",
type: "post",
dataType: "json",
data: {actionOnPost:"liked",pid:pid, who:who},
success: function(data){
/*alert(data);*/
if(data.postLikes == null){
return false;
}
fa_like.html("<i class='fa fa-heart'></i> • "+data.postLikes);
},
error: function(error){
//alert("Could not load data. Please try again");
}
});
});
});
/* Image like ends */

/* Animations function starts*/
function add_animation(element, animationName, callback){
element.addClass("animated "+animationName+" faster");
function removeEvent(){
element.removeClass("animated "+animationName+" faster");
element.off("animationend", removeEvent);
callback();
}
element.on("animationend", removeEvent);
}
/* Animations function ends */


/* Button handler functions*/
cardBtnHandle();
function cardBtnHandle(){
$("button").click(function(){
var btn = $(this);
var btn_name = btn.data("name");
var btn_href = btn.data("href");
switch(btn_name){
case "comment": add_animation(btn, "pulse", function(){ pageUrl = btn; $.realMeet.loadContent(); });
break;
case "share": 
add_animation(btn, "bounceIn", function(){
btn.css("color","pink");
});
var pid = btn.data("pid");
var who = btn.data("who");
$.getJSON('../checkpoint/server.post_content.php',{fetchRetweetedPosts:true,pid:pid,who:who}).done(function(data){
//alert(data)
$.load.share(data,{pid:pid,who:who});
});

break;
case "like": add_animation(btn, "bounceIn", function(){
btn.css({color:'red',fontWeight:'1000'});
var pid = btn.data("pid");
var who = btn.data("who");
$.ajax({
url: "./checkpoint/server.post_content.php",
type: "post",
dataType: "json",
data: {actionOnPost:"liked",pid:pid, who:who},
success: function(data){
if(data.postLikes == null){
return false;
}

btn.children(':first').text(" • "+data.postLikes);
},
error: function(error){
//alert("Could not load data. Please try again");
}
});
});
break;
case "followuser": add_animation(btn, "bounceIn",
 function(){ 
 isMe(btn);
 var data = {actionOnPost:"following", who: btn.data("who"), pid: btn.data("pid")};
 sendRequest(data, function(data){
 btn.children(":first").css({color:"rgb(255,0,255)"});
 });  });
break;
}


});
}

/* Button handler functions end*/


/* Display moment in homepage */
$("#showMoment").html($.load.moments_card({header:"Add stories",sessPic:$.session_pic}));


/* Load profile when user dl is clicked */
$("div#_user_dp_").on("click",function(){
var pageUrl = $(this);
var page = (pageUrl.data("page") == "")?"Profile":pageUrl.data("page");
$("#pageTitle").html(page);
$.ajax({
        url: pageUrl.data("href"),
        success: function (data) {
          $("div#_body_").html(data);
        }
    });
    if (pageUrl.data("href") != window.location) {
        window.history.pushState({ path: pageUrl.data("href") }, '', pageUrl.data("href"));
    }
});

/* Create lime break in post texts */
function nl2br(str, is_xhtml) {   
    var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';    
    return (str + ' ').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1'+ breakTag +'$2');
}

function x(){
 var $sidebar   = $("div.animation-elements");
 var $window    = $(window);
var  offset     = $sidebar.offset();
var  topPadding = 15;
 
 $window.scroll(function() {
 alert(offset.top);
/* if ($window.scrollTop() > offset.top) {
 $sidebar.animate({
 marginTop: $window.scrollTop() - offset.top + topPadding
 });
 } else {
 $sidebar.animate({
 marginTop: 0
 });
 }*/
 });
 };
 x();
 
});

//},5000);

  
/*function check_if_in_view() {
alert()
  var window_height = $window.height();
  var window_top_position = $window.scrollTop();
  var window_bottom_position = (window_top_position + window_height);

  $.each($animation_elements, function() {
    var $element = $(this);
    var element_height = $element.outerHeight();
    var element_top_position = $element.offset().top;
    var element_bottom_position = (element_top_position + element_height);

    //check to see if this current container is within viewport
    if ((element_bottom_position >= window_top_position) &&
        (element_top_position <= window_bottom_position)) {
      $element.addClass('animated bounceIn');
    } else {
      $element.removeClass('animated bounceIn');
    }
  });
}*/


});

</script>