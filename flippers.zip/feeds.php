<div style="background:white;margin:0;padding:0;" class="cont animated slideInLeft faster" >


</div>

<script type="text/javascript">
$(document).ready(function(){



var rdruid = "<?php echo $_GET['rdrid']; ?>";


var loadFeeds = function(){
$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
data:{loadProfile:rdruid},
success:function(data){
//...
var r = data[0];

$("#countryState").text(r.country+", "+r.state);
var l = r.socialLink.split(",");
var link_ ="";
for(var i = 0; i< l.length; i++){
link_ += '<i class="fa fa-rss" ></i><a target="_BLANK" href="'+l[i].trim()+'">'+l[i].trim()+'</a><br>';
}
$("#u_link").html(link_);
$("#lookingFor").html(r.lookingFor.toUpperCase());

},
fail:function(xhr, textStatus){
//...
}
});
}


loadFeeds();

});

</script>