<?php
//include_once "./header.php";
session_start();
include_once "./includes/Handler.class.php";

$main = new Maintenance($_SESSION["id"]);

$uname = $_GET["u"]??'';
$pid = $_GET['rdrid'] ?? $_GET["pid"] ?? null;
$uid = $_GET['ssid'] ?? $_GET["uid"] ?? null;
$frm = $_GET["frm"];
$sid = $_SESSION["id"];

$no_of_shared = $main->con->query("SELECT sid FROM retweet WHERE pid=".$pid)->num_rows;
$no_of_likes = $main->getActions($pid, "uid", "pid", "liked");
?>

<style type="text/css">
body{
background:white;
}
.card {
border-bottom:1px solid #aaa;
width:100%;
height:auto;
padding:5px 10px;
margin:0;
}


.card .card-header {
width:100%;
height:auto;
background:white;
display:flex;
flex-flow:row nowrap;
justify-content:flex-start;
align-content:flex-start;
margin:0;
padding:0;
border:none;
}

.card-header .icon {
width:40px;
min-width:40px;
height:40px;
border-radius:50%;
background:#eee;
border:0.5px solid #aaa;
overflow:hidden;
}

.card-header .icon img {
height:100%;
width:100%;
}

.card-header .info {
height:auto;
display:inline;
flex-flow:row nowrap;
justify-content:flex-start;
align-content:flex-start;
width:80%;
margin:auto 0 auto 5%;
/*background:#eee;*/
/*border-radius:5px;*/
}


.info p{
line-height:15px;
font-size:small;
font-weight:300;
}

.info p:first-of-type {
max-width:250px;
font-weight:600;
}

.info p:first-of-type span {
color:#aaa;
}


.card-header .toggler {
width:30px;
height:30px;
background:white;
border:none;
border-radius:50%;
font-weight:300;
}

.card .body {
width:100%;
height:auto;
background:white;
margin:auto;
}

.body.parent{
font-size:large;
line-height:20px;
padding:10px 0;
max-width:100%;
}

.body.parent p{
word-break:break-word;
text-overflow:break-word;
}
.body.child{
width:70%;
margin:auto 0 5px 18%;
}

.body.child  p{
width:auto;
height:auto;
}

.body p{
width:100%;
height:auto;
/*background:#eee;*/
margin:0 auto;
font-weight:400;
//font-size:large;
//line-height:30px;
}


.body .attachment  {
max-height:200px;
max-width:100%;
border-radius:20px;
overflow:hidden;
display:flex;
flex-flow:row wrap;
}

.card .footer {
width:90%;
height:auto;
background:white;
display:flex;
flex-flow:row nowrap;
justify-content:flex-start;
align-content:flex-start;
margin:auto 0 auto 5%;
border:none;
/*border-bottom:1px solid #aaa;*/
}

.footer button {
width:100%;
padding:0 1px;
margin:0 2px;
border-radius:5px;
background:white;
border:none;
}

.footer button:nth-child(1) {
//color:#aaa;
}

.footer button .fa{
font-weight:100
}


.footer.f-info p{
font-weight:500;
font-size:small;
width:100%;
padding:0;
}

.footer.f-info p span{
font-weight:300;
}

.card.c .text {
font-size:small;
line-height:20px;
}


.comment_btn {
width:50px;
height:50px;
position:fixed;
bottom:100px;
right:10px;
border-radius:50%;
background:rgb(255,0,255);
}

.comment_btn button {
padding:10px;
font-size:medium;
height:inherit;
width:inherit;
background:transparent;
border:none;
color:white;
}


button.control{
border:none;
background:rgba(255,0,255,.03);
margin:5px auto;
color:#333;
font-weight:400;
font-size:small;
border-left:1px solid rgb(255,0,255);
padding:0 5px;
}

.xx {
margin:10px auto;
}
.xx, .xxp-c span {
width:100%;
display:flex;
flex-flow:row nowrap;
justify-content:flex-start;
align-content:center;
padding:5px;
}

.xxi {
width:40px;
min-width:40px;
height:40px;
background-color:#eee;
border-radius:50%;
background-position:center;
background-size:cover;
background-repeat:no-repeat;
}

.xxp-c {
padding:5px;
margin:auto 10px;
}

.xxp-c h3{
padding:5px;
background-color:#F1F1F1;
border-radius:10px 10px 0 0;
font-weight:400;
}

.xxp-c span{
background-color:#F1F1F1;
padding:0 0 5px 0;
margin:0;
border-radius:0 0 10px 10px;
}

.xxp-c h3 span{
font-size:14px;
}

.xxp-c span button {
background:transparent;
border:none;
width:100%;
}

.xxp-c span button .fa.fa-heart,
.xxp-c span button .fa.fa-comment
{
font-weight:400;
}

.xcxc {
min-width:100%;
height:auto;
}
</style>

</head>
<body>
<div class="weContainer animated slideInUp faster" >

<div class="card" >
<div class="card-header" >
<div class="icon" ><img src="../img/loader.gif" ></div>
<div class="info" >
<p class="i" >Default</p>
</div>
<button id="loadCommandForParent" name="commandbox"  class="toggler" >
<i class="fa fa-angle-down" ></i>
</button>
</div>
<div class="body parent" >
<p class="text" ></p>
<br>
</div>
<div style="margin:10px auto;" class="footer f-info" >
</div>
<div class="footer" >
<!--<button><?php echo $no_of_shared?> • Comments</button>-->
<button data-title="Shares" id="share_count" class="showEvent hover" ><?php echo $no_of_shared?> • Shared</button>
<button data-title="Likes" id="like_count" class="showEvent hover"  ><?php echo $no_of_likes?> • Liked</button>
<button id="fl_like_btn" data-pid="<?php echo $pid; ?>" data-who="<?php echo $uid; ?>"><i style="font-weight:400;"  class="fa fa-heart"></i></button>
<!--<button onclick="return false;" id="loadCommentModalParent"  data-postername="<?php echo $uname; ?>" data-pid="<?php echo $pid; ?>" data-uid="<?php echo $uid; ?>" data-action="comment" ><i class="fa fa-comments" ></i><span class="no_of_comments" ></span></button>-->
<button id="fl_rtwt_btn" data-pid="<?php echo $pid; ?>" data-who="<?php echo $uid; ?>"><i style="font-weight:1000;"  class="fa fa-retweet" ></i></button>

</div>
</div>


<div class="comment_log" >
<div style="margin:auto;" class="card-header" >
<div style="margin:50% auto;" class="avatar" >
<img src="./img/loader.gif" >
</div>
</div>
</div>
</div>


<div class="comment_btn" >
<button id="parent-comment-btn" data-postername="<?php echo $uname; ?>" data-pid="<?php echo $pid; ?>" data-uid="<?php echo $uid; ?>" data-action="comment" ><i class="fa fa-comments" ></i></button>
</div>

<script type="text/javascript">
$(document).ready(function(){

var sessImg;

var page = {
uname:"<?php echo $uname; ?>",
uid:"<?php echo $uid; ?>",
pid:"<?php echo $pid; ?>"
};




$.load.loadWeComments = function(){

var data = {
fetchTweet: true,
uname:"<?php echo $uname; ?>",
uid:"<?php echo $uid; ?>",
pid:"<?php echo $pid; ?>",
sid:"<?php echo $sid; ?>"
};

$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
data:data,
success:function(data){
var d = data;
var data = data[0];
var rows = data;
//alert(data.feedPic)

var pp = "";

for(var e in data.feedPic){

addCssOf = (rows.feedPic.length == 3)?e:3;
if((addCssOf != 3 && addCssOf != 0 && addCssOf != 2) || rows.feedPic.length > 3){
addCssOf = '';
}
addCssOf = (rows.feedPic.length == 2)?'':addCssOf;


pp += '<div class="img-responsive card_'+addCssOf+'" onclick="return $.load.loadImageModal({src:\'../uploads/feeds/'+rows.feedPic[e]+'\'});" style="background-image:url(\'../uploads/feeds/'+rows.feedPic[e]+'\');"></div>';

}

//alert(pp)

sessImg = "../uploads/profile/"+data.sessImg;

container("div.icon").prop("src", "../uploads/profile/"+data.profilePic);
container("div.info").html(data.fullName+' <font style="font-size:smaller;color:#aaa;font-weight:500;"> • @'+data.userName+' • '+data.date+'</font>');


var t = $.load.urlify(nl2br(data.text));

container("div.body").html(t); //t+"<br>"+atTag.join("<br>"));

if(data.tmp_pic !== "") $("div.body.parent").append('<div class="attachment" >'+pp+'</div>');

},
error:function(xhr, textStatus){

$("#_body_").html($.load.reload());     

}

});
}



$.load.retrieveComment = function(){


var data = {
fetchTweetComment: true,
uname:"<?php echo $uname; ?>",
uid:"<?php echo $uid; ?>",
pid:"<?php echo $pid; ?>",
limit:'LIMIT 5',
};

var rows;
var p = "";
var count_actions = "";
$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
data:data,
beforeSend:function(){
//$("#_body_").html(showLoader());
},
success:function(data){
//alert(data)
if(data.length < 1){
$(".comment_log").html("<h1 style='margin:25% auto;text-align:center;color:#aaa;'>No comments</h1>");
}

for(var i = 0; i < data.length; ++i){
var evt = {
evt_type:'loadReplies',
data:{
commentdate:data[i].time,
commenterid:data[i].sid,
commentid:data[i].id,
target:data[i].id,
},
};

rows = data[i];

p += '<div class="xx" >';
p += '<div style="background-image:url(\'./uploads/profile/'+rows.commenter_pic+'\');" class="xxi" ></div>';
p += '<div class="xxp-c" >';
p += '<h3 class="xxp" ><b><a href="">'+rows.commenter_fullName+'<font color="#aaa"> @'+rows.commenter_userName+'</font></a><i style="color:#aaa;"> • '+rows.time+'</i></b> <span>'+rows.comment_text+'</span></h3>';
p += '<span class="xxbb" >';
p += '<button> <i class="fa fa-heart" ></i></button>';
p += '<button id="loadCommentModal" data-commenterid="'+rows.commenter_id+'" data-sspic="'+sessImg+'" data-parentid="'+rows.id+'" data-postername="'+rows.commenter_userName+'" data-pid="<?php echo $pid; ?>" data-uid="<?php echo $uid; ?>" data-action="reply" >';
//p += '<button><i class="fa fa-comment" ></i></button>';
p += rows.noOfReplies+' • <i class="fa fa-comment" ></i></button>';
p += '<button><i class="fa fa-retweet" ></i></button>';
p += '<button id="loadCommandForComments"><i class="fa fa-ellipsis-v" ></i></button>';
p += '</span>';
p += '<div class="xcxc" >'+$.load.smallComments(data[i].fReplies, evt)+'</div>';
p += '</div></div>';


/*p += '<div class="card c" >';
p += '<div class="card-header" >';
p += '<div class="icon" ><img src="../uploads/profile/'+data[i].commenter_pic+'" ></div>';
p += '<div class="info" >';
p += '<p>'+data[i].commenter_fullName;
p += '<font style="font-size:smaller;color:#aaa;font-weight:500;">';
p += '<b> • @'+data[i].commenter_userName+' </b></font>';
p += '<font style="font-size:smaller;color:#aaa;font-weight:500;"> • '+data[i].time+'</font>';
p += '</p></div>';
p += '<button name="commandbox" class="toggler" ><i class="fa fa-angle-down" ></i></button>';
p += '</div>';
p += '<div class="body child" >';
p += '<p class="text" >'+data[i].comment_text+'</p>';

p += $.load.smallComments(data[i].fReplies, evt);

p += '<div class="att" >';
//<!--<img src="../img/pp7.gif" >-->
p += '</div>';
//p += '<button class="control" onclick="$.load.loadReplies(this);" data-commentdate="'+data[i].time+'" data-commenterid="'+data[i].sid+'" data-commentid="'+data[i].id+'">replies</button>';
p += '</div>';
//p += '<button class="control" onclick="$.load.loadReplies(this);" data-commentdate="'+data[i].time+'" data-commenterid="'+data[i].sid+'" data-commentid="'+data[i].id+'">replies</button>';
p += '<div class="footer" >';
p += '<button><i class="fa fa-thumbs-up" ></i></button>';
p += '<button id="loadCommentModal" data-commenterid="'+data[i].commenter_id+'" data-sspic="'+sessImg+'" data-parentid="'+data[i].id+'" data-postername="'+data[i].commenter_userName+'" data-pid="<?php echo $pid; ?>" data-uid="<?php echo $uid; ?>" data-action="reply" >';
p += '<i class="fa fa-comment" ></i> • '+data[i].noOfReplies;
p += '</button>';
p += '<button id="fl_rtwt_btn" data-pid="" data-who=""><i style="font-weight:1000;"  class="fa fa-retweet" ></i></button>';
p += '</div></div>';
*/
}

$("button#parent-comment-btn").html("<i class='fa fa-comments' > <font style='font-weight:1000;font-size:small;'>"+data[0].no_of_comments+"</font></i>");

if(data[0] !== ""){
$(".comment_log").html(p);
}


$.load.replySystem("button#loadCommentModal", function(arg){
$("#_body_").append(arg);
});


$("button#loadCommandForComments").click(function(){
var href = "../profile";
var _this = $(this);
$.load.animate(_this,'bounceIn');
var params = [
{title:"Abc",href:href,fa:"<i class='fa fa-share _obj_commands'></i>"},
{title:"Flag",href:href,fa:"<i class='fa fa-flag _obj_commands'></i>"},
{title:"sendPM",href:href,fa:"<i class='fa fa-comment _obj_commands'></i>"},
{title:"Inquire",href:href,fa:"<i class='fa fa-exclamation-triangle _obj_commands'></i>"},
];
var modal_object = {href:href,params:params};
var modal = $.load.LoadModal(modal_object);
$(document.body).append(modal);
});


},
error:function(xhr, textStatus){
//alert("Error fetching data: "+textStatus);
}

});
}

setInterval(function(){
$.load.retrieveComment();
}, 5000);

$.load.retrieveComment();

$.load.loadWeComments();



$("button#parent-comment-btn").on("click", function(){
  var btn = $(this);
  btn.addClass("animated bounceIn faster");
  var who = (btn.data("uid") == "<?php echo $_SESSION['id']; ?>")?"your ":"@"+btn.data("postername");   
  
  var objInfo = {
  sessImg : sessImg,
  params :{
  pid:btn.data("pid"),
  uid:btn.data("uid"),
  action:(btn.data("action")=="reply")?"replying to "+who+" comment":"comment on "+who+" post",
  name:btn.data("postername")
  }
  };
  
  var commentBox = $.load.loadCommentModal(objInfo);
  $(document.body).append(commentBox);
   btn.on("animationend", function (){
   btn.removeClass("animated bounceIn faster");
    });
  });  
  
 function container(t){
  return $(t).children(":first");
 } 
  
  
  
function nl2br(str, is_xhtml) {   
    var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';    
    return (str + ' ').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1'+ breakTag +'$2');
}
  
  
  
  function getHasTagAry( msgTxt, finder ) {     
  var msgTxtAry = msgTxt.split(' ') || msgTxt.split('');
  var hash = []
  for(var i = 0; i < msgTxtAry.length; i++) {
  if( msgTxtAry[i].indexOf(finder) > -1 )
  hash.push(msgTxtAry[i].trim());
  }
  return hash;
  }    
  
var currentLoc = $(window.location).attr("href");
var openReplyModal = currentLoc.split("#").pop();
var id = "<?php echo $_GET['ccidfn']; ?>";
var sid = "<?php echo $_GET['ssidfn']; ?>";
var date = "<?php echo $_GET['ddfn']; ?>";
if(openReplyModal == "true"){

   $.load.loadReplies(null, {
   id:id,
   sid:sid,
   date:date
   });
 }

function showLoader(){
var _node = '<div class="modal loader" >';
 _node += '<div class="loader-console" >';
 _node += '<div class="outer" >';
 _node += '<div class="inner" ></div>';
 _node += '</div></div></div>';
return _node;
}


$("button#loadCommandForParent").click(function(){
var href = "../profile";
var _this = $(this);
$.load.animate(_this,'bounceIn');
var params = [
{title:"Abc",href:href,fa:"<i class='fa fa-share _obj_commands'></i>"},
{title:"Flag",href:href,fa:"<i class='fa fa-flag _obj_commands'></i>"},
{title:"sendPM",href:href,fa:"<i class='fa fa-comment _obj_commands'></i>"},
{title:"Inquire",href:href,fa:"<i class='fa fa-exclamation-triangle _obj_commands'></i>"},
];
var modal_object = {href:href,params:params};
var modal = $.load.LoadModal(modal_object);
$(document.body).append(modal);
});


$('button.showEvent').on('click',function(){
btn = $(this);
var data = {
title:btn.data('title'),
uid:6,
sid:9,
load:'',
};
$.load.animate(btn, "bounceIn");
$(document.body).append($.load.userEvent(data));
});



$('button#fl_rtwt_btn').on('click',function(){
btn = $(this);
$.load.animate(btn, "bounceIn", function(){
btn.css("color","pink");
});
var pid = btn.data("pid");
var who = btn.data("who");
$.getJSON('../checkpoint/server.post_content.php',{fetchRetweetedPosts:true,pid:pid,who:who}).done(function(data){
$.load.share(data,{pid:pid,who:who});
});
});


$('button#fl_like_btn').on('click',function(){
btn = $(this);
$.load.animate(btn, "bounceIn", function(){
btn.css("color","red");
});
var pid = btn.data("pid");
var who = btn.data("who");
$.ajax({
url: "./checkpoint/server.post_content.php",
type: "post",
dataType: "json",
data: {actionOnPost:"liked",pid:pid, who:who},
success: function(data){
if(data.postLikes == null){
return false;
}
$("#like_count").text(data.postLikes+' • liked');
//btn.children(":first").text(" • "+data.postLikes);
},
error: function(error){
//alert("Could not load data. Please try again");
}
});
});


//$('#pageTitle').before('<button class="goBack" onclick="history.go(-1)"><i class="fa fa-arrow-left" ></i></button>')
$("#pageTitle").text("Comments");
});

</script>


</body>

</html>