
<div id="_card_2" ></div>
<div id="_card_3" ></div>
<div id="_card_4" ></div>
<div id="_card_5" ></div>

<script type="text/javascript">
$(document).ready(function(){
//Suggestion

var params;

params = {
title:'Based on your location',
limit:'LIMIT 5'
};
$.load.suggestion_card_inline(params, function(cards){
$("#_card_2").html(cards);
});


params = {
title:'Because you follow Chioma',
limit:'LIMIT 5'
};
$.load.suggestion_card_inline(params, function(cards){
$("#_card_3").html(cards);
});

params = {
title:'Because you follow Abdulkareem',
limit:'LIMIT 5'
};
$.load.suggestion_card_inline(params, function(cards){
$("#_card_4").html(cards);
});

params = {
title:'Suggested for you',
limit:'LIMIT 5'
};
$.load.suggestion_card_inline(params, function(cards){
$("#_card_5").html(cards);
});


});
</script>