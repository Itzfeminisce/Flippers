
<div class="cont animated slideInRight faster" >
<h1>Profile settings</h1>


<div class="info settings" >
<h1><i class="fa fa-check-circle" ></i>Upgrade membership</h1>
<span>
<p>Upgrade to premium to enjoy full features on realmeet. Find out more...</p>
<button id="market" data-href="../market">Goto Market</button>
</span>
</div>




<div class="info settings" >
<h1><i class="fa fa-wrench" ></i>Edit basic info</h1>
<span>
<p>Edit your profile informations</p>
<button id="editProfile" data-href="../edit-profile">Edit</button>
</span>
</div>



<div class="info settings" >
<h1><i class="fa fa-lock" ></i>Blocked users</h1>
<span>
<p>Blocked users won't be able to chat or read your feeds</p>
<button>Edit</button>
</span>
</div>


<div class="info settings" >
<h1><i class="fa fa-envelope" ></i>Email</h1>
<span>
<p>Activate your registered email to avoid been disabled</p>
<button>Verify</button>
</span>
</div>



<div class="info settings" >
<h1><i class="fa fa-eye" ></i>Manage Settings</h1>
<span>
<p>Set who sees your feeds, online status, pictures etc.</p>
<button data-href="/account/manage"><i class="fa fa-chevron-right" ></i></button>
</span>
</div>



<div class="info settings" >
<h1><i class="fa fa-chevron-right" ></i>Go for break</h1>
<span>
<p>You will be signed out of this account</p>
<button id="signout" >Sign out</button>
</span>
</div>

<div class="info settings" >
<h1><i class="fa fa-power-off" ></i>Account Deactivation</h1>
<span>
<p>Your account will be deleted permanently</p>
<button>Deactivate</button>
</span>
</div>
</div>

<script type="text/javascript">
$(document).ready(function(){

var url = "../checkpoint/server.post_content.php";

$("button#signout").click(function(e){
e.preventDefault();
var arg1 = "Do you want to log out of this account?";
var arg2 = "Sign Out!";
triger(arg1,arg2, function(){
$.getJSON(url,{signoutUser:true},function(data){
if(data.signedout){
location.href="../signin?res=You+are+signed+out";
}
});
});
});



function triger(arg, text, callback){
var obj = {
arg : arg,
text:text,
action: callback
}
var confirmModal = $.load.confirm(obj);
$(document.body).append(confirmModal);
};



$("button:not(#signout,#market)").click(loadPage);


$("button#market").click(function(){
location.href = $(this).data('href');
});


function loadPage(){
  $.ajax({
        url: $(this).data("href"),
        success: function (data) {
          $('#_body_').html(data);
        }
    });
    if ($(this).data("href") != window.location) {
        window.history.pushState({ path: $(this).data("href") }, '', $(this).data("href"));
    }
    return false;
}

});
</script>