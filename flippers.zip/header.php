<?php ob_start(); session_start();

if(!isset($_SESSION["id"])){
//header("location: ../signin?q=Logged out");
}


?>
<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="utf-8" />
<meta id="theme-color" name="theme-color" content="#FFFFFF" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="#08A8B8" />
<meta name="apple-mobile-web-app-title" content="Flippers" />
<meta name="fomat-detection" content="telephone=no" />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0,viewport-fit=cover" />
<link rel="apple-touch-icon" href="/icons/flip-eagle.png" >
<link rel="shortcut icon" href="/icons/flip-eagle.png" >
<!--<meta name="apple-web-app-capable" content="yes" />-->


<!-- Startup configuration -->

<link rel="manifest" href="manifest.json" />

<!-- Fallback application metadata for legacy browsers -->
<meta name="application-name" content="Flippers">
<link rel="icon" sizes="16x16 32x32 48x48" href="./icons/flip-eagle.png">
<link rel="icon" sizes="512x512" href="./icons/flip-eagle.png">






<link href="../animate/animate.css" rel="stylesheet" />

<link href="../styles/fa/css/all.css" rel="stylesheet" />
<link href="../styles/index-files.inc.css" rel="stylesheet" />
<link href="../styles/main.min.css" rel="stylesheet" />
<link href="./styles/login.min.css" rel="stylesheet" />
<!--<link href="https://rawgit.com/mervick/emojionearea/master/dist/emojionearea.css" rel="stylesheet" />-->
<link href="https://fonts.googleapis.com/css?family=Helvetica|Open+Sans&display=swap" rel="stylesheet">
<!--<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">-->
</head>
<body>
<div class="_main_" >

<div style="visibility:hidden;" class="_header_ _flex_row" >
<input id="session-id" type="hidden" value="<?php echo $_SESSION["id"]; ?>" >
<h1 id="pageTitle"  class="large_txt" ></h1>
<button style="visibility:hidden;" id="notifier-bell" class="" data-title="Notification" data-destination="notification" data-href="../notification" ><i class="fa fa-bell" ></i><span class="animated fadeInRightBig faster notifier" id="NotificationCount"></span></button>
<button id="notifier-bell-after" ><i class="fa fa-angle-down" ></i></button>
</div>





<script type="text/javascript">
setInterval($.load.getUnreadNotification, 500);

</script>