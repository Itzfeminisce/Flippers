<?php
session_start();
include_once "../header.php";
include_once "../includes/Handler.class.php";
$main = new Maintenance($_SESSION["id"]);

?>
<style type="text/css">
.m-bg {
position:fixed;
height:100%;
width:100%;
top:0;left:0;right:0;bottom:0;
background-position:center;
background-repeat:no-repeat;
background-size:cover;
background-color:#204088;
background-attachment:fixed;
overflow:hidden;
overflow-y:scroll;
display:flex;
flex-flow:column wrap;
padding:10px;
}

.m-bg::-webkit-scrollbar {
width:0px;
display:none;
}

.ixcc{
width:100%;
height:auto;
background-color:rgba(0,0,0,.08);
margin:0 auto;
}

.ixcc h1{
text-align:center;
font-size:large;
font-family:'Helvetica',sans-serif;
color:#FFF;
}

</style>
<div style="background-image:url('../icons/flip-eagle-fill.png');" class="m-bg" >
<div class="ixcc" >
<h1>Welcome to our Market place</h1>
</div>
</div>