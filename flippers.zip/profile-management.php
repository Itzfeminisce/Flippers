<style type="text/css">

.album div{
height:auto;
width:auto;
padding:0;
margin:0;
background:#eee;
}

.album div img{
height:auto;
width:100%;
min-height:300px;
max-height:400px;
padding:0;
margin:0;
border-radius:10px;
}

.aboutInput, .aboutInput + button {
padding:5px;
border:1px solid #aaa;
background:#eee;
border-radius:5px;
margin:5px;
}
.aboutInput {
width:70%;
}
.control_container {
padding:5px;
text-align:center;
display:flex;
flex-wrap:nowrap;
width:100%;
}
.control_container > p{
width:100%;
display:block;
color:#aaa;
}
.hide{
display:none;
}

.cont  h1 button {
float:right;
padding:5px;
background:transparent;
border:none;
color:#aaa;
}
</style>

<div class="cont animated slideInRight faster" > 
<h1>About me <button id="collapseAll" ><i class="fa fa-chevron-down" ></i></button></h1>

<div class="info" >
<h1><i class="fa fa-location-arrow" ></i>Location</h1>
<span>
<p id="countryState" >•••</p>
<button class="cs"  ><i class="fa fa-pen" ></i></button>
</span>
<div class="control_container" >
<!--<p>You can only change your present location.</p>-->
<input class="aboutInput CURRENT_LOCATION" data-name="presentLocation" type="text" placeholder="Tap to write" disabled="disabled"  >
<button class="UPDATE_BUTTON" disabled="disabled" >Update</button>
</div>
</div>



<div class="info" >
<h1><i class="fa fa-user" ></i>Gender</h1>
<span>
<p class="gender" >•••</p>
<button class="cs" ><i class="fa fa-pen" ></i></button>
</span>
<div class="control_container" >
<input class="aboutInput gender" data-name="gender" type="text" placeholder="Tap to write" disabled="disabled" >
<!--<select class="aboutInput gender" data-name="gender" >
<option value="male" selected="selected">Male</option>
<option value="female" >Female</option>
<option value="other" >Other</option>
</select>-->
<button class="UPDATE_BUTTON" disabled="disabled" >Update</button>
</div>
</div>


<div class="info" >
<h1><i class="fa fa-user" ></i>Ethnicity</h1>
<span>
<p class="ethnic" >•••</p>
<button class="cs" ><i class="fa fa-pen" ></i></button>
</span>
<div class="control_container" >
<input class="aboutInput ethnic" data-name="ethnic" type="text" placeholder="Tap to write" >
<!--<select class="aboutInput ethnic" data-name="ethnic" >
<option value="male" >African</option>
<option value="caucasian" selected="selected" >Caucasian</option>
<option value="asian" >Asian</option>
<option value="filipino" >Filipino</option>
<option value="jamaica" >Jamaica</option>
</select>-->
<button class="UPDATE_BUTTON" >Update</button>
</div>
</div>


<div class="info" >
<h1><i class="fa fa-graduation-cap" ></i>Occupation</h1>
<span>
<p class="occupation" >•••</p>
<button class="cs" ><i class="fa fa-pen" ></i></button>
</span>
<div class="control_container" >
<input class="aboutInput occupation" data-name="occupation" type="text" placeholder="Tap to write" >
<button class="UPDATE_BUTTON" >Update</button>
</div>
</div>

<div class="info" >
<h1><i class="fa fa-eye" ></i>Interested in</h1>
<span>
<p class="lookingFor" >•••</p>
<button class="cs" ><i class="fa fa-pen" ></i></button>
</span>
<div class="control_container" >
<input class="aboutInput lookingFor" data-name="lookingFor" type="text" placeholder="Tap to write" >
<!--<select class="aboutInput lookingFor" data-name="lookingFor" >
<option value="male" selected="selected">Male</option>
<option value="female" >Female</option>
<option value="other" >Other</option>
</select>-->
<button class="UPDATE_BUTTON" >Update</button>
</div>
</div>

<div class="info" >
<h1><i class="fa fa-fire" ></i>Smoking</h1>
<span>
<p class="smoking" >•••</p>
<button class="cs" ><i class="fa fa-pen" ></i></button>
</span>
<div class="control_container" >
<input class="aboutInput smoking" data-name="smoking" type="text" placeholder="Tap to write" >
<button class="UPDATE_BUTTON" >Update</button>
</div>
</div>

<div class="info" >
<h1><i class="fa fa-coffee" ></i>Drinking</h1>
<span>
<p class="drinking" >•••</p>
<button class="cs" ><i class="fa fa-pen" ></i></button>
</span>
<div class="control_container" >
<input class="aboutInput drinking" data-name="drinking" type="text" placeholder="Tap to write" >
<button class="UPDATE_BUTTON" >Update</button>
</div>
</div>

<!--
<div class="info" >
<form>
<h1><i class="fa fa-bio" ></i>Bio</h1>
<span>
<p>Tell your friends about you...</p>
<button><i class="fa fa-pen" ></i></button>
</span>
</form>
</div>
-->

<div class="info" >
<h1><i class="fa fa-comment" ></i>Personal Quote</h1>
<span>
<p class="quote" >•••</p>
<button class="cs" ><i class="fa fa-pen" ></i></button>
</span>
<div class="control_container" >
<input class="aboutInput quote" data-name="quote" type="text" placeholder="Tap to write" >
<button class="UPDATE_BUTTON" >Update</button>
</div>
</div>




</div>


<!-- USER CARD -->
<!--<center><font style="text-align:center;font-family:cursive;"> You're all caught up😇</font></center>-->
<!--<div style="box-shadow:none;height:50px;border:none;background:#fff;" class="main-round-card" ></div>-->
<!-- USER CARD ENDS -->

<script type="text/javascript">
$(document).ready(function(){

$('div.control_container').hide();

var rdruid = "<?php echo $_GET['rdrid']; ?>";


var loadInfo = function(){

$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
data:{loadProfile:rdruid},
success:function(data){
//...
//alert(data)
var r = data[0];
//SET_VALUE(data.name,data.value);

$("#countryState").text(r.country+", "+r.state);
$(".gender").html(ucfirst(r.gender));
$(".ethnic").html(ucfirst(r.ethnic));
$(".occupation").html(ucfirst(r.occupation));
$(".lookingFor").html(ucfirst(r.lookingFor));
$(".smoking").html(ucfirst(r.smoking));
$(".drinking").html(ucfirst(r.drinking));
$(".quote").html(ucfirst(r.quote));




},
fail:function(xhr, textStatus){
//...
alert(textStatus)
}
});
};




loadInfo();

$('#collapseAll').click(()=>{$('div.control_container').hide('fast'); });
$('button.cs').on('click',function(e){
$('div.control_container').hide('fast');
$(this).parent().next().show('fast');
});

$('button.UPDATE_BUTTON').on('click',function(e){
UPDATE_DATA($(this));
e.preventDefault();
});


function UPDATE_DATA(_this){
this.btn = _this;
this.name = this.btn.prev().data('name');
this.value = this.btn.prev().val().trim();
if(this.value.length < 1) 
return;
else
this.data = {
request:'updateUserData',
name: this.name,
value:this.value
};
$.getJSON($.load.server(),this.data)
.done(function(data){
if(data.done){
SET_VALUE(data.name,data.value);
_this.prev().val('');
_this.parent().hide();
$.load.notification({msg:data.msg},function(c){
		setTimeout(function(){
		c.addClass('animated slideOutUp');
	    div.hide();			
		}, 5000);
		});
}else{
$.load.notification({msg:data.msg},function(c){
		setTimeout(function(){
		c.addClass('animated slideOutUp');
	    div.hide();			
		}, 5000);
		});
}
})
.fail(function(error){
alert(error)
});
return;
}


function SET_VALUE(name,text){
$('p.'+name).html(text);
//$('input.'+name).data('value',text);
//$('select.'+name).data('value',text);
}


function ucfirst(str){
var str = str.toLowerCase().replace(/\b[a-z]/g, function(letter) {
    return letter.toUpperCase();
});
return str;
}

});
</script>