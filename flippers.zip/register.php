<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="utf-8" />
<title>Flippers - Create an account</title>
<meta id="theme-color" name="theme-color" content="#fff" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="#08A8B8" />
<meta name="apple-mobile-web-app-title" content="Flippers" />
<meta name="fomat-detection" content="telephone=no" />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0,viewport-fit=cover" />
<link rel="apple-touch-icon" href="/icons/flip-eagle.png" >
<link rel="shortcut icon" href="/icons/flip-eagle.png" >
<!--<meta name="apple-web-app-capable" content="yes" />-->


<!-- Startup configuration -->

<link rel="manifest" href="manifest.json" />

<!-- Fallback application metadata for legacy browsers -->
<meta name="application-name" content="Flippers">
<link rel="icon" sizes="16x16 32x32 48x48" href="./icons/flip-eagle.png">
<link rel="icon" sizes="512x512" href="./icons/flip-eagle.png">
<link href="./animate/animate.css" rel="stylesheet" />
<link href="./styles/fa/css/all.css" rel="stylesheet" />
<link href="./styles/index-files.inc.css" rel="stylesheet" />
<link href="./styles/main.min.css" rel="stylesheet" />
<link href="./styles/login.min.css" rel="stylesheet" />
<!--<link href="https://rawgit.com/mervick/emojionearea/master/dist/emojionearea.css" rel="stylesheet" />-->
<link href="https://fonts.googleapis.com/css?family=Helvetica|Open+Sans&display=swap" rel="stylesheet">
<!--<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">-->

</head>
<body class="body" >

<!--<img class="bg-image" src="./img/pp7.jpeg"  >-->
<div class="bg-container" >
<div class="bg-console" >
<h1 class="animated slideInRight" >Flippers</h1>
<div class="bg-login-box" >
<fieldset class="animated bounceIn" >
<legend>Join the community!</legend>
<form>
<h1 class="animated slideInDown faster"></h1>
<!--<input name="uname" type="text" id="uname" placeholder="Email/username"  >-->
<div class="nextFormContainer" >
<p class="animated slideInLeft faster">What's your gender? </p>
<select class="animated slideInRight faster" name="gender" >
<option value="male" >Male</option>
<option value="female" >Female</option>
<option value="others" >Others</option>
</select>
</div>
<!--<input name="pwd" type="password" id="pwd" placeholder="Password"  >-->
<button style="margin:20px auto;" class="animated slideInUp faster" name="proceed" >Next</button>
</form>
<p class="creat-account" >Already a member? <a href="./signin" rel="index follow" >Sign in!</a> <span><a href="/" >Report an issue?</a></span></p>
</fieldset>
<br>
<div class="bg-more animated bounceInUp" >
<h1>By signing up, you agree to the <a href="tnq" >terms and condition</a> of this website.</h1>
</div>
</div>
</div>


</div>




<script src="./script/jquery.js"></script>
<script src="./script/Handler.Java.js"></script>
</body>

</html>