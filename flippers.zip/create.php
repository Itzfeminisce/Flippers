<?php ob_start(); session_start();

include_once "./includes/Handler.class.php";

$main = new Maintenance($_SESSION["id"]);

?>
<style type="text/css">
#_body_{
background:white;
}
</style>
<form class="post-form" name="postForm" action="?" method="get">
<p id="warning" ></p>
<div class="text-field" >
<div class="text-input-field" >
<textarea name="post-content"  class="post-box" rows="" cols="" placeholder="How's your day going?"  ></textarea>
<span class="word-counter" >0/250</span>
</div>
</div>
<button name="post_content_btn"  type="submit" class="post-btn" >
Post<i class="fa fa-paper-plane" ></i>
</button>
</form>


<div class="upload-preview" >
<form action="?"  name="bind-attachment" method="post"  enctype="multipart/form-data" >
<div class="att-field" >


<input class="file-input-input" type="file" name="files[]" multiple="multiple" >

<button name="preload-btn" class="file-input-btn" >
<!--<i class="fa fa-image" ></i>-->
<svg width="100px" height="100px" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg" version="1.1">
 <path style="fill:#eee;fill-opacity:1.0;stroke:none;stroke-width:0.5;stroke-opacity:1.0" d="M10 20 V40 H30 V20 Z"/>
 <path style="fill:#08a8b8;fill-opacity:1.0;stroke:none;stroke-width:0;stroke-opacity:1.0" d="M10 40 V33 L15 29 L16 37 L21 28 L22 34 L26 28 L30 31 V40 Z"/>
 <path style="fill:#08a8b8;fill-opacity:1.0;stroke:none;stroke-width:0;stroke-opacity:1.0" d="M25 23 H26 V24 H27 V23 H28 V22 H27 V21 H26 V22 H25 Z"/>
</svg>
</button>
<div class="upload_btn_btn" >
<span>
<button><i class="fa fa-times" ></i></button>
</span>
</div>
</div>
</form>
<div class="upload-preview-box" style="border:none;float:;"  ></div>
</div>


<!--<div id="showTags" class="xxmc" >
<div class="xxmh" >
<div class="xxmi" ></div>
<p class="xxmp" >hello world</p>
</div>
</div>-->

<script type="text/javascript">
$(document).ready(function(){
$('#pageTitle').text('Create a flip');
wordCount(".post-box", ".word-counter");
uploadPost(".file-input-btn", ".file-input-input");
function uploadPost(button, fileInput){
$(button).on("click",(e)=>{
e.preventDefault();
$(fileInput).click();
});
}
var wordCount_ = 0;
var maxWordCount = 250;
var extra = 0;
var formData = new FormData(); 
function wordCount(textContainer, indicator){
$(textContainer).on("keyup", function(){
extra += 2;



var fontSize = $(textContainer).css("fontSize").replace("px", '');
var textCount = $(textContainer).val().length;
if(textCount >= maxWordCount){
$(indicator).css({color:"red"});
}else if(textCount <= maxWordCount){
$(indicator).css({color:""});
}
if(textCount > 100 && textCount < 120){
$(textContainer).css({fontSize: (fontSize - ((fontSize / 100) * 2))+"px"});
}
if(textCount > 160 && textCount < 180){
$(textContainer).css({fontSize: (fontSize - ((fontSize / 100) * 2))+"px"});
}
wordCount_ = textCount;
extra = maxWordCount - wordCount_;
extra = (extra > 0)?0:extra;
$(indicator).html(textCount+"/250("+extra+")");
});
}
var fileSize = [];
function getFile(file){
$(file).change(function () {
        var imgPath = this.value;
        var ext = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
        if (ext == "gif" || ext == "png" || ext == "jpg" || ext == "jpeg" || ext == "mp4")
          return  readURL(this, ext);
        else
            alert("Please select image file (jpg, jpeg, png).")
    });
    function readURL(input, ext) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.readAsDataURL(input.files[0]);
            reader.onload = function (e) {
            fileSize.push(e.target.result);
            formData.append("post_files[]", input.files[0]);
            if(ext == "mp4"){
            $(".upload-preview-box").prepend('<video width="100" height="100" class="animated bounceInLeft" controls><source src="'+e.target.result+'" type="video/mp4"><video>');
            }else{
             $('.upload-preview-box').prepend("<img src='"+e.target.result+"' width='100' class='animated bounceInLeft' height='100' style='border-radius:5px;margin:auto 5px;'>");
            }
           };
        }
    }
}
getFile("input[type='file'][multiple]");
$("form[name='postForm']").on("submit", function(e){
e.preventDefault();
var form = $(this);
var formBtn = $(this).children(":last-child");
var text_ = $("textarea[name='post-content']");
var text = text_.val();
if(wordCount_ >= maxWordCount) return false, alert("NB: 250 characters exceeded!");
formData.append("content", text);
formData.append("createFeeds", true);
if((text == "") && (fileSize.length < 1)){
$(document.body).css({background:"rgba(255,0,0,.05)"});
setTimeout(function(){
$(document.body).css({background:""});
}, 1000);
return false;
}
if(fileSize.length > 4){
alert("Maximum of 4 files is allowed. Please adjust and try again.");
return false;
}
var fBtnHtml = formBtn.html();
$.ajax({
url:"../checkpoint/server.post_content.php",
type:"POST",
dataType:"json",
contentType:false,
cache:false,
processData:false,
beforeSend: function(){
formBtn.html("<i class='fa fa-hourglass-half animated bounceInUp faster'></i>");
formBtn.attr("disabled", "disabled");
},
data: formData,
success:function(data){
//alert(data)
if(data.status){
formBtn.html("<i class='fa fa-check animated bounceInUp faster'><br>Done!</i>");
text_.val("");
}else{
formBtn.html("<i style='color:red;font-size:10px;' class='fa fa-hourglass-half animated bounceInUp faster'><br>Failed!</i>");
}
setTimeout(function(){
formBtn.html(fBtnHtml);
formBtn.removeAttr("disabled");
}, 5000);
},
error:function(jxHQR, textStatus){
//alert(textStatus);
formBtn.html("<i class='fa fa-check animated bounceInUp faster'><br>Done!</i>");
setTimeout(function(){
formBtn.html(fBtnHtml);
formBtn.removeAttr("disabled");
}, 5000);
}
});
});
});
</script>