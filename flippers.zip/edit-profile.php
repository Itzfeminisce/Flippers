<?php ob_start(); session_start();
include_once "./includes/Handler.class.php";

$main = new Maintenance($_SESSION["id"]);
//print_r($main->data->uid);

?>

<style type="text/css">

.section1 {
display:flex;
flex-flow:row nowrap;
justify-content:flex-start;
align-content:flex-start;
align-items:center;
width:100%;
height:200px;
margin:10px auto;
background:white;
}
.section1 .icon {
width:150px;
height:150px;
border-radius:50%;
background:#eee;
margin:5px auto;
overflow:hidden;
border-top:5px solid transparent;
border-bottom:5px solid transparent;
border-right:5px solid transparent;
border-left:5px solid transparent;
box-shadow:0px 2px 10px #aaa;
display:block;
}

.section1 .icon img{
width:100%;
height:100%;
transition:100ms linear;
}

.section1 .icon img:active{
opacity:.5;
}
.section1 .other_info {
width:50%;
background:rgba(0,0,0,.5);
height:auto;
padding:5px;
border-radius:10px;
text-align:center;
display:none;
}

.section1 .other_info p{
font-weight:500;
font-size:medium;
color:white;
}

.line {
width:100%;
height:auto;
margin:10px auto;
padding:5px;
position:relative;
}

.line p{
font-weight:500;
color:#aaa;
}

.line input, .line textarea {
border:1px solid #eee;
border-radius:5px;
width:100%;
min-height:100px;
padding:5px 1px;
font-weight:400;
font-size:medium;
font-family:sans-serif;
text-overflow:break-word;
}


.line input::placeholder,
.line textarea::placeholder{
font-weight:300;
color:#aaa;
font-size:x-small;
padding:5px;
font-family:sans-serif;
}

.line span{
background:#08a8b8;
border-radius:3px;
padding:10px;
display:none;
position:absolute;
bottom:10px;
right:10px;
color:white;
}

.siteName h1 {
font-family:sans-serif;
color:black;
font-weight:400;
}
</style>

<div style="background:white;" class="edit-container animated slideInRight faster" >

<div style="
background:url('../img/pp4.jpeg');
 background-size:100%; 
 padding-top:10px;
 background-position:center;
 background-repeat:no-repeat;
 " id="wallpaper" >
<div class="section1" >
<div class="icon" >
<img class="hover" id="pp" src="../img/avatar1.jpeg" >
</div>
<div class="other_info" >
<p style="text-align:center;color:#aaa;padding-bottom:5px;" >BIO</p>
<div><p style="text-align:center;" >Welcome to RealMeet😇</p>
<br><br><br>
<p id="placeholder" style="text-align:center;color:rgba(255,0,255,.3);" >Loading information....</p>
</div>
</div>
<input style="display:none;"  type="file" id="file-input" name="profilePic">
</div>
</div>


<p id="ppErr" style="text-align:center;padding:5px;color:green;" ></p>
<div class="line">
<p>Full name</p>
<input class="hover" name="fullName" placeholder="Write your name in full..." >
<span class="submit" ><i class="fa fa-pen animated bounceIn" ></i></span>
</div>


<div class="line" >
<p>Bio</p>
<textarea class="hover" name="bio" placeholder="Write something about yourself..." ></textarea>
<span class="submit" ><i class="fa fa-pen  animated bounceIn" ></i></span>
</div>


<div class="line" >
<p>Social media links</p>
<input class="hover"  type="text"  name="socialLink" placeholder="Enter links separated by comma e.g https://mylink1.com, https://mylink2.com, ..." >
<span class="submit" ><i class="fa fa-pen  animated bounceIn" ></i></span>
</div>


<!--<div class="line" >
<p>Reset all fields</p>
<button class="clearFields" >Reset</button>
</div>-->


</div>







<script type="text/javascript">


$(document).ready(function(){

//alert();
$('#pageTitle').text('Edit profile');

var name, value, input, btn;
$("input, textarea").on("keyup", function(){
btn = $(this).next();
input = $(this);
word = $(this).val().length;
var btnTxt = btn.html();
if(($(this).val().trim().length > 0) && ($(this).val().length <= 200)){
$(this).next().show("fast");
$(this).css({borderBottom:""});
}else{
$(this).css({borderBottom:"2px solid red"});
$(this).next().hide("fast");
}


});


$("input, textarea").next().on("click", function(){
//alert(value);
var btn = $(this);
var btnTxt = btn.html();
name = $(this).prev().attr("name");
value = $(this).prev().val();
if($('input[name="socialLink"]').val().split(',').length > 3){
alert('Maximum of 3 websites is allowed.\nPlease adjust and try again.');
return false;
}
$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
beforeSend:function(){
btn.attr("disabled","disabled").html("•••");
},
data:{updateProfile:"<?php echo $_SESSION['id']; ?>", name:name,value:value},
complete:function(){
btn.html(btnTxt);
},
success:function(data){
//alert(data)
btn.html(data.msg);
btn.removeAttr("disabled");
setTimeout(function(){
//btn.html(btnTxt);
}, 3000);
},
fail:function(xhr, textStatus){
//...

$("#_body_").html($.load.reload());     

}
});

});

$("#pp").click(function(){
file.click();
});

var file = $("input[type='file']");
updateProfilePic(file);
function updateProfilePic(file){
var files;
var fdata = new FormData();
$(file).on("change", function (e) {
 files = this.files;
 $.each(files, function (i, file) {
 fdata.append("profilePic", file);
 });
 
/* fdata.append("FullName", "John Doe");
 fdata.append("Gender", "Male");
 fdata.append("Age", "24");
 */
 $.ajax({
 url: "../checkpoint/server.post_content.php",
 type: "post",
 data: fdata, //add the FormData object to the data parameter
 dataType:"json",
 processData: false, 
 contentType: false, //tell jquery not to set content-type
 beforeSend:function(){
 $("#pp").prop("src","../img/loader.gif");
 },
 success: function (response, status, jqxhr) {
 //handle success
 if(response.status){
  $("#pp").prop("src","../uploads/profile/"+response.file);
  $("#ppErr").text(response.msg);
  setInterval(function(){
  $("#ppErr").hide("fast");
  }, 3000);
 }else{
 $("#ppErr").text(response.msg);
 setInterval(function(){
 $("#ppErr").hide("fast");
 }, 3000);
 }
 },
 error: function (jqxhr, status, errorMessage) {
 //handle error
$("#_body_").html($.load.reload());     
 }
 });
 });

}

//var interval = setInterval(function(){
$(function(){
$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
data:{loadProfile:'<?php echo $_SESSION["id"]; ?>'},
success:function(data){
//...
var r = data[0];
$(".other_info").children(":nth-child(2)").html("<p>"+r.bio+"</p>");

$("input[name='fullName']").val(r.fullName);

$("textarea[name='bio']").val(r.bio);
$("input[name='socialLink']").val(r.socialLink);
$("#pp").prop("src","../uploads/profile/"+r.profilePic);
$("div#wallpaper").css("background-image","url('./uploads/profile/"+r.wallpaper+"')");
clearInterval(interval);
},
fail:function(xhr, textStatus){
$("#_body_").html($.load.reload());     
}
});
});
//}, 2000);


});
</script>