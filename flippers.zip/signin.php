<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="utf-8" />
<title>Flippers - Sign In</title>
<meta id="theme-color" name="theme-color" content="#fff" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="#08A8B8" />
<meta name="apple-mobile-web-app-title" content="Flippers" />
<meta name="fomat-detection" content="telephone=no" />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0,viewport-fit=cover" />
<link rel="apple-touch-icon" href="/icons/flip-eagle.png" >
<link rel="shortcut icon" href="/icons/flip-eagle.png" >
<!--<meta name="apple-web-app-capable" content="yes" />-->


<!-- Startup configuration -->

<link rel="manifest" href="manifest.json" />

<!-- Fallback application metadata for legacy browsers -->
<meta name="application-name" content="Flippers">
<link rel="icon" sizes="16x16 32x32 48x48" href="./icons/flip-eagle.png">
<link rel="icon" sizes="512x512" href="./icons/flip-eagle.png">
<link href="./animate/animate.css" rel="stylesheet" />
<link href="./styles/fa/css/all.css" rel="stylesheet" />
<link href="./styles/index-files.inc.css" rel="stylesheet" />
<link href="./styles/main.min.css" rel="stylesheet" />
<link href="./styles/login.min.css" rel="stylesheet" />
<!--<link href="https://rawgit.com/mervick/emojionearea/master/dist/emojionearea.css" rel="stylesheet" />-->
<link href="https://fonts.googleapis.com/css?family=Helvetica|Open+Sans&display=swap" rel="stylesheet">
<!--<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">-->

</head>
<body class="body" >

<style type="text/css">

button[name=fb-login],
button[name=g-login]{
background:#1946B5;
color:#fff;
padding:10px;
border-radius:10px;
border:none;
margin:10px auto;
display:block;
width:100%;
text-align:center;
font-weight:600;
box-shadow:#aaa 0 3px 5px 0;
}
button[name=g-login]{
background:red;
}
p.orliv{
text-align:center;
font-weight:400;
}
</style>




<div class="bg-container" >
<div class="bg-console" >
<br>
<img class="siteIcon" src="./icons/flip-eagle.png" >
<div class="bg-login-box" >
<fieldset class="animated bounceIn" >
<legend>Sign in</legend>
<form name="login" >
<p id="response" style="text-align:center;font-weight:300;" ></p>
<input class="animated slideInLeft faster hover" name="uname" type="text" id="uname" placeholder="Email/username"  >
<span></span>
<br>
<input class="animated slideInRight faster hover" name="pwd" type="password" id="pwd" placeholder="Password"  >
<span></span>
<br>
<button name="signin" value="signin" class="animated slideInUp faster hover">Let's go...</button>
</form>
<br>
<p class="orliv" > Or login via: </p>
<button name="fb-login" value="login" class="animated slideInUp faster hover">Facebook</button>
<button name="g-login" value="login" class="animated slideInUp faster hover">Google</button>
<p class="create-account" >Need an account <a href="../register" rel="index follow" >Create now!</a> 
<span><a href="/" >Forgot Password?</a></span>
</p>
<p id="pwdVisible" >Show password <i class="fa fa-eye" ></i></p>
</fieldset>
<br>
<div style="display:none;"  class="bg-more animated bounceInUp" >
<h1>Kindly read the <a href="tnq" >terms and condition</a> guiding the use of
this site.
You are to note that this website does not allow
person under the age of 18.
</h1>
</div>
</div>
</div>
</div>




<script src="./script/jquery.js"></script>
<script src="./script/Handler.Java.js"></script>

<script type="text/javascript">
$(document).ready(function(){


$("#pwdVisible").click(function(){
if($("input[name='pwd']").prop("type")==="password"){
$("input[name='pwd']").prop("type","text");
}else{
$("input[name='pwd']").prop("type","password");
}
});



$("form[name='login']").on("submit", function(event){
event.preventDefault();

var uname = $("input[name='uname']");
var pwd = $("input[name='pwd']");
var unameErr = uname.next();
var pwdErr = pwd.next();


if(uname.val() == ""){
uname.css({border:"0.5px solid red",background:"rgba(255,0,0,.09)"});
unameErr.text("Please enter your username")
.show("fast")
.addClass("animated", "slideInRight");
uname.focus();
return false;
}else{
unameErr.hide("fast");
uname.css({border:"",background:""});
}

if(pwd.val() == ""){
pwd.css({border:"0.5px solid red",background:"rgba(255,0,0,.09)"});
pwdErr.text("Please enter your password")
.show("fast")
.addClass("animated", "slideInRight");
pwd.focus();
return false;
}else{
pwdErr.hide("fast");
pwd.css({border:"",background:""});
}


$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
beforeSend:function(){
$("button[name='signin']").attr("disabled","disabled").text("redirecting...");
},
data:{accr:true,uname:uname.val(),pwd:pwd.val()},
success:function(data){
//alert(data)
$("button[name='signin']").removeAttr("disabled").text("Let's go...");
if(data.status){
$("#response").text(data.msg).css({color:"green"});
location.href = "./ng/main?b_cr=1";
}else{
$("#response").text(data.msg).css({color:"red"});
}
},
fail:function(xhr, textStatus){
$("#response").text('oops! looks like the server is busy right now. Please try again.').css({color:'red'});
}
});

});

});
</script>
</body>

</html>