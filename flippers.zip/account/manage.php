<?php
session_start();
include_once "../includes/Handler.class.php";
$main = new Maintenance($_SESSION["id"]);
$privacy = new Privacy($main->data->uid);

?>
<style type="text/css">
._0 {
padding:10px;
width:100%;
display:block;
background:#fff;
color:;
}

._0 h1{
font-size:small;
color:#aaa;
}

._1{
margin:20px auto;
}

._1.footer{
margin:20px auto auto 5px;
padding:10px;
text-align:center;
}

._1.footer h1, ._1.footer p{
font-size:small;
color:#aaa;
font-weight:400;
}
._1.footer p{
max-width:none;
max-height:none;
margin-top:5px;
}

._1 label {
font-size:small;
}

._1 label .fa{
font-size:larger;
width:40px;
height:40px;
padding:10px;
margin:auto 5px;
text-align:center;
}

._1 label + button {
background:transparent;
border:none;
float:right;
padding:5px 10px;
color:#aaa;
}
</style>
<div class="_0" >
<br>

<div class="_1" >
<label for="a"><i class="fa fa-bell" ></i>Notification</label>
<button id="a" ><i class="fa fa-chevron-right" ></i></button>
</div>

<div class="_1" >
<label for="b"><i class="fa fa-unlock-alt" ></i>Privacy</label>
<button id="b" data-href="manager/privacy.php"><i class="fa fa-chevron-right" ></i></button>
</div>


<div class="_1" >
<label for="c"><i class="fa fa-lock" ></i>Security</label>
<button id="c" ><i class="fa fa-chevron-right" ></i></button>
</div>


<div class="_1" >
<label for="e"><i class="fa fa-credit-card" ></i>Ads</label>
<button id="e" ><i class="fa fa-chevron-right" ></i></button>
</div>

<div class="_1" >
<label for="f"><i class="fa fa-users" ></i>Account</label>
<button id="f" ><i class="fa fa-chevron-right" ></i></button>
</div>

<div class="_1" >
<label for="g"><i class="fa fa-exclamation-triangle" ></i>Help</label>
<button id="g" ><i class="fa fa-chevron-right" ></i></button>
</div>


<div class="_1" >
<label for="h"><i class="fa fa-copyright" ></i>About</label>
<button id="h" ><i class="fa fa-chevron-right" ></i></button>
</div>


<div class="_1 footer" >
<h1>Flippers</h1>
<p>2020<sup>&copy;</sup> All Rights Reserved</p>
</div>

</div>


<script type="text/javascript">
$(document).ready(function(){
$('#pageTitle').text('Manage your account');



$("button").click(loadPage);



function loadPage(){
  $.ajax({
        url: $(this).data("href"),
        success: function (data) {
          $('#_body_').html(data);
        }
    });
    if ($(this).data("href") != window.location) {
        window.history.pushState({ path: $(this).data("href") }, '', $(this).data("href"));
    }
    return false;
}

});

</script>