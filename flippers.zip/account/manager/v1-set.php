<?php
session_start();
include_once "../.././includes/Handler.class.php";
$main = new Maintenance($_SESSION["id"]);

$request = $_GET["page"] ?? null;
?>
<style type="text/css">
._0 {
padding:10px;
width:100%;
display:block;
background:#fff;
}




.co_m {
width:100%;
height:200px;
display:block;
margin:auto;
border-radius:10px;
background-color:#eee;
background-image:url("../../../icons/story.png");
background-repeat:no-repeat;
background-position:center;
background-size:100% 100%;
}

.co_m_h {
padding:10px;
color:#aaa;
font-size:small;
font-weight:400;
}

h1 p{
padding:5px 0;
text-align:left;
color:#aaa;
}

      input[type="checkbox"], input[type="radio"] {
         display: none; /* hide the default check boxes and radios */
      }
      /* style the label elements */
      label {
         display: block;
         width: 100%;
         padding: 15px;
         //border: 1px solid #08a8b8;
         margin-bottom: 20px;
         //border-radius: 0px;
         font-size:medium;
         /box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.3), 0 7px 21px 0 rgba(0, 0, 0, 0.20);
      }
      /* create our custom checkbox and radio */
      label > span {
         display: inline-block;
         width: 20px;
         height: 20px;
         border: 3px solid #08a8b8;
        border-radius: 10px;
        margin-right: 30px;
        float:right;
        clear:left;
      }
      /* style the labels when their corresponding inputs are checked */
      input[type="checkbox"]:checked + label, input[type="radio"]:checked + label {
         //background: #173459;
         color: #08a8b8;
      }
      /* style the custom check boxes and radios when their corresponding inputs are checked */
      input[type="checkbox"]:checked + label > span, input[type="radio"]:checked + label > span {
        background: #08a8b8;
        // color:#08a8b8;
      }
</style>
<div class="_0" >
<?php switch($request):?>
<?php case 'profileVisibility': ?>
<div class="co_m" ></div>



<h1 class="co_m_h" >
Manage who sees your posts, profile uploads,
personal details, followers, following etc.
</h1>


      <input type="radio" name="visibility" value="1" id="public" />
      <label for="public"><span></span> Public </label>

      <input type="radio" name="visibility" value="0" id="private" />
      <label for="private"><span></span> Private</label>
<?php
 break;
 case 'storyVisibility':
?>

<h1 class="co_m_h" >
Who can see your story uploads 
</h1>


      <input type="radio" name="visibility" value="1" id="public" />
      <label for="public"><span></span> Everyone</label>

      <input type="radio" name="visibility" value="0" id="private" />
      <label for="private"><span></span> Followers</label>
      
      <input type="radio" name="visibility" value="0" id="private" />
      <label for="private"><span></span> Only me</label>
      

<?php
 break;
 
 case 'storyReactant':
?>

<h1 class="co_m_h" >
Who can react to your story uploads
</h1>


      <input type="radio" name="visibility" value="1" id="public" />
      <label for="public"><span></span> Everyone</label>

      <input type="radio" name="visibility" value="0" id="private" />
      <label for="private"><span></span> Followers</label>
      
      <input type="radio" name="visibility" value="0" id="private" />
      <label for="private"><span></span> Only me</label>
      


<?php
 break;
 
 case 'storyCommenting':
?>

<h1 class="co_m_h" >
Who can comment to your story uploads
</h1>


      <input type="radio" name="visibility" value="1" id="public" />
      <label for="public"><span></span> Everyone</label>

      <input type="radio" name="visibility" value="0" id="private" />
      <label for="private"><span></span> Followers</label>
      
      <input type="radio" name="visibility" value="0" id="private" />
      <label for="private"><span></span> Only me</label>
      

 <?php
 break;
 
 case 'storyShownTo':
 ?>
 
 <h1 class="co_m_h" >
 Your story uploads shows only on activated plateform
<p> Tips: </p>
<p>"Only me": Your story is shown to you alone on your profile page</p>
  <p>     "Everyone" : Your story is show to everyone including those who are not followjng you.</p>
 <p>      "Followers": Shown to you and your followers alone.</p>
 </h1>
 
 
 <input type="radio" name="visibility" value="1" id="" />
 <label for="public"><span></span> Only me</label>
 
 <input type="radio" name="visibility" value="0" id="private" />
 <label for="private"><span></span> Followers</label>
 
 <input type="radio" name="visibility" value="0" id="private" />
 <label for="private"><span></span> Everyone</label>
 
 
 <?php
 break;
 
 default : echo 'Sorry, the page your requested for was not found on this server.';
 
 endswitch;
?>
</div>


<script type="text/javascript">

$(document).ready(function(){



$.load.getProfileVisibility(function(data){
$('#'+data.visibility+' + label > span ').css({background:'#08a8b8'});
});


$('input').on('change',function(){
$('input + label > span').css({background:'transparent'});
$.getJSON('../.././checkpoint/server.post_content.php',{modifyPrivacy:'setProfileVisibility',val:$(this).val()}).done(function(re){ 
$.load.getProfileVisibility(function(data){
$('#'+data.visibility+' + label > span ').css({background:'#08a8b8'});
});

});
});



});



</script>
