<?php
session_start();
include_once "../.././includes/Handler.class.php";
$main = new Maintenance($_SESSION["id"]);


?>
<style type="text/css">
._0 {
padding:10px;
width:100%;
display:block;
background:#fff;
color:;
}

._0 h1{
font-size:small;
color:#aaa;
}

._1{
margin:20px auto;
}

._1 label {
font-size:small;
}

._1 label .fa{
font-size:larger;
width:40px;
height:40px;
padding:10px;
margin:auto 5px;
text-align:center;
}

._1 label + button {
background:transparent;
border:none;
float:right;
padding:5px 10px;
color:#aaa;
}
</style>
<div class="_0" >
<br>
<h1>Interaction</h1>
<br>
<div class="_1" >
<label for="a"><i class="fa fa-comment" ></i>Comment</label>
<button id="a" data-href="p/comment.php"><i class="fa fa-chevron-right" ></i></button>
</div>

<div class="_1" >
<label for="b"><i class="fa fa-th-large" ></i>Post</label>
<button id="b" data-href="v/post.php"><i class="fa fa-chevron-right" ></i></button>
</div>


<div class="_1" >
<label for="c"><i class="fa fa-spinner" ></i>Story</label>
<button id="c" data-href="s/story.php"><i class="fa fa-chevron-right" ></i></button>
</div>

<!-- -->
<br>
<br>
<h1>Connection</h1>
<br>
<div class="_1" >
<label for="e"><i class="fa fa-user" ></i>Account Privacy</label>
<button id="e" data-href="v1-set?page=profileVisibility">requesting...</button>
</div>

<div class="_1" >
<label for="f"><i class="fa fa-user-times" ></i>Blocked Accounts</label>
<button id="f" ><i class="fa fa-chevron-right" ></i></button>
</div>

<div class="_1" >
<label for="g"><i class="fa fa-bell-slash" ></i>Muted Accounts</label>
<button id="g" ><i class="fa fa-chevron-right" ></i></button>
</div>


<div class="_1" >
<label for="h"><i class="fa fa-users" ></i>Close Friends</label>
<button id="h" ><i class="fa fa-chevron-right" ></i></button>
</div>

</div>


<script type="text/javascript">
$(document).ready(function(){
$('#pageTitle').text('Privacy');



$("button").click(loadPage);

$.load.getProfileVisibility(function(data){
$('button#e').html(data.visibility); //css({background:'#08a8b8'});
});

function loadPage(){
  $.ajax({
        url: $(this).data("href"),
        success: function (data) {
          $('#_body_').html(data);
        }
    });
    if ($(this).data("href") != window.location) {
        window.history.pushState({ path: $(this).data("href") }, '', $(this).data("href"));
    }
    return false;
}



});

</script>