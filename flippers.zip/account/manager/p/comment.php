<?php
session_start();
include_once "../../../includes/Handler.class.php";
$main = new Maintenance($_SESSION["id"]);
$privacy = new Privacy($main->data->uid);

?>
<style type="text/css">
._0 {
padding:10px;
width:100%;
display:block;
background:#fff;
}



._1{
margin:20px auto;
display:flex;
}

._1_0 {
word-break:break-word;
text-overflow:break-word;
}

._1_0 h1{
color:#000;
font-size:small;
}

._1_0 p{
padding:3px 0;
}

._1_0 p:last-of-type {
padding-top:5px;
}


._1 label {
font-size:large;
}

._1 label .fa{
font-size:larger;
width:30px;
height:40px;
margin:auto 5px;
text-align:center;
}

._1 button {
background:transparent;
border:none;
padding:10px;
color:#aaa;
margin:auto 0 auto auto;
}

._1 span {
color:#aaa;
}

._1 p{
font-weight:400;
color:#aaa;
}

.co_m {
width:100%;
height:200px;
display:block;
margin:auto;
border-radius:10px;
background-color:#eee;
background-image:url("../../../icons/comment-reply-o.png");
background-repeat:no-repeat;
background-position:center;
background-size:100% 100%;
}

.co_m_h {
padding:10px;
color:#aaa;
font-size:small;
font-weight:400;
}
</style>
<div class="_0" >
<br>
<div class="co_m" ></div>



<h1 class="co_m_h" >
Now you can manage what happens when you comment
on posts.
</h1>


<div class="_1" >
<label for="a"><i class="fa fa-arrow-righ" >1</i></label>
<div class="_1_0" >
<h1>Who can comment on your comments</h1>
<p>Control who comments on your comments</p>
<p>Everyone</p>
</div>
<button id="a" ><i class="fa fa-chevron-right" ></i></button>
</div>


<div class="_1" >
<label for="a"><i class="fa fa-bel" >2</i></label>
<div class="_1_0" >
<h1>Who can share your comments</h1>
<p>Control who shares your comments <br>
<small>Shared comments is visible to everyone</small></p>
<p>Everyone</p>
</div>
<button id="a" ><i class="fa fa-chevron-right" ></i></button>
</div>

<div class="_1" >
<label for="a"><i class="fa fa-bel" >3</i></label>
<div class="_1_0" >
<h1>Who can reply on your comments</h1>
<p>Now you can control who replies to your comments on a post</p>
<p>Everyone</p>
</div>
<button id="a" ><i class="fa fa-chevron-right" ></i></button>
</div>


<div class="_1" >
<label for="a"><i class="fa fa-bel" >4</i></label>
<div class="_1_0" >
<h1>How many re-shares would you allow on your shared posts</h1>
<p>Limit the number of shares you get in a post</p>
<p>Unlimited</p>
</div>
<button id="a" ><i class="fa fa-chevron-right" ></i></button>
</div>



</div>


<script type="text/javascript">
$(document).ready(function(){
$('#pageTitle').text('Comment');



$("button").click(loadPage);



function loadPage(){
  $.ajax({
        url: $(this).data("href"),
        success: function (data) {
          $('#_body_').html(data);
        }
    });
    if ($(this).data("href") != window.location) {
        window.history.pushState({ path: $(this).data("href") }, '', $(this).data("href"));
    }
    return false;
}

});

</script>