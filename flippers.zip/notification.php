<?php
session_start();
include_once "./includes/config.class.php";
include_once "./includes/Handler.class.php";

//$obj = new Maintenance($_SESSION['id']);

?>
<style type="text/css">

body{
background:white;
font-weight:500;
}
.n-container {
border:;
width:100%;
}

.n-container .n-console {
position:relative;
width:100%;
height:auto;
display:flex;
flex-direction:row;
flex-wrap:nowrap;
justify-content:flex-start;
align-items:flex-start;
padding:10px;
/*border-bottom:0.5px solid #aaa;*/
position:relative;
transition:500ms linear;
/*background:rgba(0,200,255,.05);*/
}

.comment-container .n-console:hover {
background:;
}


.n-console .icon {
width:50px;
min-width:50px;
height:50px;
background:#eee;
border-radius:50%;
//border:1px solid #aaa;
//overflow:hidden;
background-repeat:no-repeat;
background-position:center;
background-size:cover;
box-shadow:0 0 1px rgba(0,0,0,.5), rgba(0,0,0,.2) 0 0 5px;
position:relative;
}


.n-console .text {
width:auto;
height:inherit;
/*background:#eee;*/
padding:5px 5px 5px 10px;
font-size:small;
line-height:20px;
word-break:break-word;
text-overflow:break-word;
}

.n-console .text button{
border:none;
box-shadow:none;
background:transparent;
color:#aaa;
}


.n-console .text span{
color:rgb(200,0,150);
font-weight:500;
font-style:italic;
}


.n-console .time {
color:#aaa;
font-weight:400;
}

.n-console button {
border:none;
border-radius:5px;
background-color:transparent;
color:#444;
font-weight:400;
font-size:small;
align-self:center;
box-shadow:0 0 3px #aaa;
padding:5px;
margin:auto 0 auto auto;
}

b{
font-weight:1000;
}


.n-console.loader .icon{
margin:50% auto;
width:100px;
height:100px;
}


.n-console.loader p{
text-align:center;
}

.nType {
height:30px;
width:30px;
border-radius:50%;
position:absolute;
bottom:-5px;
right:-5px;
background-repeat:no-repeat;
background-position:center;
background-size:cover;
box-shadow:0 0 3px rgba(0,0,0,.5), rgba(0,0,0,.2) 0 0 5px;
}

._s_header_ {
display:flex;
}
._s_header_ .searchBtn{
padding:10px;
border-radius:50%;
border:none;
margin:5px 0 5px auto;
background:white;
align-self:right;
}

._s_header_ .searchBtn .fa{
color:#000;
font-size:large;
}

._s_header_ button {
border:none;
background:transparent;
padding:10px 0 0 5px;
width:15%;
align-self:right;
margin-right:0;
}

._s_header_ button .fa{
font-size:larger;
color:#aaa;
}

._s_header_._parent{
position:sticky;
-webkit-position:sticky;
top:0;
background-color:white;
z-index:99;
}

._s_header_._s{
flex-flow:row nowrap;
align-content:center;
white-space:nowrap;
overflow:hidden;
overflow-x:scroll;
//display:none;
}

._s_header_._s::-webkit-scrollbar{
display:none;
}

._s_header_._s button .fa{
font-size:small;
padding:0 5px;
}


._s_header_._s p{
font-weight:400;
text-align:right;
color:#aaa;
padding:5px;
font-size:small;
align-self:center;
}

._s_header_._s button{
padding:5px;
margin:5px;
width:auto;
height:auto;
color:#000;
font-weight:500;
font-size:small;
}

._s_header_._s button:disabled {
color:#aaa;
}
</style>


<div class="_s_header_ _flex_row" >
<button id="search-list" ><i class="fa fa-ellipsis-h" ></i></button>
<button id="searchBtn" class="searchBtn"><i class="fa fa-search" ></i></button>
</div>
<div id="_s_menu_lists" class="_s_header_ _parent _flex_row" >
<button id="list-action-toggler" ><i class="fa fa-angle-down" ></i></button>
<div id="" class="_s_header_ _s _flex_row" >
<p>[<span id="list-counter">0</span>]</p>
<button class="list-action selectAll" disabled="disabled" ><i class="fa fa-list"></i> Select All</button>
<button class="list-action UnSelectAll" disabled="disabled" ><i class="fa fa-list"></i> Unselect</button>
<button class="list-action delete" disabled="disabled"  ><i class="fa fa-trash"></i> Delete <span style="display:none;"  id="list-counter">0</span></button>
<button class="list-action setAsRead" disabled="disabled" ><i class="fa fa-list"></i> Set As Read</button>
<button class="list-action setAsUnread" disabled="disabled" ><i class="fa fa-list"></i> Set As Unread</button>
</div>
</div>
<div class="n-container" ></div>


<script type="text/javascript">



$(document).ready(function(){
$('#searchBtn').click(function(){
$.load.searchModal();
});
$('div#_s_menu_lists').hide();
$("#pageTitle").text('Notifications');
var sessionId = "<?php echo $_SESSION['id']; ?>";
var url = "../checkpoint/server.post_content.php";
$.loadNotifications = $.loadNotifications || {};
$.loadNotifications.new = function(){
$.getJSON(url,{loadNewNotification:true},function(data){
var sstyle = '';
//alert(data)
var p = "";
if(data.length < 1) 
$("#_body_").html("<h1 class='_warning_cool _small_txt _site_txt_color'>You have no new notifications.</h1>");
for(var i = 0; i<data.length; ++i){

var ssid = data[i].sid;
var ffid = data[i].uid;
var pid = data[i].pid;
var ssName = data[i].fullName;
var ffName = (data[i].fidName == null)?'Flippers team':data[i].fidName;
var type = data[i].action;
var actionMessage = data[i].postText;
var ppPic = data[i].profilePic;
var ffPic = (data[i].fidPic == null || ppPic == null)?'./img/flippersteam.jpeg':data[i].fidPic;
var time = data[i].time;
var comment = data[i].comment;
var postText = data[i].postText;
var morePostInstance = (postText.length > 150)?"...":"";
var morePostInfo = ' • <br><font color="#aaa">'+postText+'</font>'; //"▶<span style='color:rgb(50,50,50);font-weight:400;'> "+postText.substring(0, 100)+morePostInstance+"</span>";
var isRead = (data[i].read == 1)?"white":"rgba(0,200,200,.09)";
var text;
var personTmp = (ssid===sessionId) ? "You":ffName;
var person = (ssid===sessionId) ? "You":"<b>"+ffName+"</b>";
var useThey = (ssid===sessionId) ? "you":"they";
var yourPost = (ffid===sessionId) ? "your post"+morePostInfo:"<b>"+ssName+"</b>'s post"+morePostInfo;
var personShared = (type == 'mentioned')?useThey+' shared '+morePostInfo:useThey+" "+morePostInfo;
var aPost = (ffid===sessionId) ? "you in a post "+personShared:"<b>"+ssName+"</b> in a post "+personShared;
var isFollowing = (ffid===sessionId) ?"you":"<b>"+ssName+"</b>";
var parent_comment = data[i].parent_comment;
var repliesTo = (ffid===sessionId) ? "your comment " :ssName+"'s comment";
var openReplyModal = false;
var whoid = (ssid===sessionId) ?ffid:ssid;
var whopic = (ssid===sessionId) ?'./uploads/profile/'+ppPic:'./uploads/profile/'+ffPic;
var n_indicator = '';
var get_poster_pronoun = data[i].get_poster_pronoun;
var get_real_poster_pronoun = (data[i].get_poster_uid !== ffid && data[i].get_poster_uid !== ssid)?data[i].get_poster_uname:get_poster_pronoun;
var deviceName, deviceID, accountID,loginDate,accessed = '';






//if (personTmp == 'You') continue;

if(type === "comment"){
text = person +" "+type+"ed on "+yourPost+" • <span class='__comment'>"+comment+"</span>";
n_indicator = 'comment-o.png';
}else if(type === "liked"){
text = person +" "+type+" "+yourPost;
n_indicator = 'heart-o.png';
}else if(type === "following"){
text = person +" started "+type+" "+isFollowing;
n_indicator = 'official-flippers.png';
}else if(type === "replied"){
openReplyModal = true;
n_indicator = 'comment-reply-o.png';
text = person +" "+type+" to "+repliesTo+" on "+get_real_poster_pronoun+" post • "+parent_comment;
}else if(type == "each other"){
text = data[i].msg;
}else if(type == "shared"){
text = person +" "+type+" "+yourPost; //+" • <span class='__comment'>"+comment+"</span>";
n_indicator = 'share.png';
}else if(type == "mentioned"){
n_indicator = 'share.png';
text = person +" "+type+" "+aPost; //+" • <span class='__comment'>"+comment+"</span>";
}else if(type == "accessed"){
n_indicator = 'official-flippers.png';
whopic = './icons/site-v.png';
text = "Your account was accessed on <b>"+data[i].o_time+"</b>. If this";
text += " was you, dont fret. Otherwise, please <a class='hashTag' href='#learn-more'> Learn More</a>";
text += "<br>Thank you for choosing Flippers.";
accessed = 'Accessed';
}

if(type == 'following'){
data_url = '../profile?rdrid='+whoid+'&ssid='+ssid+'&ffid='+ffid+'&from=notification';
}else if(type == 'accessed'){
data_url = null;
}else{
data_url = "../comments.php?ccidfn="+data[i].ccidfn+"&ssidfn="+data[i].ssidfn+"&ddfn="+data[i].ddfn+"&u="+personTmp+"&pid="+pid+"&uid="+ffid+"&frm=notification#"+openReplyModal;
}


p += '<div id="n_console" data-notname="no_'+i+'" data-notid="'+data[i].tid+'" style="background-color:'+isRead+';" class="n-console label_'+data[i].tid+' '+accessed+' hover" >';
p += '<div class="icon hover" style="background-image:url(\''+whopic+'\');"><div class="nType" style="'+sstyle+'background-image:url(\'./icons/'+n_indicator+'\');"></div></div>';
p += '<p class="text" >'+data[i].tid+'<font data-href="'+data_url+'" data-pid="'+pid+'" data-type="'+type+'" id="n_console">'+$.load.reduce_length(text,200)+' </font><span></span><br><small class="time">'+time+' &nbsp; <button id="n_option"><i class="fa fa-angle-down"></i></button></small></p>';
//p += followBackBtn;
p += '</div>';

//}


}

$("div.n-container").html(p);
loadPage("font#n_console");

/*setTimeout(function(){
$('div.Accessed').css({backgroundColor:'#fff'});
}, 4000);*/

/* Card menu button starts */
$("button#n_option").click(function(e){
e.preventDefault();
$.load.animate($(this),'bounceIn');
var href = "../home";
var _this = $(this);
var pid = _this.data('pid');
var uid = _this.data('uid');
var sid = _this.data('sid');
var params = [
{title:"Set as read",pid:pid,uid:uid,sid:sid,type:'abc',href:href,fa:"<i style='' class='fa fa-trash _obj_commands'></i>"},
{title:"Delete",pid:pid,uid:uid,sid:sid,type:'abc',href:href,fa:"<i style='' class='fa fa-unlink _obj_commands'></i>"},
{title:"Hide notification from this user",pid:pid,uid:uid,sid:sid,type:'abc',href:href,fa:"<i style='' class='fa fa-eye-slash _obj_commands'></i>"},
];
var modal_object = {href:href,params:params};
var modal = $.load.LoadModal(modal_object);
$(document.body).append(modal);
});



});
};

/*setInterval(function(){
$.loadNotifications();
}, 5000);*/
$.loadNotifications.new();



function loadPage(html){
$(html).on('click', function (e) {
    e.preventDefault();
    pageUrl = $(this); 
    var params = {
    		  pid:pageUrl.data("pid"),
    		  action:pageUrl.data("type"),
    		  isRead:'setRead'
    		};
  $.post(url,params,function(data){
  //...Post is read
  $.ajax({
        url: pageUrl.data("href"),
        timeout:10000,
        success: function (data) {
            $("#_body_").html(data);
        },
        error:function(){
        $("#_body_").html($.load.reload());     
        }
    });
   if (pageUrl.data("href") != window.location) {
   window.history.pushState({ path: pageUrl.data("href") }, '', pageUrl.data("href"));
       }
  });             
});
}




function ucfirst(str){
var str = str.toLowerCase().replace(/\b[a-z]/g, function(letter) {
    return letter.toUpperCase();
});
return str;
}

});
</script>

<script type="text/javascript">
$(document).ready(function(){




//if($(location).attr('pathname') === '/notification'){

$('#search-list').on('click',function(e){
e.preventDefault();
$.load.animate($(this), 'bounceIn');
/* Card menu button starts */
var href = "../profile";
var params = [
{title:"Select",type:'SELECT',href:href,fa:"<i class='fa fa-list _obj_commands'></i>"},
{title:"Manage what you receive",href:href,fa:"<i class='fa fa-wrench _obj_commands'></i>"},
];
var modal_object = {href:href,params:params};
var modal = $.load.LoadModal(modal_object);
$(document.body).append(modal);

/* Card menu button ends */

});
/*}else{
nb.html('<i class="fa fa-bell"></i>');
nb.html(nbhtml);
}*/
         

});

</script>
