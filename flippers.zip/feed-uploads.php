<style type="text/css">

.album{
display:flex;
flex-flow:row wrap;
//justify-content:flex-start;
//align-items:flex-start;
height:100%;
width:100%;
padding:0 0 10px 0;
margin:0;
background:#fff;
}


</style>

<div class=" animated slideInRight faster" > 



<div class="album" >
</div>



</div>


<!-- USER CARD -->
<!--<center><font style="text-align:center;font-family:cursive;"> You're all caught up😇</font></center>-->
<!--<div style="box-shadow:none;height:50px;border:none;background:#fff;" class="main-round-card" ></div>-->
<!-- USER CARD ENDS -->

<script type="text/javascript">
$(document).ready(function(){



var rdruid = "<?php echo $_GET['rdrid']; ?>";

var loadFeeds = function(){
$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
data:{loadAlbum:rdruid},
success:function(data){
//alert(data)
//alert(data.length)
var p = "";
for(var i = 0; i< data.length; i++){
/*addCssOf = (data[i].pic.length == 3)?e:3;
if((addCssOf != 3 && addCssOf != 0 && addCssOf != 2) || data[i].pic.length > 3){
addCssOf = '';
}
addCssOf = (data[i].pic.length == 2)?'':addCssOf;
*/
p += '<div style="background-image:url(\'../uploads/feeds/'+data[i].pic+'\');" class="img-responsive" onclick="return $.load.loadImageModal({src:$(this).data(\'src\')});" data-src="../uploads/feeds/'+data[i].pic+'"></div>';
}

if(data.length < 1){
p = "<h1 style='background:;text-align:center;margin:10% auto;color:#aaa;font-weight:400;font-size:small;'>Photos appear here once detected.</h1>";
}



$(".album").html(p);
/*}else{
$(".album").html(r[0]);
}
*/

},
fail:function(xhr, textStatus){
//...
}
});
};


loadFeeds();

});
</script>