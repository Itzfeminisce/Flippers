<?php ob_start(); session_start();
include_once "./includes/Handler.class.php";
$main = new Maintenance($_SESSION["id"]);
?>
<div style="background-color:white;" class="parent__" >

<?php
$q = "SELECT tmp_chat.*, 
	DATE_FORMAT(tmp_chat.time,'%h:%i') AS time,
	private_chat.message,
	private_chat.tid,
	private_chat.read,
	private_chat.sid AS myself
	FROM tmp_chat
	JOIN  private_chat
	ON private_chat.tid=tmp_chat.last_message

	WHERE tmp_chat.sender=".$main->data->uid." 
	OR tmp_chat.receiver=".$main->data->uid." 
	ORDER BY tmp_chat.time DESC";
$q = $main->con->query($q);
if($q->num_rows > 0):
while($rows = $q->fetch_object()):
$showName = ($rows->sender == $main->data->uid)?$main->search("fullName",$rows->receiver):$main->search("fullName",$rows->sender);
$showId = ($rows->sender == $main->data->uid)?$rows->receiver:$rows->sender;
$showPic = ($rows->sender == $main->data->uid)?$main->search("profilePic",$rows->receiver):$main->search("profilePic",$rows->sender);
$online = ($main->search("online",$rows->receiver) == 0)?"#eee":"green";
$message = ($rows->message == 'heart')?'❤':$rows->message;
//echo $main->search("online",$rows->receiver); //Sender turns $receiver here
//echo $main->search("fullName",$rows->receiver);

//echo $rows->read= $main->con->query('SELECT read FROM private_chat WHERE tid = '.$rows->tid)->fetch_object()->read;

$isRead = ($rows->read == 1 || $rows->myself == $main->data->uid)?'#fff':'rgba(0,0,200,.09)';
?>
<div id="message" onclick="$.load.loadChat({card:$(this)});" 
data-sid="<?php echo $main->data->uid; ?>"
 data-name="<?php echo $showName; ?>" 
 data-uid="<?php echo $showId; ?>" 
 data-pic="<?php echo $showPic; ?>" 
 data-message="<?php echo $rows->last_message; ?>"
 data-isread="<?php echo $rows->read; ?>"
 data-msgid="<?php echo $rows->tid; ?>"
 class="placeholder message motion hover"
 style="background-color:<?php echo $isRead; ?>;">
<div style="background-image:url('./uploads/profile/<?php echo $showPic; ?>');" class="avatar" >
<!--<img src="../uploads/profile/<?php echo $showPic; ?>" >-->
<div style="background:<?php echo $online; ?>;" class="online-status" ></div>
</div>
<div class="info" >
<div class="name" ><h1><?php echo $showName; ?></h1></div>
<div class="text" >
<div class="sent-notifier" >√√</div>
<h2><?php echo $message; ?></h2></div>
<div class="date" ><p><?php echo $rows->time; ?></p></div>
<div style="background-color:transparent;" class="unread" ><p></p></div>
</div>
</div>
<?php
endwhile;
else:
echo "<h1 class='_warning_cool _small_txt _site_txt_color'>You have no messages</h1>";
endif;
?>

<div id="_show_suggestion" ></div>
</div>

<script type="text/javascript">

//var card = "", url="../checkpoint/server.post_content.php";
$("#pageTitle").text("Messages");
//$("#_show_suggestion").append($.load.suggestion_card({title:'Based on people you follow:',css:{orientation:'column',width:'95%',margin:'10px auto'}}));

params = {
title:'Based on people you follow',
limit:'LIMIT 7'
};
$.load.suggestion_card_inline(params, function(cards){
$("#_show_suggestion").html(cards);
});


$('div#message').on('click',function(){
var data = {setMessageInfo:true,id:$(this).data('msgid'),action:'isRead'};
$.get($.load.server(),data,function(data){
//Set read to true.
//alert(data)

});
});

</script>
