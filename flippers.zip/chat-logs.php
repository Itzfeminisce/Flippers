<?php
include_once "./header.php";
?>



</head>
<body>

<div class="comment-container" >
<div class="comment-header" >
<div class="back-btn" ><button onclick="history.back();"  class="back-btn-btn"><i class="fa fa-arrow-left" ></i></button></div>
<div class="poster-info" ><p>Frank Lampard<span> 46, Houston, TX</span></p></div>
<div class="poster-icon" ></div>
</div>


<div class="chat-field-console " >

<div class="chat-field" >
<p>I am a developer too... Nice job bro👊👊👊👊</p>
<p>23:56pm</p>
</div>


<div class="chat-field out" >
<p>Nice one man, keep it up✌</p>
<p>23:56pm</p>
</div>



</div>
<div class="comment-form" >
<textarea></textarea>
<button><i class="fa fa-paper-plane" ></i></button>
</div>
</div>





<!-- USER CARD -->
<!--<center><font style="text-align:center;font-family:cursive;"> You're all caught up😇</font></center>-->
<!--<div style="box-shadow:none;height:50px;border:none;" class="main-round-card" ></div>-->
<!-- USER CARD ENDS -->

<!--
<div class="taskbar" >
<div class="meet" ><button onclick="location='./index.html';" ><i class="fa fa-users" ></i></button></div>
<div class="explore" ><button onclick="location='./explore.html';" ><i class="fa fa-search" ></i></button></div>
<div class="meet" ><button onclick="location='';" ><i class="fa fa-plus" style="padding:0 15px;font-weight:;" ></i></button></div>
<div class="message" ><button onclick="location='./chats.html';" ><i class="fa fa-envelope" style="font-weight:normal;" ></i></button></div>
<div class="profile" ><button onclick="location='./profile.html';" ><i class="fa fa-user"  style="font-weight:normal;" ></i></button></div>
</div>
-->
<script src="./script/jquery.js"></script>
<script src="./script/Handler.Java.js"></script>
</body>

</html>