


$(document).ready(()=>{


$.load = $.load || {};


$.load.getUnreadNotification = function(use){

var params = {
		  isRead:'getUnreadNotification'
		};
  $.post($.load.server(),params,function(count){
//alert(count)
if(count.unreadNot > 0){
$('#NotificationCount').show('fast'); //.text(count.unread).show('fast');
}else{
$('#NotificationCount').hide('fast');
}

if(count.unreadMsg > 0){
$('#MsgCount').show('fast'); //.text(count.unread).show('fast');
}else{
$('#MsgCount').hide('fast');
}
 if(typeof use == 'function') use(count);
  }, 'json');
};



$.load.userEvent = function(data = null){
var btnName,isMe = false;
if(data !== null){
title = data.title;
uid = data.uid;
sid = data.sid;
load = data.load;
if(uid == sid){
isMe = true;
}
}
var __o,_d='',_c_ = '',actionType = '',fbtnstc = '', fbtnstb='',_followbtn = '',_p_ = $('<div></div>');


_c_ += '<div class="animated fadeInUpBig faster xxact" >';
_c_ += '<div class="xxact-h" >';
_c_ += '<button id="xxact-bb" onclick="var _this = $(this); $.load.animate(_this, \'bounceIn\'); _this.parent().parent().addClass(\'animated fadeOutDownBig\');"><i class="fa fa-arrow-left" ></i></button>';
_c_ += '<p>'+title+'</p></div>';
_c_ += '<div class="xxact-b" >';
$.getJSON($.load.server(),{load:load,uid:uid},function(response){

for(var rows in response){
rows = response[rows];

if(isMe == true){
btnName = (load == 'follower')?'remove':'following';
_followbtn = (rows.isFollowing == true)?'<span class="__o__ _i_">You\'re following</span>':'<span class="__o__">Not following <b>'+rows.fullName+'</b> • </span><button data-v="o" data-uname="'+rows.fullName+'" data-uimg="'+rows.profilePic+'" data-who="'+rows.fuid+'" data-type="follow" id="getAction" class="__follow-btn hover">follow back</button>';
}


if(isMe == false){
if(rows.isFollowing == true){
btnName = 'following';
}else{
btnName = 'follow';
}
_d = (rows.fuid == sid)? 'hidden' : 'visible';
}


if(btnName == 'following'){
actionType = 'unfollow';
}else{
actionType = 'follow';
}

if(btnName == 'remove'){
actionType = 'remove';
}



_c_ += '<div class="xxl hover" >';
_c_ += '<div  id="___card___" data-carduid="'+rows.fuid+'" data-href="../profile?rdrid='+rows.fuid+'&token=sjsjdbdj&frm=load" style="background-image:url(\'../uploads/profile/'+rows.profilePic+'\');" class="xxl-i hover" ></div>';
_c_ += '<p  id="___card___" data-carduid="'+rows.fuid+'" data-href="../profile?rdrid='+rows.fuid+'&token=sjsjdbdj&frm=load" class="hover">'+rows.fullName+'<br>'+_followbtn+'</p>';
//_c_ += _followbtn;
_c_ += '<button style="visibility:'+_d+';" data-who="'+rows.fuid+'" data-uid="'+rows.uid+'" data-uname="'+rows.fullName+'" data-uimg="'+rows.profilePic+'" data-type="'+actionType+'" id="getAction" class="hover">'+btnName+'</button>';
_c_ += '</div>';
}
_c_ += '</div></div>';
_p_.html(_c_);

$("div#___card___, p#___card___").click(function(){
pageUrl = $(this);
$.ajax({
        url: pageUrl.data("href"),
        success: function (data) {
          $("div#_body_").html(data);
        }
    });
   pageUrl.parent().parent().parent().addClass('animated fadeOutDownBig faster');
    if (pageUrl.data("href") != window.location) {
        window.history.pushState({ path: pageUrl.data("href") }, '', pageUrl.data("href"));
    }
});
    
$('button#getAction').click(function(){
_this = $(this);
type = _this.data('type');
//params = {};
switch(type){
case 'remove':
__o = {
title:'Remove <strong>'+_this.data('uname')+'</strong>',
text:'<strong>'+_this.data('uname')+'</strong> will not be notified that you remove them from your follower. Continue?',
action_btn_text:'remove',
img:'../uploads/profile/'+_this.data('uimg'),
};
//$.load.alert(__o);
$.load.alert(__o,function(callback){
$.load.FOLLOW(_this, function(status){
//Add other styling to indicate unfollowed;
_this.text(function(){ return $(this).text()+'d';});
if(typeof  callback == 'function') callback(status);
});
});



break;
case 'unfollow':
__o = {
title:'Unfollow <strong>'+_this.data('uname')+'</strong>',
text:'Do you want to unfollow <strong>'+_this.data('uname')+'</strong>',
action_btn_text:'unfollow',
img:'../uploads/profile/'+_this.data('uimg'),
};
$.load.alert(__o,function(callback){
$.load.FOLLOW(_this, function(status){
//Add other styling to indicate unfollowed;
_this.text('follow');
_this.data('type','follow');
if(_this.data('v') == 'o'){
_this.prev().text(function(){
return $(this).text().replace('Now','Not');
});
}
if(typeof  callback == 'function') callback(status);
});
});

break;

case 'follow':

$.load.FOLLOW(_this, function(status){
//Add other styling to indicate unfollowed;
_this.text('following');
_this.data('type','unfollow');
if(_this.data('v') == 'o'){
_this.prev().text(function(){
return $(this).text().replace('Not','Now');
});
}
if(typeof  callback == 'function') callback(status);
});


break;

}

});
});

return _p_;
};


$.load.smallComments = function(comments,evt = null){

var _m,_n,_o,_p,target=0,commentdate='',commenterid='',commentid='',_q,rows,evt_name;

if(evt !== null){
 commentdate = evt.data.commentdate;
 commenterid = evt.data.commenterid;
 commentid = evt.data.commentid;
 target = evt.data.target;
 evt_name = '$.load.loadReplies(this);';
}
_q = $('<div></div>');
for(var i in comments){
rows = comments[i];
_m = $('<div id="comment_'+target+'" class="ex-c hover" ></div>');
_n = $('<div onclick="'+evt_name+'" data-commentdate="'+commentdate+'" data-commenterid="'+commenterid+'" data-commentid="'+commentid+'" class="c" ></div>');
_o = $('<div style="background-image:url(\'../uploads/profile/'+rows.profilePic+'\');"class="ci" ></div>');
_p = $('<p><b>'+rows.userName+': </b>'+rows.comment_text+'</p>');

_n.append(_o);
_n.append(_p);
_m.append(_n);
_q.append(_m);
}
 //$('<button><a href="#'+target+'"></a></button>').click();
return _q.html();
};

$.load.alert = function(params,callback){
title = params.title;
text = params.text;
img = (params.img == undefined || params.img == null)?'../icons/site-v.png':params.img;
action_btn_text = (params.action_btn_text == undefined)?'Ok Please!':params.action_btn_text;
var _a = '';
_a += '<div class="alert" >';
_a += '<div class="alert-body" >';
_a += '<p class="alert-title" >'+title+'</p>';
_a += '<div style="background-image:url(\''+img+'\');" class="alert-img"></div>';
_a += '<p class="alert-parag" >';
_a += text;
_a += '<div class="alert-controls" >';
_a += '<button class="hover" id="continue">'+action_btn_text+'</button>';
_a += '<button class="hover" id="closeAlert">Cancel</button>';
_a += '</div></div></div>';

  $(document.body).append($(_a));
  $('button#closeAlert').click(function(e){
	$(this).parent().parents('.alert').hide();
	$(this).parent().parents('.alert').empty();
   e.preventDafault();
  });
  
  
  $('button#continue').click(function(e){
	if(typeof callback == 'function'){
	 callback(function(response){
	 __status = response.status;
	 __msg = response.msg;
	 if(__status == true){
	 	 ___o = {
	 msg:__msg,
	 status:__status
	 }
	 $.load.notification(___o,function(c){
	 setTimeout(function(){
	 c.addClass('animated slideOutUp');
	 },3000)
	 });
	 }else{
	 alert('Something went wrong. But dont fret so give it another shot.');
	 }
	 });
  	}
  	$(this).parent().parents('.alert').hide();
  	$(this).parent().parents('.alert').empty();
  	
  	e.preventDafault();
  });
  
};




$.load.server = function(){
return '../checkpoint/server.post_content.php';
};


$.load.urlify = function(text) {
    var urlRegex = /((?:(http|https|Http|Https|rtsp|Rtsp):\/\/(?:(?:[a-zA-Z0-9\$\-\_\.\+\!\*\'\(\)\,\;\?\&\=]|(?:\%[a-fA-F0-9]{2})){1,64}(?:\:(?:[a-zA-Z0-9\$\-\_\.\+\!\*\'\(\)\,\;\?\&\=]|(?:\%[a-fA-F0-9]{2})){1,25})?\@)?)?((?:(?:[a-zA-Z0-9][a-zA-Z0-9\-]{0,64}\.)+(?:(?:aero|arpa|asia|a[cdefgilmnoqrstuwxz])|(?:biz|b[abdefghijmnorstvwyz])|(?:cat|com|coop|c[acdfghiklmnoruvxyz])|d[ejkmoz]|(?:edu|e[cegrstu])|f[ijkmor]|(?:gov|g[abdefghilmnpqrstuwy])|h[kmnrtu]|(?:info|int|i[delmnoqrst])|(?:jobs|j[emop])|k[eghimnrwyz]|l[abcikrstuvy]|(?:mil|mobi|museum|m[acdghklmnopqrstuvwxyz])|(?:name|net|n[acefgilopruz])|(?:org|om)|(?:pro|p[aefghklmnrstwy])|qa|r[eouw]|s[abcdeghijklmnortuvyz]|(?:tel|travel|t[cdfghjklmnoprtvwz])|u[agkmsyz]|v[aceginu]|w[fs]|y[etu]|z[amw]))|(?:(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9])\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[0-9])))(?:\:\d{1,5})?)(\/(?:(?:[a-zA-Z0-9\;\/\?\:\@\&\=\#\~\-\.\+\!\*\'\(\)\,\_])|(?:\%[a-fA-F0-9]{2}))*)?(?:\b|$)/gi;
    return text.replace(urlRegex, function(url) {
        
        if ( ( url.indexOf(".jpg") > 0 ) || ( url.indexOf(".png") > 0 ) || ( url.indexOf(".gif") > 0 ) ) {
        return '<a class="postUrls" href="'+url+'" rel="nofollow noindex" target="_blank"><object class="img-responsive _card _embedded" data="'+url+'" type=""></object></a>';
         //'<a href="'+url+'" target="_BLANK"><img width="100" height="100" src="' + url + '"></a>' + '<br/>'
        }else{
        
        return '<a class="postUrls" href="' + url + '" target="_BLANK" title="'+url+'" rel="noindex nofollow">'+url+'</a>';
    }
    })
    // or alternatively
   // return text.replace(urlRegex, '<a href="$1">$1</a>')
};






$.load.deleteTweet = function(btn){
var requestType = btn.data('type');
var requestPid = btn.data('pid');
var requestUid = btn.data('uid');
var requestSid = btn.data('sid');
var _await;
var url = '../checkpoint/server.post_content.php';
var confirmation_btn_text = 'Go!', confirmation_return_text = 'Welcome to Flippers';
var data;
switch(requestType){
case 'delete': 
confirmation_return_text = 'Are you sure you want to delete this post?';
confirmation_btn_text = 'Delete now!';
var obj = {
arg : confirmation_return_text,
text: confirmation_btn_text,
action: function(){
$.getJSON(url,{CommandList:requestType,pid:requestPid,uid:requestUid,sid:requestSid})
.done(function(response){
_await = response.text;
}).fail(function(statusText){
_await = statusText;
});
return _await;
},
}
$(document.body).append($.load.confirm(obj));
break;

case 'reflip':

//$.load.share();

break;
}



};


$.load.delay = function(callback,timeout = 5000) {
_v0 = $('<div class="_abc" ></div>');
_v1 = $('<div class="_abc_logo" style="background-image:url(\'../icons/flip-eagle.png\');"></div>');
_v2 = $('<div class="_abc_logo_small" ></div>');
_v3 = $('<p>Flippers</p>');
_v0.append(_v1);
_v1.append(_v2);
_v0.append(_v3);
$(document.body).append(_v0);
$('#theme-color').prop('content','#08A8B8');
setTimeout(function(){
$('#theme-color').prop('content','#FFFFFF');
if(typeof callback == 'function') callback(_v0);
},timeout);
};


$.load.reload = function(page = $(location).attr('href')){
_arc = $('<div class=”___refresh_page"></div>').css({
width:'200px',
height:'auto',
backgroundColor:'rgba(0,0,0,.05)',
margin:'25% auto',
borderRadius:'10px',
padding:'10px',
textAlign:'center',
});
_arp = $('<p>Oops! Something weird happened. Please give it another try.</p>').css({
color:'#000',
margin:'10px auto',
});
_arb = $('<button data-href="'+page+'"><i class="fa fa-spinner"> Refresh</i></button><br>').css({
padding:'5px 10px',
border:'1px solid white',
borderRadius:'100px',
color:'white',
background:'rgba(0,0,200,.5)',
});

_arbback = $('<br><button data-href="../"><i class="fa fa-arrow-left"> Goto main page</i></button>').css({
padding:'5px 10px',
border:'1px solid white',
borderRadius:'100px',
color:'white',
background:'rgba(0,0,200,.5)',
});

_arc.append(_arp);
_arc.append(_arb);
_arc.append(_arbback);
_arb.on('click',function(){
$.ajax({
        url: $(this).data("href"),
        timeout:10000,
        beforeSend:function(){
          $("#_body_").html(showLoader());
        },
         success: function (data) {
          $("#_body_").html(data);
        },
        error:function(){
        $("#_body_").html($.load.reload());     
        }
    });
});

_arbback.on('click',function(){
$.ajax({
        url: $(this).data("href"),
        timeout:10000,
        beforeSend:function(){
          $("#_body_").html(showLoader());
        },
         success: function (data) {
          $(document.body).html(data);
        },
        error:function(){
        $("#_body_").html($.load.reload());     
        }
    });
});

return _arc;
}


$.load.notification = function(data,callback=null){
var c,msg,status;
if(data === null){
msg = 'Notification';
status = 'default';
}else{
msg = data.msg;
status = data.status;
}
c = $('<div class="animated slideInDown"></div>').css({
position:'fixed',
top:'0',
left:'0',
width:'100%',
height:'auto',
padding:'5px',
margin:'auto',
zIndex:'999',
});
b = $('<p>'+msg+'</p>').css({
backgroundColor:'rgb(255,0,255)',
padding:'10px',
color:'white',
textAlign:'center',
});
c.append(b);
$(document.body).append(c);
if(typeof callback == 'function'){
var __return = callback(c);
if(((__return != null) || (__return != undefined)) && (__return == true)){
setTimeout(function(){
c.addClass('animated slideOutUp');
c.on('anitmationend',function(){
c.removeClass('aninated slideOutUp');
});
});
} 
 }
};


$.load.reflip = function(rows){


///alert(rows.rtwt.rtwt_username)

//alert(rows.rtwt_pic.toString())

var rtwt_username = rows.rtwt.rtwt_username;


var rtwt_content = (rows.rtwt.text == '' || rows.rtwt.text == '')?'reflipped ':rows.rtwt.text;


var rtwt_fullName = rows.rtwt.rtwt_fullName;
var new_user_post =  rows.rtwt_text;
var rtwt_time = rows.rtwt.rtwt_time;
var rtwt_profilePic = rows.rtwt.rtwt_profilePic;


var rtwt_pics = rows.rtwt.rtwt_tmp_pic;
var is_pic = (rtwt_pics == null)?"":rtwt_pics;
var tmp_pic = (is_pic == "")?"none":"";

var css = {
border:'1px solid #aaa',
borderRadius:{round:'50%',endRound:'100px',smallRound:'10px'},
width:{fill:'100%',auto:'auto',test:'100px'},
height:{fill:'100%',auto:'auto',test:'100px'},
padding:'10px',
margin:{fit:'auto',margin:'5px'},
color:{site:'#08A8B8',black:'#000'}
};
var create = {
div:'<div></div>',
p:'<p></p>',
h1:'<h1></h1>',
img:'<img>',
input:'<input>',
span:'<span></span>',
button:'<button></button>',
};

var btnStyle= {
background:'transparent',
fontSize:'small',
border:'none',
margin:'5px',
padding:'2px 5px',
};

var p,r,l,rh,rt,rb,rf;
p = $('<div id="rtwt__parent__"></div>').css({
width:'100%',
height:'auto',
backgroundColor:'',
border:'1px solid rgba(0,0,200,.05)',
borderRadius:'10px',
display:'flex',
flexFlow:'row nowrap',
justifyContent:'flex-start',
alignContent:'center',
alignSelf:'flex-end',
margin:'auto 5px auto auto',
padding:'5px',
});


l = $('<div id="rtwt_profilePic"></div>').css({
width:'30px',
height:'30px',
minWidth:'30px',
minHeight:'30px',
border:'1px solid #aaa',
borderRadius:'50%',
alignSelf:'flex-start',
margin:'0 3px',
backgroundPosition:'center',
backgroundRepeat:'no-repeat',
backgroundSize:'100% 100%',
backgroundImage:'url("../uploads/profile/'+rtwt_profilePic+'")'
});

r = $(create.div).css({
width:'90%',
height:'auto',
});

rh = $(create.p).css({
marginBottom:'2px',
display:'flex',
flexFlow:'row nowrap',
fontSize:'medium',
}).html($('<span id="rtwt_name"></span>').html(rtwt_fullName+' <font id="rtwt_username" style="color:#aaa;font-weight:400;">@'+rtwt_username+'</font>').css({
maxWidth:'200px',
whiteSpace:'nowrap',
overflow:'hidden',
textOverflow:'ellipsis',
fontWeight:'700',
fontSize:'small',
}))
.append($('<p id="rtwt_time"></p>').html(' • '+rtwt_time).css({
color:'#aaa',
fontWeight:'400',
//fontSize:'smaller'
}));



rt = $('<h1 class="_panel_parag_ _large_txt" data-click="0" data-href="../comments?u='+rows.rtwt.rtwt_username+'&pid='+rows.rtwt.rtwt_pid+'&uid='+rows.rtwt.rtwt_uid+'&frm=home" id="text_p">'+$.load.reduce_length($.load.urlify(rows.rtwt.rtwt_text))+'</h1>').css({
fontSize:'14px',
fontWeight:'400',
width:'100%',
overflowWrap:'break-word',
});



rf = $(create.div).css({
display:'flex',
flexFlow:'row nowrap',
justifyContent:'center',
alignContent:'shrink',
width:'100%',
})
.append($(create.button).html('<i style="font-weight:400;" class="fa fa-heart"> • 305k</i>').css(btnStyle))
.append($(create.button).html('<i style="font-weight:600;" class="fa fa-retweet"> • 35k</i>').css(btnStyle))
.append($(create.button).html('<i style="font-weight:400;" class="fa fa-comment"> • 505k</i>').css(btnStyle));
r.append(rh);
r.append(rt);


rb = $('<div id="rtwt_attachment"></div>').css({
width:'100%',
display:tmp_pic,
height:'100px',
backgroundColor:'#eee',
borderRadius:'10px',
margin:'3px auto',
backgroundPosition:'center',
backgroundRepeat:'no-repeat',
backgroundSize:'cover',
backgroundImage:'url("../uploads/feeds/'+is_pic+'")'
});

r.append(rb);
//r.append(rf);
p.append(l);
p.append(r);

var container = $(create.div);
container.append($(create.p).css({
fontSize:'medium',
fontWeight:'400',
width:'100%',
padding:'3px 0',
overflowWrap:'break-word',
}).html('<h1 class="_panel_parag_ _large_txt" data-click="0" data-href="../comments?u='+rows.userName+'&pid='+rows.pid+'&uid='+rows.uid+'&frm=home" id="text_p">'+$.load.reduce_length($.load.urlify(rows.text))+'</h1>'));
container.append(p);

return container.html();
}

$.load.reduce_length = function(str,max=300){
this.str = str;
this.string = [];
this.strlen = this.str.split('');
this.max = max;
if(this.strlen.length <= this.max){
return this.str;
}else{
for(var i = 0; i < this.strlen.length; i++){
this.string.push(this.strlen[i]);
if(i == (this.max + 1)){
this.string.push('...<font color="#aaa">read more</font>');
break;
}
}
return this.string.join('');
}
};




$.load.loadChat = function(q = null){
var _parent_, _h, _b,_s, _f, _f_c, url="../checkpoint/server.post_content.php";
if(q !== null){
card = q.card;
sid = card.data("sid");
uid = card.data("uid");
name = card.data("name");
pic = card.data("pic");
messageId = card.data("message");
}else{
card ="default";
sid = "default";
uid = "default";
name = "default";
pic = "default";
messageId = 0;
}

var data = {setMessageInfo:true,id:messageId,action:'isRead'};
$.get($.load.server(),data,function(data){
//Set read to true.
});


_css = {
show:{ display:'block'},
hide:{ display:'none'}
};
_btnCss_ = {
width:"40px",
height:"40px",
minWidth:"40px",
minHeight:"40px",
color:"#444",
borderRadius:"50%",
border:"none",
margin:"auto",
};
_parent_ = $("<div class='animated fadeInRightBig faster'></div>").css({
position:"fixed",
top:"0",
left:"0",
width:"100%",
height:"100%",
display:"flex",
flexFlow:"column nowrap",
alignContent:"flex-start",
justifyContent:"flex-start",
alignItems:"shrink",
backgroundColor:"#fff",
zIndex:"99",
});
_h = $("<div></div>").css({
width:"100%",
height:"auto",
display:"flex",
flexFlow:"row nowrap",
alignContent:"flex-start",
justifyContent:"flex-start",
alignItems:"shrink",
background:"transparent",
padding:"5px 0",
});
_b = $("<div id='myDiv'></div>").css({
width:"100%",
height:"auto",
backgroundColor:"transparent",
color:"white",
fontSize:"medium",
padding:"10px",
textAlign:"center",
fontSize:"x-large",
lineHeight:"30px",
backgroundPosition:"center",
backgroundSize:"100%",
backgroundRepeat:"no-repeat",
overflow:"hidden",
overflowY:"scroll",
margin:"auto auto 0 auto",
});
_s = $("<div class='moment-container'></div>").css({
width:"100%",
height:"auto",
display:"flex",
flexFlow:"row wrap",
alignContent:"flex-start",
justifyContent:"flex-start",
backgroundColor:"rgba(0,0,0,.4)",
padding:"2px 4px",
}).hide();
_f = $("<div></div>").css({
width:"100%",
height:"auto",
display:"flex",
flexFlow:"row nowrap",
alignContent:"center",
justifyContent:"flex-start",
alignItems:"center",
backgroundColor:"transparent",
alignSelf:"flex-end",
padding:"10px 0",
});
_f_c = $("<div></div>").css({
height:"50px",
width:"99%",
backgroundColor:"transparent",
border:"none",
borderTop:'.5px solid #aaa',
borderRadius:"none",
margin:"auto",
display:"flex",
flexFlow:"row nowrap",
alignContent:"center",
justifyContent:"flex-start",
alignItems:"center",
padding:"0 5px",
});
_hbb = $("<i class='fa fa-arrow-left'>&nbsp;</i>").css({
width:"auto",
padding:"10px",
color:"black",
backgroundColor:"transparent",
fontSize:"large",
fontWeight:"500px",
});
_hpc = $("<span class=''>&nbsp; "+name+"</font><span style='color:#000;font-size:xx-small;' id='typing'></span></span>").css({
width:"100%",
padding:"10px",
color:"black",
backgroundColor:"transparent",
fontSize:"large",
});
_hoi = $("<i class='fa fa-ellipsis-v'></i>").css({
width:"auto",
padding:"10px 0",
color:"black",
margin:"auto 10px",
backgroundColor:"transparent",
fontSize:"large",
});
_hoi_img_css = {
width:"40px",
height:"40px",
minWidth:"40px",
maxHeight:"40px",
borderRadius:"50%",
border:"2px solid black",
backgroundColor:"transparent",
backgroundPosition:"center",
backgroundSize:"cover",
backgroundRepeat:"no-repeat",
};
_hoi_img = $("<div class=''></div>").css(_hoi_img_css).css({backgroundImage:"url('../uploads/profile/"+pic+"')"});
_f_parent_c = $("<div class='animated bounceIn faster'></div>").css({
width:"auto",
height:"auto",
backgroundColor:"transparent",
display:"flex",
});
_f_i_uploads = $("<div><i class='fa fa-paperclip'></i></div>").css(_btnCss_).css({
fontSize:"x-large",
padding:"6px",
fontWeight:"400"
});
_f_i_textarea = $("<input />").css(_btnCss_).css({
width:"100%",
borderRadius:"100px",
margin:"0 10px",
padding:"10px",
backgroundColor:"#eee",
color:"#333",
});
_f_i_textarea.prop({
type:"text",
placeholder:"Write your message...",
"class":"message_input"
});
//alert(_f_i_textarea.attr("class"))
_f_i_send = $("<div><i class='fa fa-paper-plane'></i></div>").css(_btnCss_).css({
fontSize:"x-large",
padding:"5px 5px",
});
_f_i_heart = $("<div data-name='heart'><i class='fa fa-heart'></i></div>").css(_btnCss_).css({
fontSize:"x-large",
padding:"5px 5px",
color:"red"
});
_f_i_smileys = $("<div><i class='fa fa-smile'></i></div>").css(_btnCss_).css({
fontSize:"x-large",
padding:"5px 5px",
});
function setIsRead(id){
$.get(url,{setMessageInfo:true,action:"isRead",id:id},function(data){
//alert(data)
});
}
setIsRead(messageId);
_f_c.append(_f_i_uploads);
_f_c.append(_f_i_textarea);
_f_parent_c.append(_f_i_heart);
_f_parent_c.append(_f_i_smileys);
_f_c.append(_f_parent_c);
_h.append(_hbb);
_h.append(_hpc);
_h.append(_hoi);
_f.append(_f_c);
_hoi.before(_hoi_img);
_parent_.append(_h);
_parent_.append(_b);
_parent_.append(_s);
_parent_.append(_f);
//alert(_f.html())
function click_heart(btn){
_this = btn;
_this.click(function(){
$.load.animate(_this,"bounceIn",function(){
_heart = _this.data("name");
$.post(url,{storeChatMsg:true,chatMsg:_heart,uid:uid},function(){
refreshChat();
});
});
});
return;
}
var _fimg = $("<input type='file' name='file'>");
_f_i_uploads.on("click",function(){
_fimg.click();
 });
_pre = $("<div id='uploads_'></div>").css({
width:"100px",
height:"100px",
minHeight:"100px",
borderRadius:"10%",
backgroundPosition:"center",
backgroundSize:"100%",
backgroundRepeat:"no-repeat",
margin:"5px 10px",
position:"relative",
//backgroundImage:"url('"+e.target.result+"')",
});
_pre_cancel = $("<button><i class='fa fa-times'></i></button>").css({
width:"20px",
height:"20px",
border:"none",
backgroundColor:"#000",
borderRadius:"50%",
color:"white",
fontSize:"medium",
position:"absolute",
top:"10px",
right:"10px",
});
_pre.append(_pre_cancel);
 _fdata = new FormData();
_fimg.on("change", function(){
_myExt = ["mp4","3gp","gif","ogg","png","jpg","jpeg"]; 
files = this.files;
$.load.preloadImage(this, _myExt, function(e){
_s.before(_pre);
//alert(e.target.result);
_pre.css({backgroundImage:"url('"+e.target.result+"')"});
$.each(files, function(i,file){
_fdata.append("file",file);
});
_fimg.val("");
});
//alert(_fdata.getAll("mFile"))
});
_pre_cancel.on("click",function(){
_pre.hide("fast");
});
$.load.loadSmileys(
//Append smileys to div
function(smileys){
_s.append(smileys);
},
//Do something when smileys is clicked
function(_smileys_btn_){
alert(_smileys_btn_.data("name"));
});
function showSmileys(){
_f_i_smileys.on({
click:function(){
var ___this = $(this);
if(_s.is(":hidden")){
___this.html("<i class='fa fa-times'></i>");
_s.show("fast");
}else{
___this.html("<i class='fa fa-smile'></i>");
_s.hide("fast");
}
}
});
return;
}
showSmileys();
click_heart(_f_i_heart);
_f_i_textarea.on({
keyup:function(){
var _this = $(this);
if(_this.val().length > 0){
_f_parent_c.empty();
_f_parent_c.append(_f_i_send);
_f_i_send.on({
click:function(e){
_fdata.append("chatMsg", _this.val());
/**********/
_fdata.append("storeChatMsg", true);
_fdata.append("uid", uid);
$.load.animate($(this), "bounceIn", function(){
$.ajax({
url:url,
type:"post",
dataType:"json",
data:_fdata,
processData:false,
contentType:false,
cache:false,
timeout:2000,
beforeSend:function(){},
complete:function(){},
success:function(data){
checkTypingStatus(messageId);
},
error:function(xhr,textStatus, statusCode){
//alert(xhr.textStatus+xhr.statusCode);
}
});
_this.val("");
_f_parent_c.empty();
_f_parent_c.append(_f_i_heart);
_f_parent_c.append(_f_i_smileys);
click_heart(_f_i_heart);
showSmileys();
});
}
});
}else{
_f_parent_c.empty();
_f_parent_c.append(_f_i_heart);
_f_parent_c.append(_f_i_smileys);
}
},
focusin:function(){
setIsTyping(messageId,1);
},
focusout:function(){
setIsTyping(messageId,0);
}
});
function setIsTyping(id,status){
$.get(url,{setMessageInfo:true,action:"typing",status:status,id:id},function(data){
});
}
function checkTypingStatus(id){
$.getJSON(url,{setMessageInfo:true,action:"checkIfTyping",id:id},function(data){
var typingStatus = (data.is_typing == 1)?"is typing...":"";
$("#typing").text(" "+typingStatus);
});
}
checkTypingStatus();
setInterval(function(){
checkTypingStatus(messageId);
},3000);
/***
refresh chat after 5 secs
**/
function refreshChat(){
$.post(url,{fetchChatMsg:true,uid:uid},function(data){
//alert(data)
chatLogs(data,function(logs){
//_b.html(logs);
});
},"json");
//location.href = "#bottom";
}
refreshChat();
setInterval(function(){
refreshChat();
},3000);
/***
refresh chat after 5 secs
**/

function chatLogs(data,_return_){
//alert(data)
var c ="", ___attachment;
var __who = null;
if(data.length > 0){
for(var t =0; t < data.length; ++t){
if((data[t].file == null) || (data[t].file == '')){
___attachment = "";
}else{
___attachment = "<object onclick='$.load.loadImageModal({img:$(this)})' width='100%' height='150' data='../uploads/chats/"+data[t].file+"' src='../uploads/chats/"+data[t].file+"' data-src='../uploads/chats/"+data[t].file+"'></object>";
}
if(data[t].sid == sid){
__who = "user";
}else{
__who = "friend";
}
if(data[t].message === "heart"){
var _style = "transparent;color:red;font-size:xx-large";
var message = "❤" ;
}else{
message = data[t].message+"<span style=\"font-weight:800;padding:1px 5px;font-size:xx-small;float:right;margin:10px 0 0 auto;\">"+data[t].time+"</span>";
_style = "";
}
c += "<div class='chat_c'>";
c += "<div class='chat_p_r "+__who+"'>";
c += "<p class='t' style='background-color:"+_style+";'>"+message+"<br>"+___attachment+"</p>";
c += "</div>";
c += "<div style='display:none;' class='chat_p_l_img'></div>";
c += "</div>";
//_return_(chat_c);
}
c += "<span id='bottom'></span>";
_b.html(c);
}
_b.scrollTop(function() { return $(this).scrollHeight; });
}
_hbb.click(()=>{
_parent_.addClass("animated fadeOutRightBig faster");
     //history.back();
   //window.history.pushState({ path: location.pathname+"#chat-logs" }, '', history.go(-1));  
 });
 
 _hbb.on("animationend",function(){
 _hbb.removeClass("animated fadeOutRightBig faster");
});
$(document.body).append(_parent_);
if(q.where == undefined) window.history.pushState({ path: location.pathname+"#chat-logs" }, 'Messages', 'Messages');
};

//Smileys
$.load.loadSmileys = function(return_, doSomething){
var smileys___ = {
"like":"😍",
"laugh":"🤣",
"love":"❤",
"depressed":"😥",
"crying":"😭",
"applause":"👏",
"flower":"🌹",
"coffee":"☕",
"refreshed":"😇",
"heart-wrap":"💝",
"love-envelope":"💌",
"fire":"🔥",
"angel":"🧚‍♂️",
"banana":"🍌",
"raspberry":"🍇",
"raining":"🌧",
"jet":"🚀",
"earth":"🌏",
"dotknot":"🎯",
"hurray":"🎉",
"ghana":"🇲🇺",
"uk":"🇵🇷",
"nigeria":"🇳🇬",
"usa":"🇺🇸",
};
for(var i in smileys___){
var _all = $("<div id='smileys' data-name='"+i+"'>"+smileys___[i]+"</div>").css({
padding:"5px",
backgroundColor:"transparent",
//border:"1px solid white",
margin:"auto 5px",
fontSize:"xx-large",
});
_all.on("click",function(){
_this_ = $(this);
$.load.animate(_this_,"bounceIn",function(){
doSomething(_this_)
});
//alert(_this_.data("name"));
});
return_(_all);
}
};
$.load.filterSmileys = function(smileys___){
switch(smileys___){
case "like": f_smileys = "😍";
break;
case "laugh": f_smileys = "🤣";
break;
case "love": f_smileys = "❤";
break;
case "depressed": f_smileys = "😥";
break;
case "crying": f_smileys = "😭";
break;
case "applause": f_smileys = "👏";
break;
case "flower": f_smileys = "🌹";
break;
case "coffee": f_smileys = "☕";
break;
default: f_smileys = "";
}
return f_smileys;
};
$.load.list = function(q = null){
if(q !== null){
var sid = q.sid;
var click = q.click;
var clickId = q.clickId;
var cardId = q.cardId;
}
var parent__,parentListHolder, listHolder,list, url = "../checkpoint/server.post_content.php";
parent__ = $("<div class='animated slideInUp faster'></div>").css({
width:"90%",
height:"auto",
margin:"0 auto",
border:"1px solid #fff",
background:"rgba(0,0,0,.6)",
borderRadius:"10px 10px 0 0",
textAlign:"center",
});
parentListHolder = $("<div></div>").css({
width:"100%",
height:"500px",
background:"transparent",
overflow:"hidden",
overflowY:"scroll",
margin:"0px auto 30px auto",
textAlign:"left",
});
removeParent__ = $("<button></button>").css({
width:"20%",
padding:"2px",
color:"white",
border:"none",
borderRadius:"100px",
background:"#eee",
boxShadow:"0 2px 3px #fff",
margin:"2px auto",
});
var listCss = {
width:"100%",
padding:"5px",
color:"white",
fontSize:"medium",
fontWeight:"400",
};
parent__.append(removeParent__);
list = $("<p>Please wait...</p>").css(listCss);
$.getJSON(url,{actionOnMoment:"showViewers",momentID:cardId}).done(function(data){
if(data.length < 1){
list = $("<p>No views yet</p>").css(listCss);
parentListHolder.append(list);
}else{
for(var r = 0; r < data.length; ++r){
names = (data[r].sid == clickId)?"You":data[r].fullName;
smileys___ = data[r].reaction;
var __smiley = $.load.filterSmileys(smileys___);
list = $("<p>"+names+" &nbsp;"+__smiley+" <span style='float:right;font-size:12px;'>"+data[r].time+"</span></p>").css(listCss);
parentListHolder.append(list);
}
}
});
parent__.append(parentListHolder);
removeParent__.click(function(){
parent__.addClass("animated slideOutDown");
});
return parent__;
};
$.load.loadMomentModal = function(q = null){
var readMoment = false, m, h, b, s, f, hbb, hpc, hoi, url = "../checkpoint/server.post_content.php";
if(q !== null){
var sid = q.sid;
var click = q.click;
var clickId = q.clickId;
var clickBtn = q.btn;
var cardId = q.cardId;
if(click == "view"){
readMoment = true;
}

}
$.getJSON(url,{actionOnMoment:"view",by:clickId,from:sid,momentID:cardId}).done(function(data){
//alert(data)
});
m = $("<div class='animated slideInLeft faster'></div>").css({
position:"fixed",
top:"0",
left:"0",
width:"100%",
height:"100%",
display:"flex",
flexFlow:"column nowrap",
alignContent:"shrink",
justifyContent:"center",
alignItems:"shrink",
background:"#000",
zIndex:"99",
});
h = $("<div></div>").css({
width:"100%",
height:"auto",
display:"flex",
flexFlow:"row nowrap",
alignContent:"flex-start",
justifyContent:"flex-start",
alignItems:"flex-start",
background:"transparent",
});

controls = $("<div></div>").css({
width:"100%",
display:"flex",
flexFlow:"row nowrap",
alignContent:"flex-end",
justifyContent:"flex-end",
alignItems:"flex-end",
background:"transparent",
padding:'2px',
borderRadius:'10px',
});

hTextSettings = $("<div></div>").css({
width:"50px",
display:"flex",
flexFlow:"column nowrap",
alignContent:"shrink",
justifyContent:"center",
alignItems:"shrink",
background:"rgba(255,255,255,.1)",
position:'absolute',
top:'10%',
right:'10px',
padding:'10px 2px',
borderRadius:'10px',
});

//hbgSettings = $("<div class='slideContainer'></div>");
hbgtextSlider = $('<input type="range" min="20" max="150" value="24" id="myRange" class="slider">');



b = $("<textarea class='moment_textarea'></textarea>").css({
width:"100%",
whiteSpace:"wrap",
height:"75%",
//maxHeight:"100%",
backgroundColor:"transparent",
border:"none",
color:"white",
padding:"10px",
textAlign:"center",
fontSize:"xx-large",
lineHeight:"",
backgroundPosition:"center",
backgroundSize:"100%",
backgroundRepeat:"no-repeat",
//position:"relative",
});
b.prop("placeholder","Tap to write");
s = $("<div class='moment-container_'></div>").css({
position:"relative",
width:"100%",
height:"10%",
minHeight:'10%',
display:"flex",
flexFlow:"row nowrap",
alignContent:"flex-start",
justifyContent:"flex-start",
backgroundColor:"transparent",
whiteSpace:"nowrap",
overflow:"hidden",
overflowX:"scroll",
padding:"2px 4px",
});
f = $("<div></div>").css({
position:"relative",
width:"100%",
height:"10%",
display:"flex",
flexFlow:"row nowrap",
alignContent:"flex-start",
justifyContent:"flex-start",
alignItems:"center",
backgroundColor:"transparent",
});
hbb = $("<i class='fa fa-arrow-left'></i>&nbsp; ").css({
width:"20%",
padding:"10px",
color:"white",
background:"transparent",
fontSize:"large",
fontWeight:"500px",
});
hpc = $("<i class=''>n</i>").css({
width:"1%",
padding:"10px",
color:"white",
background:"red",
fontSize:"medium",
}).hide();
hoi = $("<button><i class='fa fa-ellipsis-v'></i></button>").css({
width:"auto",
padding:"10px",
color:"white",
fontSize:"medium",
padding:'2px 5px',
border:'none',
alignSelf:'flex-end',
background:'transparent',
}).hide();
btnCss_ = {
width:"40px",
height:"40px",
minWidth:"40px",
minHeight:"40px",
background:"transparent",
color:"white",
borderRadius:"50%",
border:"1px solid white",
margin:"auto",
};
var font = "sans-serif", fu, fi, fb, fimg, files, formData = new FormData();
fu = $("<button><i class='fa fa-image'></i></button>").css(btnCss_);
fi = $("<textarea name='moment' placeholder='Write your moment here...'></textarea>").css({
width:"70%",
height:"40px",
border:"1px solid white",
borderRadius:"100px",
background:"transparent",
outline:"none",
padding:"10px",
fontWeight:"500",
color:"white",
});
fb = $("<button><i class='fa fa-paper-plane'></i></button>").css(btnCss_);
var scs = {
width:"40px",
minWidth:"40px",
height:"40px",
//border:"1px solid white",
borderRadius:"50%",
margin:"auto 5px",
background:"#08A8B8",
backgroundPosition:'center',
backgroundRepeat:'no-repeat',
backgroundSize:'cover',

//boxShadow:'0 8px 4px 8px #08A8B8',
};

var scsText = {
width:"20px",
minWidth:"20px",
height:"20px",
border:"1px solid white",
borderRadius:"50%",
margin:"5px auto",
background:"#08A8B8",
backgroundPosition:'center',
backgroundRepeat:'no-repeat',
backgroundSize:'cover',
//boxShadow:'0 8px 4px 8px #08A8B8',
};

var scsControls = {
width:"40px",
minWidth:"40px",
height:"40px",
borderRadius:"50%",
margin:"auto 15px",
//background:"#08A8B8",
backgroundPosition:'center',
backgroundRepeat:'no-repeat',
backgroundSize:'100%',
alignSelf:'flex-end',
};

sc_font_increase_size = $("<div>F+</div>").css(scs).css({
padding:"1px 10px",
color:"#fff",
fontWeight:"500",
fontSize:"xx-large",
fontFamily:"cursive"
}).hide(); /* DEPRECATED */
sc_font_decrease_size = $("<div>F-</div>").css(scs).css({
padding:"1px 10px",
color:"#fff",
fontWeight:"500",
fontSize:"xx-large",
fontFamily:"cursive"
}).hide(); /* DEPRECATED */
hTextColorChangerOne = $('<div class="tcolor"></div>').css(scsText).css({backgroundColor:'rgb(138, 43, 226)'});
hTextColorChangerTwo = $('<div class="tcolor"></div>').css(scsText).css({backgroundColor:'rgb(165, 42, 42)'});
hTextColorChangerThree = $('<div class="tcolor"></div>').css(scsText).css({backgroundColor:'rgb(173, 255, 47)'});
hTextColorChangerFour = $('<div class="tcolor"></div>').css(scsText).css({backgroundColor:'rgb(100, 149, 237)'});
hTextColorChangerFive = $('<div class="tcolor"></div>').css(scsText).css({backgroundColor:'rgb(0, 100, 0)'});
hTextColorChangerSix = $('<div id="tcolor"></div>').css(scsText).css({backgroundColor:'rgb(30, 144, 255)'});

c1 = $('<div></div>').css(scsControls).css({backgroundImage:'url("../img/texter.png")'});
c2 = $('<div>😇</div>').css(scsControls).css({fontSize:c1.css('height'),background:'transparent'}); //.css({backgroundImage:'url("../img/emoji.jpeg")'});
c3 = $('<div></div>').css(scsControls);
//c4 = $('<div></div>').css(scs);
//c5 = $('<div></div>').css(scs);

controls.append(c1);
//controls.append(c2);
//controls.append(c3);
//controls.append(c4);
//controls.append(c5);

c1.click(function(){
hTextSettings.toggle('fast','linear');
});
c2.click(function(){
s.toggle(); 
});
hoi.click(function(){
controls.toggle(); 
});

function setTextColor(){
$.load.animate($(this),'bounceIn');
bgColor = $(this).css('background-color');
b.css({color:bgColor});
return;
}

hTextColorChangerOne.click(setTextColor);
hTextColorChangerTwo.click(setTextColor);
hTextColorChangerThree.click(setTextColor);
hTextColorChangerFour.click(setTextColor);
hTextColorChangerFive.click(setTextColor);
hTextColorChangerSix.click(setTextColor);



hTextSettings.append(hTextColorChangerOne);
hTextSettings.append(hTextColorChangerTwo);
hTextSettings.append(hTextColorChangerThree);
hTextSettings.append(hTextColorChangerFour);
hTextSettings.append(hTextColorChangerFive);
hTextSettings.append(hTextColorChangerSix);
hTextSettings.append(hbgtextSlider);

var sc_color = $("<input type='color'>").css(scs);
var sc_font = $("<div>F</div>").css(scs).css({padding:"1px 10px",color:"#fff",fontWeight:"500",fontSize:"xx-large",fontFamily:"cursive"});
s.append(sc_color);
s.append(sc_font);
sc_font.after(sc_font_increase_size);
sc_font.after(sc_font_decrease_size);
var myFonts = ["cursive","sans-serif","fantasy","monospace","cursive","cursive","sans-serif","fantasy","monospace","sans-serif","fantasy","monospace"];
sc_font.on("click",function(){
n = Math.floor(Math.random() * 10);
for(var t in myFonts){
if(t == n){
$(this).css({fontFamily:myFonts[t]});
font = myFonts[t];
b.css({fontFamily:myFonts[t]});
}else{
continue;
}
}
});

hbgtextSlider.on("input",function(){
b.css({
fontSize:$(this).val()+'px',
});
});

/* DEPRECATED */
/*sc_font_increase_size.on("click",function(){
b.css({
fontSize:"+=5px",
});
});
sc_font_decrease_size.on("click",function(){
b.css({
fontSize:"-=5px",
});
});*/

var smileys = {
"like":"😍",
"laugh":"🤣",
"love":"❤",
"depressed":"😥",
"crying":"😭",
"applause":"👏",
"flower":"🌹",
"coffee":"☕"
};
$.load.loadSmileys(
//Append smileys to div
function(smileys){
s.append(smileys);
},
//Do something when smileys is clicked
function(_smileys_btn_){
smileyName = _smileys_btn_.data("name");
ivb = b.val();
ivb = ""+ivb+_smileys_btn_.html();
if(!readMoment) b.val(ivb);
//alert(_smileys_btn_.data("name"));
});
fimg = $("<input type='file' name='myMoment'>");
fu.on("click",function(){
fimg.click();
 });
fimg.on("change", function(){
myExt = ["mp4","3gp","gif","ogg","png","jpg","jpeg"]; 
files = this.files;
$.load.preloadImage(this, myExt, function(e){
//alert(e.target.s);
b.css({backgroundImage:"url('"+e.target.result+"')"});
$.each(files, function(i,file){
formData.append("mFile",file);
});
});
});
if(readMoment){
b.prop("disabled","disabled");
sc_color.hide();
sc_font.hide();
hTextSettings.hide();
c1.hide();
sc_font_decrease_size.hide();
sc_font_increase_size.hide();
$.getJSON(url,{fetchMomentOnClick:true,where:sid,cardId:cardId},function(data){
data = data[0];
$('#theme-color').prop('content',data.bg);
f.empty();
b.css({backgroundImage:"url('../uploads/moment/"+data.file+"')"});
m.css({backgroundColor:data.bg});
b.css({fontFamily:data.font});
b.css({fontSize:data.fontSize});
b.css({color:data.txtColor});
b.val(data.text);
_text_color = (data.bg == 'rgb(255, 255, 255)')?'#000':'#fff';
hbb.css({color:_text_color});
$("div#smileys").click(function(){
smiley_name = $(this).data("name");
sm__ = $(this);
sm__.addClass("animated zoomInUp faster");
sm__.on("animationend",function(){
sm__.removeClass("animated zoomInUp faster");
});
$.get(url,{actionOnMoment:"react",smiley_name:smiley_name,by:clickId,from:sid,momentID:cardId}).done(function(data){
//alert(data)
$("div#smileys").css({backgroundColor:"transparent",boxShadow:"none"});
sm__.css({backgroundColor:"red",boxShadow:"0 2px 5px #eee"});
});
});
});
var viewViewers = $("<div><i class='fa fa-eye'></i></div>").css(scs).css({
fontSize:"large",
color:"#fff",
textAlign:"center",
padding:"2.5%"
});
sc_font.after(viewViewers);
viewViewers.on("click",function(){
var displayViewers = $.load.list({
sid: sid,
click: click,
clickId: clickId,
cardId: cardId
});
f.html(displayViewers);
});
}else{
$('#theme-color').prop('content','#000');
}
h.append(hbb);
h.append(controls);
h.append(hpc);
h.append(hoi);
f.append(fu);
f.append(fi);
f.append(fb);
m.append(h);
//m.append(controls);
m.append(hTextSettings);
//m.append(hbgSettings);
m.append(b);
m.append(s);
m.append(f);
hbb.click(()=>{m.addClass("animated slideOutLeft faster"); hbb.off(); m.off();   $('#theme-color').prop('content','#FFFFFF'); });
sc_color.on("change",function(){
if($(this).val() == "#ffffff"){
hbb.css({color:"#000000"});
fu.css({color:"#000000",border:"1px solid #000000"});
fi.css({color:"#000000",border:"1px solid #000000"});
fb.css({color:"#000000",border:"1px solid #000000"});
b.css({color:"#000000"});
}else{
hbb.css({color:"#ffffff"});
fu.css({color:"#ffffff",border:"1px solid #ffffff"});
fi.css({color:"#ffffff",border:"1px solid #ffffff"});
fb.css({color:"#ffffff",border:"1px solid #ffffff"});
b.css({color:"#ffffff"});
}
m.css({background:$(this).val()});
$('#theme-color').prop('content',$(this).val());
});
b.on({keyup:function(){
iv = $(this).val();
iv = iv.replace(/(^|\s)(<[a-z\d-]+)/ig," ");
iv = iv.replace(/(^|\s)([#@][a-z\d-]+)/ig,"<span class='hash'>$2</span>");
if(iv.length > 200){
fb.css({visibility:"hidden"});
}else{
fb.css({visibility:"visible"});
}
b.val(iv);
},
focusin:function(){
b.prop("placeholder","Write something cool..");
},
focusout:function(){
b.prop("placeholder","Tap to write");
}
});
fb.on({
click:function(){
//alert(iv);
//return false;
if((b.val().trim().length < 1) && (b.css("background-image") == "none")) return false;
var mComment = b.val();
mComment = mComment.replace(/(^|\s)([#@][a-z\d-]+)/ig,"<span class='hash'>$2</span>");
formData.append("mComment",mComment);
formData.append("storeMoment",true);
formData.append("font",font);
formData.append("bg",m.css("background-color"));
formData.append("fontSize",b.css("font-size"));
formData.append("txtColor",b.css('color'));
$.ajax({
url:url,
type:"post",
dataType:"json",
data:formData,
processData:false,
contentType:false,
cache:false,
beforeSend:function(){
fb.html("<i class='fa fa-hourglass-half'></i>");
},
complete:function(){
fb.html("<i class='fa fa-check'></i>");
b.val("");
},
success:function(data){
//alert(data)
if(data == true){
fb.html("<i class='fa fa-paper-plane'></i>");
}else{
//alert(data)
fb.html("<i class='fa fa-exclamation-triangle'></i>");
setTimeout(function(){
fb.html("<i class='fa fa-paper-plane'></i>");
},2000);
}
},
error:function(a, b, c){
//alert(a.b+" "+a.c);
}
});
}
});
fi.css({visibility:"hidden"});
return $(document.body).append(m);
};
$.load.preloadImage = function(file, validExt, use){
$(file).change(function () {
        var imgPath = this.value;
        var ext = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
        if (validExt.indexOf(ext) > -1)
          return  readURL(this, ext);
        else
            alert("Please select file of the following type ("+validExt.join(", ")+").")
    });    
    function readURL(input, ext) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.readAsDataURL(input.files[0]);
            reader.onload = function (e) {
          		use(e);
           };
        }
    }
   return;
}
$.load.moments_card = function(params = null){
var head_parag = (params.header == null)?"":params.header;
var where = (params.where == null)?"":params.where;
var _sessPic = (params.sessPic == null)?"":params.sessPic;
consoleCss_ = {
display:"flex",
flexFlow:"row nowrap",
alignContent:"flex-start",
justifyContent:"flex-start",
width:"auto",
margin:"0",
whiteSpace:"nowrap",
overflow:"hidden",
overflowX:"scroll",
background:"#aaa",
};
imgCss_ = {
width:"50px",
height:"50px",
minHeight:"50px",
minWidth:"50px",
//background:"rgb(255,0,255)",
color:"white",
borderRadius:"50%",
border:"3px solid rgb(255,0,255)",
margin:"auto 5px",
//backgroundImage:"url('./img/pp3.jpg')",
backgroundSize:"cover",
backgroundPosition:"center",
};
var add_moment = {
width:"50px",
height:"50px",
minHeight:"50px",
minWidth:"50px",
//background:"rgb(255,0,255)",
//backgroundImage:"url('../img/pp3.jpg')",
backgroundPosition:"center",
backgroundRepeat:"no-repeat",
backgroundSize:"cover",
color:"white",
padding:"5%",
textAlign:"center",
fontSize:"xx-large",
borderRadius:"50%",
border:"1px solid #eee",
margin:"auto 5px",
boxShadow:"0 2px 5px #aaa",
}
var url = "../checkpoint/server.post_content.php";
var parentContainer_ = $("<div></div>").css({width:"100%"});
var header = $("<p></p>").css({padding:"5px 0",fontSize:"+=10px"});
var p_div = $("<div></div>").css({display:"flex"});
var d1 = $("<div></div>").css({minWidth:"70px",textAlign:"center"});
var d2 = $("<div class='moment-container'></div>"); //.css(consoleCss_);
var card_name = $("<p>"+head_parag+"</p>").css({fontWeight:"500",padding:"5px 0 0 0"});
var add = $("<button class='hover'>+</button>").css(add_moment);
d1.append(add);
d1.append(card_name)
p_div.append(d1);
add.css({
backgroundImage:"url('../uploads/profile/"+_sessPic+"')",
});
$.load.refreshMoment = function(){
$.getJSON(url,{fetchMoment:true,where:where},function(data){
pp = "";
for(var i = 0; i < data.length; ++i){
pp += "<div class='m_card_p hover' data-card_id='"+data[i].id+"' data-sid='"+data[i].sessionId+"' data-uid='"+data[i].sid+"'>";
pp += "<div style='background-color:"+data[i].bg+";border:3px solid "+data[i].bg+"; background-image:url(\"../uploads/profile/"+data[i].profilePic+"\")' class='m_card_p_first'></div>";
pp += "<p class='card_name'>"+data[i].fullName+"</p>";
pp += "</div>";
}
d2.html(pp);

$("div.m_card_p").on("click",function(){
var btn = $(this);
var sid = btn.data("uid");
var clickId = btn.data("sid");
var cardId = btn.data("card_id");
$.load.loadMomentModal({sid:sid,click:"view",clickId:clickId,btn:btn,cardId:cardId});
});
});
};
$.load.refreshMoment();
setInterval($.load.refreshMoment,5000);
p_div.append(d2);
parentContainer_.append(header);
parentContainer_.append(p_div);
add.on("click",function(){
var btn = $(this);
$.load.loadMomentModal(null);
});
d2.hover(
function(){

},
function(){

 });
return parentContainer_
};
/* Moments ends */
$.load.loadImageModal = function(obj = null){
var src = (obj.src != null)?obj.src:obj.img.prop("src");
//alert(src)
//"../uploads/chats/"+
var bgCss = {
background:"black",
width:"100%",
height:"100%",
position:"fixed",
top:"0px",
left:"0px",
zIndex:"99999",
//filter:"grayscale(100%)",
};
var containerCss ={
width:"100%",
height:"98%",
background:"black",
display:"flex",
flexFlow:"row wrap",
justifyContent:"flex-start",
alignContent:"flex-start",
alignItems:"center",
margin:"auto",
};
var consoleCss = {
display:"flex",
flexFlow:"row nowrap",
alignContent:"flex-start",
justifyContent:"flex-start",
width:"100%",
maxWidth:"95%",
padding:"10px",
//alignSelf:"flex-start",
borderBottom:"0.5px solid #aaa",
//margin:"auto auto auto 0",
};
var imgCss = {
width:"100%",
height:"auto",
maxHeight:"80%",
background:"black",
color:"white",
borderRadius:"5px",
border:"none",
alignSelf:"center"
};
var txtAreaCss = {
width:"100%",
height:"50px !important",
background:"#eee",
borderRadius:"100px",
padding:"10px 20px",
border:"none",
margin:"auto"
};
var parentContainer = $("<div></div>").css(bgCss).addClass("animated slideInRight faster");
var topBar = $("<div></div>").css({
position:"sticky",
top:"0",
background:"black",
width:"100%",
height:"auto",
padding:"5px 2px",
display:"flex",
flexFlow:"row nowrap",
justifyContent:"flex-start",
alignContent:"flex-start",
alignSelf:"flex-start",
});
var topBarBackBtn = $("<i class='fa fa-arrow-left'></i>").css({
width:"auto",
padding:"10px 5px",
margin:"5px",
//background:"#aaa",
fontSize:"medium",
maxWidth:"90%",
overflow:"hidden",
textOverflow:"ellipsis",
whiteSpace:"nowrap",
color:"white"
});
topBar.append(topBarBackBtn);
parentContainer.append(topBar);
parentContainer.append($("<div></div>").append($("<img src='"+src+"'>").css(imgCss)).css(containerCss));
topBarBackBtn.on("click",function(){
parentContainer.addClass("animated slideOutRight faster");
});
return $(document.body).append(parentContainer);
}
/*  */
$.load.loadReplies = function(btn = null, param = null){
if(btn == null){
btn = '<button data-commentdate="'+param.date+'" data-commenterid="'+param.sid+'" data-commentid="'+param.id+'">Load replies • (23k) </button>';
}
var bgCss = {
background:"#fff",
width:"100%",
height:"100%",
position:"fixed",
top:"0px",
left:"0px",
overflow:"hidden",
overflowY:"scroll",
zIndex:"10"
};
var containerCss ={
width:"100%",
height:"auto",
background:"white",
padding:"10px",
margin:"5px auto",
textAlign:"center"
};
var consoleCss = {
display:"flex",
flexFlow:"row nowrap",
alignContent:"flex-start",
justifyContent:"flex-start",
width:"100%",
maxWidth:"95%",
padding:"10px",
//alignSelf:"flex-start",
borderBottom:"0.5px solid #aaa",
//margin:"auto auto auto 0",
};
var imgCss = {
width:"35px",
height:"35px",
minHeight:"35px",
minWidth:"35px",
background:"rgb(255,0,255)",
color:"white",
borderRadius:"50%",
border:"none",
margin:"auto 15px auto auto",
};
var txtAreaCss = {
width:"100%",
height:"50px !important",
background:"#eee",
borderRadius:"100px",
padding:"10px 20px",
border:"none",
margin:"auto"
};
var currentLoc = $(window.location).attr("href");
locHref = currentLoc.split("&");
locHref.shift();
var strParams = locHref.join("&")+"&commentId="+$(btn).data("commentid")+"&commenterId="+$(btn).data("commenterid");
var url = "../checkpoint/server.post_content.php";
//var openReplyModal = currentLoc.split("#").pop();
var parentContainer = $("<div></div>").css(bgCss).addClass("animated slideInRight faster");
var topBar = $("<div></div>").css({
position:"sticky",
top:"0",
background:"#fff",
width:"100%",
height:"auto",
padding:"5px 2px",
borderBottom:"1px solid #eee",
display:"flex",
flexFlow:"row nowrap",
justifyContent:"flex-start",
alignContent:"flex-start",
boxShadow:"0 2px 5px #eee"
});
var topBarBackBtn = $("<i class='fa fa-arrow-left'></i>").css({
width:"auto",
padding:"10px 5px",
margin:"5px",
//background:"#aaa",
fontSize:"medium",
maxWidth:"90%",
overflow:"hidden",
textOverflow:"ellipsis",
whiteSpace:"nowrap",
}).data("href","../comment.hardcoding?views#replies");
var tsclb = $("<button><i style='font-size:x-large;font-weight:400;' class='fa fa-thumbs-up'></i></button>").css({
width:"auto",
padding:"10px 5px",
margin:"0",
background:"transparent",
border:"none",
});
topBar.append(topBarBackBtn);
topBar.append(tsclb);
parentContainer.append(topBar);
topBarBackBtn.on("click",function(){
parentContainer.addClass("animated slideOutRight faster");
});
$.ajax({
url:url,
type:"post",
dataType:"json",
data:"fetchReplies=true&"+strParams,
success:function(data){
//alert(data)
if(data.length < 1){
card = card.html($("<p>No comments</p>").css({
textAlign:"center",
fontWeight:"400",
fontSize:"medium",
margin:"25% auto",
color:"#aaa"
}));
parentContainer.append(card);
return;
}
topBarBackBtn.html("&nbsp; Replies <font style='color:#aaa;font-weight:400;font-size:small;'> - "+data[0].parent_comment_name+"'s comment • "+$(btn).data("commentdate")+"</font>");
for(var i = 0; i < data.length; ++i){
card = $("<div></div>").css(consoleCss);
 img = $("<img src='../uploads/profile/"+data[i].commenter_pic+"'>").css(imgCss);
 header = $("<div></div>").css({
 width:"100%",
// borderBottom:"0.5px solid #aaa",
 padding:"5px",
 background:"",
 borderRadius:"10px",
 });
pName = $("<p>"+data[i].commenter_fullName+" <span style='color:#aaa;font-weight:400;font-size:smaller;'> @"+data[i].commenter_userName+"</span></p>").css({
fontSize:"small",
fontWeight:"700",
margin:"auto auto 5px auto",
});
replies = $("<p>"+data[i].comment_text+"</p>").css({
fontSize:"small",
fontWeight:"400",
});

/*
$("button#parent-comment-btn").on("click", function(){
  var btn = $(this);
  btn.addClass("animated bounceIn faster");
  var who = (btn.data("uid") == "<?php echo $_SESSION['id']; ?>")?"your ":"@"+btn.data("postername");   
  
  var objInfo = {
  sessImg : sessImg,
  params :{
  pid:btn.data("pid"),
  uid:btn.data("uid"),
  action:(btn.data("action")=="reply")?"replying to "+who+" comment":"comment on "+who+" post",
  name:btn.data("postername")
  }
  };
  
  var commentBox = $.load.loadCommentModal(objInfo);
  $(document.body).append(commentBox);
   btn.on("animationend", function (){
   btn.removeClass("animated bounceIn faster");
    });
  });  

*/

bottom = $("<div>"+data[i].date+" • 34 likes •<button onclick='$.load.loadReplies(null, {id:6,sid:6,date:23});'> 45 replies</button> • </div>").css({
padding:"5px 0 1px 0",
fontWeight:"400",
fontSize:"small",
color:"#aaa"
});

bottom.append($("<button onclick='alert(\"liked\")'><i class='fa fa-heart'></i></button>")
.css({fontWeight:'400',margin:'auto 5px',color:'#aaa',border:'none',background:'transparent'}));

bottom.append($("<button onclick='$.load.loadCommentModal({})'><i class='fa fa-comment'></i></button>")
.css({fontWeight:'400',margin:'auto 5px',color:'#aaa',border:'none',background:'transparent'}));


card.append(img);
header.append(pName);
header.append(replies);
header.append(bottom);
card.append(header);
parentContainer.append(card);
}
},
error:function(xhr, statusCode, textStatus){
//alert(textStatus+"++++++"+xhr.statusCode+"++++"+xhr.textStatus);
}
});
return $(document.body).append(parentContainer);
}



$.load.replySystem = function(replyBtn, callback){
$(replyBtn).on("click",function(){
var btn = $(this);
btn.addClass("animated bounceIn faster");
btn.on("animationend", function (){
btn.removeClass("animated bounceIn faster");
 }); 
var obj = {
sessImg : btn.data("sspic"),
params :{
pid:btn.data("pid"),
uid:btn.data("commenterid"),
action:(btn.data("action")=="reply")?"replying to "+btn.data("postername")+" comment":"comment on "+btn.data("postername")+" post",
parent_id:btn.data("parentid"),
isReply:true,
name:btn.data("postername")
}
};
var commentBox = $.load.loadCommentModal(obj);
callback(commentBox);
});
};
function nl2br(str, is_xhtml) {   
  var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';    
  return (str + ' ').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1'+ breakTag +'$2');
}
function getHasTagAry( msgTxt, finder ) {     
var msgTxtAry = msgTxt.split(' ') || msgTxt.split('');
var hash = []
for(var i = 0; i < msgTxtAry.length; i++) {
if( msgTxtAry[i].indexOf(finder) > -1 )
hash.push(msgTxtAry[i].trim());
}
return hash;
}    
$.load.search = function(btn){
var modalCss = {
position:"relative",
width:"100%",
height:"100%",
background:"#fff",
zIndex:"10"
};
imgCss = {
width:"35px",
height:"35px",
minHeight:"35px",
minWidth:"35px",
background:"#eee",
color:"#333",
fontWeight:"1000",
borderRadius:"50%",
border:"none",
margin:"auto 5px",
overflow:"hidden"
};
consoleCss = {
display:"flex",
flexFlow:"row nowrap",
alignContent:"center",
justifyContent:"flex-start",
width:"100%",
margin:"10px auto",
padding:"10px",
//boxShadow:"0 2px 5px #aaa",
//borderRadius:"100px"
};
var url = "../checkpoint/server.post_content.php";
var ph = btn.attr("placeholder");
var parent = btn.parent();
var modal = $("<div></div>").addClass("animated slideInDown faster").css(modalCss);
var closeInput = $("<button>×</button>").css(imgCss);
 modal.on("animationend",function(){
parent.children(":nth-child(2)").html(closeInput);
btn.attr("placeholder","You can also search by tag name...");
 });
btn.focusout(function(){
parent.children(":nth-child(2)").html("");
});
closeInput.click(function(){
modal.parent().hide("fast");
$(this).hide("fast");
btn.val("");
btn.attr("placeholder","I hope you found what you're looking for...");
setTimeout(function(){
btn.attr("placeholder","Search again...");
}, 3000);
});
btn.on("keyup", function(){
if($(this).val() == ""){ modal.html(""); return false; }
$.ajax({
url:url,
type:"get",
dataType:"json",
beforeSend:function(){
modal.html("Loading...");
},
data: {getSearchResult:$(this).val()},
success:function(data){
modal.html("");
for(var i = 0;i < data.length; ++i){
var link = $('<a data-carduid="'+data[i].uid+'" data-href="../profile.php?rdrid='+data[i].uid+'&frm=notification"></a>');
var card = $("<div data-href='../profile.php'></div>").css(consoleCss).addClass("animated zoomIn faster");
var icon = $("<div></div>").css(imgCss).css({width:"50px",height:"50px",border:"1px solid #eee"});
var name = $("<p>"+data[i].fullName+"<br /> <i style='font-weight:400;color:#aaa;'>@"+data[i].userName+"</i></p>").css({alignSelf:"center",fontSize:"+12px",padding:"0px 10px"});
icon.append($("<img>").prop("src","../uploads/profile/"+data[i].profilePic).css({width:"100%"}));
card.append(icon);
card.append(name);
link.append(card);
modal.append(link);
link.on("click",function(){
var pageUrl = $(this);
$.ajax({
    url: pageUrl.data("href"),
    success: function (data) {
        $("#_body_").html(data);
    }
});    
 if (pageUrl.data("href") != window.location) {
 window.history.pushState({ path: pageUrl.data("href") }, pageUrl.data("title"), pageUrl.data("href"));
}
});
}
if(data[0].substring(0,2) == "No"){
modal.html(data[0]);
}
}
});
});
return modal;
};



$.load.suggestion_card_inline = function(params, use){
var _a = '', _b = $('<div></div>'), _c,rows;
var title = params.title;
var limit = params.limit;
var node, style, action, btn;

$.getJSON($.load.server(),{getSuggestedUser:true,limit:limit}).done(function(data){


_a += '<div class="xyz_c" >';
_a += '<h1>'+title+' <span><button><i class="fa fa-angle-down" ></i></button></span></h1>';

for(var i in data ){
rows = data[i];

if(rows.isFollowing){
node = 'following';
style = 'color:#F1F1F1;background-color:#FFF;border:2px solid rgba(0,0,200,.05);';
action = 1;
}else{
node = 'follow';
style = '';
action = 0;
}

_a += '<div class="xyz_s hover" >';
_a += '<div data-href="../profile?rdrid='+rows.uid+'&token='+rows.uniqvar+'&frm=home" style="background-image:url(\'../uploads/profile/'+rows.profilePic+'\');" class="xyz_s_i" ></div>';
_a += '<p class="xyz_p" ><b>'+rows.fullName+'&star; <font>@'+rows.userName+'</font></b>';
_a += '<button id="sfollow" style="'+style+'" class="xyz_f_btn hover" data-uid="'+rows.uid+'" data-uname="'+rows.fullName+'" data-action="'+action+'" >'+node+'</button><br>';
_a += '<span>'+rows.bio.substr(0,150)+'...</span>';
_a += '</p></div>';

}
_a += '</div>';
_b.html(_a);
use(_b.html());

$('div.xyz_s_i').click(function(){
pageUrl = $(this);
$.realMeet.loadContent();
});
var params = {};
$('button#sfollow').on({
click:function (){
var btn = $(this);
var action = btn.data('action');
if(action == 0){
/* if action is 0...then follow*/
params.actionOnPost = "following";
params.who = $(this).data('uid');
$.load.follow(params, function(){
btn.text('following');
btn.css({border:'2px solid rgba(0,0,200,.05)',backgroundColor:'#fff',color:'#F1F1F1'});
btn.data('action', 1);
});
}else{
/* else unfollow.... action set to 1*/
__o = {
title:'Notification!',
text:'Do you want to unfollow <b>'+btn.data('uname')+'</b>?',
action_btn_text:'Unfollow'
};
params.actionOnPost = "unfollow";
params.who = $(this).data('uid');
$.load.alert(__o,function(callback){
$.load.unfollow(params, function(status){
btn.data('action', 0);
btn.html('follow');
btn.css({backgroundColor:'#08A8B8',color:'#fff'});
if(typeof  callback == 'function') callback(status);
});
});


}

}
});


}).always(function(){
$('.xyz_c').append($('<button data-href="../views?_cd=1" class="_loadMore hover">Load more</button>').css({border:'none',backgroundColor:'transparent',padding:'10px 5px',color:'#08a8b8',margin:'auto',display:'block'}));
$('button._loadMore').click(function(){
pageUrl = $(this);
$.realMeet.loadContent();
});
});



};


$.load.suggestion_card = function(query=null){
var orientation;
if(query != null){
orientation = query.css.orientation;
width = query.css.width;
margin = query.css.margin;
title = query.title;
}else{
orientation = "row";
width = "";
margin = "";
title = "Suggested for you:";
}

consoleCss = {
display:"flex",
flexFlow:orientation+" nowrap",
alignContent:"flex-start",
justifyContent:"flex-start",
width:"auto",
margin:"0",
whiteSpace:"nowrap",
overflow:"hidden",
overflowX:"scroll",
};
imgCss = {
position:"absolute",
bottom:"10px",
left:"10px",
width:"50px",
height:"50px",
minHeight:"50px",
minWidth:"50px",
background:"#833F05",
color:"white",
borderRadius:"50%",
backgroundPosition:'center',
backgroundRepeat:'no-repeat',
backgroundSize:'cover',
border:"1px solid #fff",
//margin:"auto 5px",
};


var url = "../checkpoint/server.post_content.php";
var parentContainer = $("<div></div>").css({width:"100%",backgroundColor:'#fff',margin:'1px auto',padding:'5px 0'});
parentContainer.append("<h2 style='padding:1px 10px;font-weight:600;font-size:medium;'>"+title+"<button class='sgt-see-more'><i class='fa fa-angle-down'></i></button></h2>");
var card_container = $('<div class="sgt-card-container" ></div>').css(consoleCss);
$.getJSON(url,{getSuggestedUser:true}).done(function(data){
for(var i = 0; i < data.length; ++i){
var wallpaper = (data[i].wallpaper == null)?"":data[i].wallpaper;
//alert(wallpaper)
var isNew = (data[i].isNewUser === true)?"<br /><span style='border:1px solid #aaa;border-radius:5px;color:#333;background:transparent;padding:1px 3px;'>New</span>":"";
var followedBy = (data[i].followedBy > 0)?"followed by "+data[i].followedBy+" users" :'';
var __bio = (data[i].bio == '' || data[i].bio == null)?'<br><br>':'<br><span>'+data[i].bio+'</span>';
//var isFollowing = (data[i].isFollowing === 1)?"Following":"Follow";
var card_card = $('<div style="width:'+width+';margin:'+margin+';" class="sgt-card hover"></div>');
var card_photo_container = $('<div class="sgt-icon"></div>').css({position:"relative"});
var pp_photo = $("<div></div>").css(imgCss);
var card_photo_img = $('<img>');
var card_name = $('<p class="sgt-name" ></p>');
var others = $('<p class="sgt-otherInfo">'+followedBy+__bio+'</p>');
var card_action_btn = $('<div class="sgt-card-action" ></div>');
var card_follow_btn = $('<button class="sgn-fb hover" data-uname="'+data[i].fullName+'" data-action="0" data-uid="'+data[i].uid+'"><i class="fa fa-user-plus"></i> Follow</button>').css({background:"#08A8B8",boxShadow:"4px 4px 4px rgba(0,0,200,.05)",color:"#fff"});
var card_cancel_btn = $('<button class="sgn-cb hover">Close</button>');
var card_unfollow_btn = $('<button class="sgn-cb hover" data-uid="'+data[i].uid+'">following</button>');
var vvuid = data[i].uid;
var f_btn_html = card_follow_btn.html();
card_action_btn.append(card_follow_btn);
card_action_btn.append(card_cancel_btn);


card_photo_container.append(card_photo_img);
card_photo_container.append(pp_photo);
card_card.append(card_photo_container);
card_card.append(card_name);
card_card.append(others);
card_card.append(card_action_btn);


if(data[i].isFollowing === 1){
card_cancel_btn.hide();
card_follow_btn.attr('class','sgn-cb hover');
card_follow_btn.data('action',1);
card_follow_btn.text('Following');
card_follow_btn.css({backgroundColor:'#eee',color:'#000'});
}



card_photo_container.css({backgroundImage:"url('../uploads/profile/"+wallpaper+"')"})

//card_photo_img.prop("src","../uploads/profile/"+wallpaper);
pp_photo.css("background-image","url('../uploads/profile/"+data[i].profilePic+"')");


card_name.html(data[i].fullName+" <i style='color:#aaa;font-weight:400;'>@"+data[i].userName+"</i> &nbsp;"+isNew);
card_container.append(card_card);
parentContainer.append(card_container);

var params = {};

card_follow_btn.on({
click:function (){
var btn = $(this);
var action = btn.data('action');
if(action == 0){
/* if action is 0...then follow*/
params.actionOnPost = "following";
params.who = $(this).data('uid');
$.load.follow(params, function(){
//btn.parent().html(card_unfollow_btn);
btn.next().hide();
btn.text('Following');
btn.css({backgroundColor:'#eee',color:'#000'});
btn.data('action', 1);
});
}else{
/* else unfollow.... action set to 1*/
__o = {
title:'Notification!',
text:'Do you want to unfollow <b>'+btn.data('uname')+'</b>?',
action_btn_text:'Unfollow'
};
params.actionOnPost = "unfollow";
params.who = $(this).data('uid');

$.load.alert(__o,function(callback){
$.load.unfollow(params, function(status){
btn.next().show();
btn.data('action', 0);
btn.html(f_btn_html);
btn.css({backgroundColor:'#08A8B8',color:'#fff'});
if(typeof  callback == 'function') callback(status);
});
});


}

}
});

card_cancel_btn.click(function(){
$(this).parent().parent().hide("fast");
});
}
//parentContainer.append($('<button>See all</button>').css({width:"100%",padding:"10px",background:"#eee",fontWeight:"500",border:'none',borderRadius:"10px",margin:"10px 0"}));
$("button.sgt-see-more").on('click',function(){
var href = "../home";
var _this = $(this);
var params = [
{title:"See more ",pid:'',uid:'',sid:'',type:'stop-sgt',href:href,fa:"<i style='' class='fa fa- _obj_commands'></i>"},
{title:"Why am i seeing this? ",pid:'',uid:'',sid:'',type:'why-sgn',href:href,fa:"<i style='' class='fa fa-exclamation-triangle _obj_commands'></i>"},
{title:"Stop seeing this ",pid:'',uid:'',sid:'',type:'stop-sgt',href:href,fa:"<i style='' class='fa fa-times _obj_commands'></i>"},
];
var modal_object = {href:href,params:params};
var modal = $.load.LoadModal(modal_object);
$(document.body).append(modal);
});

});

return parentContainer;
};

/* FOLLOW SKELETAL method */
$.load.FOLLOW = function(data, callback, debug = false){
userData = {};
userData.actionOnPost = (data.data('type') == 'follow')?'following':data.data('type');
userData.who = data.data('who');

$.ajax({
url: $.load.server(),
type:"post",
dataType:(!debug)?'json':'',
data:userData,
success:function(data){ 
if(debug){alert(data); }
if(data.status === true ){
if(typeof callback == 'function') callback(data);
}
},
error:function(){  }
});
return;
}

/* unFollow method */
$.load.unfollow = function(userdata, callback){
$.ajax({
url: $.load.server(),
type:"post",
dataType:"json",
data:userdata,
success:function(data){ 
if(data.status === true ){
if(typeof callback == 'function') callback(data);
}
},
error:function(){  }
});
return;
}


/* Follow method */
$.load.follow = function(userdata, callback){
$.ajax({
url: $.load.server(),
type:"post",
dataType:"json",
data:userdata,
success:function(data){ 
if(data.status === true ){
if(typeof callback == 'function') callback();
}
},
error:function(){  }
});
return;
}



$.load.updateWallpaper = function(){
var uploader = $("<input type='file' name='file'>");
var url = "../checkpoint/server.post_content.php";
uploader.click();
uploader.change(function(e){
var fdata = new FormData();
fdata.append("updateWallpaper",true);
//alert(e.target.files.length)
fdata.append("file",e.target.files[0]);
$.post({
url:url,
data:fdata,
dataType:"json",
processData:false,
contentType:false,
cache:false
}).done(function(data){
//callback(e);
 $("#wallpaper").css("background-image","url('../uploads/profile/"+data.wallpaper+"')");
var msg = "Wallpaper has been uploaded successfully.\n\nPlease refresh page.";
$.load.notification({msg:msg},function(c){
		setTimeout(function(){
		c.addClass('animated slideOutUp');
	    div.hide();			
		}, 5000)
		});
}).fail(function(xhr, ts, sc){
var msg = "Sorry, your request could not be completed. \n\nPlease try again.";
$.load.notification({msg:msg},function(c){
		setTimeout(function(){
		c.addClass('animated slideOutUp');
	    div.hide();			
		}, 5000)
		});
});
});
};

$.load.SELECT = function(){
Attr($('#search-list'),'set','disabled','disabled');
var _await = 'Please click notification photos to select items. Thank you.';
$.load.notification({msg:_await},function(c){ setTimeout(function(){ c.addClass('animated slideOutUp'); }, 5000); });
$('div#_s_menu_lists:hidden').show('fast')
var _delete = $('button.list-action.delete');
var _unSelectAll = $('button.list-action.UnSelectAll');
var _selectAll = $('button.list-action.selectAll');
var _unSelectAlltxt = _unSelectAll.text();
var _setAsRead = $('button.list-action.setAsRead');
var _setAsUnread = $('button.list-action.setAsUnread');
var _actionBtn = $('button.list-action');
Attr(_actionBtn,'set','disabled','disabled');
Attr(_selectAll,'remove','disabled');
var lists = $('div#n_console');
var lists_count = lists.length;
var lists_id = lists.data('notid');
var checked_lists = [];
lists.data('checked',0);
var lists_bg = lists.css('background');
lists.css({borderLeft:'2px solid red'});

lists.on('click', function(e){
var _this = $(this);
if(_this.data('checked') == 0){
_this.css('background','red');
_this.data('checked',1);
checked_lists.push(_this.data('notid'));
}else{
_this.css('background',lists_bg);
_this.data('checked',0);
checked_lists = removeItemOnce(checked_lists,_this.data('notid'));
}
$('span#list-counter').text(checked_lists.length);
if(checked_lists.length > 0){
Attr(_actionBtn,'remove','disabled','disabled');
if(checked_lists.length > 1){
_unSelectAll.text('Unselect All')
}else{
_unSelectAll.text(_unSelectAlltxt);
}
}else{
Attr(_actionBtn,'set','disabled','disabled');
}

e.preventDefault();
e.target.off();
});

/* SELECT ALL ITEMS */
_selectAll.on('click',function(e){
selectAll(lists,checked_lists);
Attr(_actionBtn,'remove','disabled');
e.preventDefault();
});



/* UNSELECT ALL ITEMS */
_unSelectAll.on('click',function(e){
unselectAll(lists,checked_lists,lists_bg);
Attr(_actionBtn,'set','disabled','disabled');
e.preventDefault();
});


/* SET_AS_READ FOR SELECTED  ITEMS */
_setAsRead.on('click',function(e){
SET_AS_READ(lists, checked_lists);
Attr(_actionBtn,'set','disabled','disabled');
e.preventDefault();
});


/* SET_AS_UNREAD FOR SELECTED  ITEMS */
_setAsUnread.on('click',function(e){
SET_AS_UNREAD(lists, checked_lists);
Attr(_actionBtn,'set','disabled','disabled');
e.preventDefault();
});



/* DELETE SELECTED ITEMS*/
_delete.on('click',function(e){
var params = {};
params.title = 'Delete!';
params.text = 'You are about to delete '+checked_lists.length+' items. Continue?';
params.action_btn_text = "Delete";
$.load.alert(params,function(callback){

$.ajax({
url:$.load.server(),
type:'get',
dataType:'json',
data:{request:'deleteNotification',data:checked_lists},
success:function(data){
if(data.DELETED){
for(var i = 0; i < data.code.length; i++){
$('div.label_'+data.code[i]).addClass('animated slideOutRight faster');
$('div.label_'+data.code[i]).on('animationend', function(){
_unSelectAll.text(_unSelectAlltxt);
$(this).remove();
});
}
checked_lists.splice(0,checked_lists.length);
$('span#list-counter').text(checked_lists.length);
Attr(_actionBtn,'set','disabled','disabled');
_unSelectAll.text(_unSelectAlltxt);
}else{
var _await = 'Unable to delete Notifications. Please retry again.';
$.load.notification({msg:_await},function(c){
		setTimeout(function(){
		c.addClass('animated slideOutUp');
	    div.hide();			
		}, 5000)
		});
}
},
error:function(xhr,t,s){
//alert(xhr.t+xhr.s)
}
});


});

e.preventDefault();
});


$('#list-action-toggler').click(function(){
lists.css({borderLeft:'none',background:lists_bg});
checked_lists.splice(0,checked_lists.length);
$('span#list-counter').text(checked_lists.length);
$(this).parent().hide('fast');
Attr($('#search-list'),'remove','disabled');
_unSelectAll.text(_unSelectAlltxt);
lists.off();
});

}

/* SET AS UNREAD FOR SELECTED ITEMS */
function SET_AS_UNREAD(el, items){
var bank = items;
$.getJSON($.load.server(),{request:'setAsUnread',data:bank})
.done(function(data){
if(data.UNREAD){
for(var i = 0; i < data.code.length; i++){
$('div.label_'+data.code[i]).css({background:'rgba(0,200,200,.09)'});
}
bank.splice(0,bank.length);
el.data('checked',0);
$('span#list-counter').text(bank.length);
}else{
var _await = 'Unable to execute command. Please retry again.';
$.load.notification({msg:_await},function(c){
		setTimeout(function(){
		c.addClass('animated slideOutUp');
	    div.hide();			
		}, 5000)
		});
}
})
.fail(function(error){
//alert(error)
});
return bank;
}


/* SET AS READ FOR SELECTED ITEMS */
function SET_AS_READ(el, items){
var bank = items;
$.getJSON($.load.server(),{request:'setAsRead',data:bank})
.done(function(data){
if(data.READ){
for(var i = 0; i < data.code.length; i++){
$('div.label_'+data.code[i]).css({background:'white'});
}
el.data('checked',0);
bank.splice(0,bank.length);
$('span#list-counter').text(bank.length);
}else{
var _await = 'Unable to execute command. Please retry again.';
$.load.notification({msg:_await},function(c){
		setTimeout(function(){
		c.addClass('animated slideOutUp');
	    div.hide();			
		}, 5000)
		});
}
})
.fail(function(error){
//alert(error)
});
return bank;
}

function removeItemOnce(arr, value) { 
    var index = arr.indexOf(value);
    if (index > -1) {
        arr.splice(index, 1);
    }
    return arr;
}

function selectAll(el,bank){
this.el = el;
this.bank = bank;
this.bank.splice(0,this.bank.length);
for(var i = 0; i < this.el.length; i++){
this.el_code = this.el[i].data('notid');
this.bank.push(this.el_code);
}
this.el.data('checked',1);
this.el.css({background:'red'});
$('span#list-counter').text(this.bank.length);
return this.bank;
}

function unselectAll(el,bank,state){
this.el = el;
this.bank = bank;
this.state = state;
this.bank.splice(0,this.bank.length);
this.el.data('checked',0);
this.el.css({background:this.state});
$('span#list-counter').text(this.bank.length);
return this.bank;
}

function Attr(el,action,name,val){
this.el = el;
this.action = action;
this.name = name;
this.val = val;
if(this.action == 'remove' && this.el.is(':disabled')){
this.val = null;
this.el.removeAttr(this.name);
}
if(this.action == 'set'){
this.el.attr(this.name,this.val);
}
return this.el;
}


$.load.LoadModal = function(modal_object){
if(modal_object == null){
var params = [
{title:"Delete",href:href,fa:"<i style='background:#eee;padding:10px;border-radius:50%;' class='fa fa-share'></i>"},
{title:"Flag Inappropriate",href:href,fa:"<i style='background:#eee;padding:10px;border-radius:50%;' class='fa fa-flag'></i>"},
{title:"Disable",href:href,fa:"<i style='background:#eee;padding:10px;border-radius:50%;' class='fa fa-comment'></i>"},
{title:"Truncate",href:href,fa:"<i style='background:#eee;padding:10px;border-radius:50%;' class='fa fa-exclamation-triangle'></i>"},
];
var modal_object = {
href:href,
params:params
};

}
	var commandList = "";
	div = $("<div></div>").css({position:"fixed",display:"flex",flexFlow:"row wrap",alignContent:"flex-end",justifyContent:"flex-end",width:"100%",height:"100%",background:"rgba(0,0,0,.05)",top:"0px",left:"0px",zIndex:"99999"}).addClass("animated fadeInUpBig faster");
	commandBox = $("<div></div>").css({background:"white",position:"relative",width:"100%",height:"auto",padding:"10px"});

	for(var i = 0; i < modal_object.params.length; i++){
	rows = modal_object.params[i];
	
	var isMyList = (rows.isMyList === true || rows.isMyList == undefined)?'block':'none';
	
	var clb_event; //params = {};
	switch(rows.type){
	case 'delete': clb_event = '$.load.deleteTweet($(this))';
	break;
	case 'follow': 
	
	clb_event = '$.load.FOLLOW($(this),null)';
	break;
	case 'unfollow': 
	params = {
	title:'Notification',
	text:'Notification',
	};
	clb_event = '$.load.FOLLOW($(this),null)';
	break;
	case 'updateWallpaper': clb_event = '$.load.updateWallpaper(this)';
	break;
	case 'SELECT': clb_event = '$.load.SELECT(this)';
	break;
	default : clb_event = 'alert()';
	}
	

     commandList += 	'<p style="display:'+isMyList+';" class="hover">'+rows.fa+'<button data-who="'+rows.uid+'" data-type="'+rows.type+'" data-pid="'+rows.pid+'" data-sid="'+rows.sid+'" data-uid="'+rows.uid+'" onclick="'+clb_event+'" class="_list_command_button" data-href="'+rows.href+'">'+rows.title+'</button></p>';
	}
	cancel = $("<button class='_obj_cancel_button hover'>Cancel</button>");
	cancel.on("click",function(){
	div.hide();
	});
	div.on({
	click : function(){
	$(this).hide();
	}
	});	
	commandBox.html(commandList);
	commandBox.append(cancel);
	div.append(commandBox);
	$(document.body).append(div);
};


//Confirmation modal
$.load.confirm = function(object, _return){
	var commandList = "";	
	div = $("<div></div>").css({position:"fixed",display:"flex",flexFlow:"row wrap",alignContent:"flex-end",justifyContent:"flex-end",width:"100%",height:"100%",background:"rgba(0,0,0,.1)",top:"0px",left:"0px",zIndex:"999999"}).addClass("animated fadeInUpBig faster");
	commandBox = $("<div></div>").css({background:"white",position:"relative",width:"100%",height:"auto",padding:"10px"});
    commandList += "<p>"+object.arg+"</p><br><br>";
	yesBtn = $("<button>"+object.text+"</button>").css({width:"50%",padding:"10px",color:"white",background:"rgb(255,0,255)",border:"none",borderRadius:"100px"});
	cancel__ = $("<button>Cancel</button>").css({width:"50%",padding:"10px",background:"#eee",border:"none",borderRadius:"100px"});
    cancel__.on("click",function(){
    div.hide();
     });
	yesBtn.on("click",function(){
		var _await = object.action();
		if(_await){
		    div.hide();
			$.load.notification({msg:_await},function(c){
			setTimeout(function(){
			c.addClass('animated slideOutUp');
		    div.hide();			
			}, 5000)
			});
		}
	});
	commandBox.html(commandList);
    commandBox.append(yesBtn);
	commandBox.append(cancel__);
	div.append(commandBox);
	return div;
};
$.load.loadCommentModal = function(obj){
 var sessImg = obj.sessImg;
var pid = obj.params.pid;
/* var msg = obj.params.msg;*/
var action = obj.params.action;
var isReply = (obj.params.isReply)?true:false;
 var uid = obj.params.uid;
var parent_id = obj.params.parent_id;
var url = "../checkpoint/server.post_content.php";
var inputValName = obj.params.name;
 bgCss = {
background:"transparent",
width:"100%",
height:"100%",
position:"fixed",
top:"0px",
left:"0px",
display:"flex",
flexFlow:"row wrap",
alignContent:"flex-end",
justifyContent:"flex-end",
zIndex:"10"
};
containerCss ={
width:"100%",
height:"auto",
background:"white",
padding:"10px",
margin:"0 auto",
textAlign:"center"
};
consoleCss = {
display:"flex",
flexFlow:"row unwrap",
alignContent:"flex-start",
justifyContent:"flex-start",
width:"100%",
margin:"10px auto",
};
_imgCss = {
width:"35px",
height:"35px",
minHeight:"35px",
minWidth:"35px",
background:"rgb(255,0,255)",
color:"white",
borderRadius:"50%",
border:"none",
margin:"auto 5px",
};
 txtAreaCss = {
width:"100%",
height:"50px !important",
background:"#eee",
borderRadius:"100px",
padding:"10px 20px",
border:"none",
margin:"auto"
};
var bg = $("<div></div>").css(bgCss).addClass("animated slideInUp faster");
var container = $("<div></div>").css(containerCss);
var console = $("<div></div>").css(consoleCss);
var img = $("<img>").css(_imgCss);
img.prop("src", sessImg);
var txtArea = $("<input type='text' name='comment' value='@"+inputValName+"&nbsp; ' placeholder='"+action+"'>").css(txtAreaCss);
var fileInput = $("<input type='file' name='c_att'>").css({display:"none"}); //{fontWeight:"1000",width:"5%",padding:"5px",background:"#eee",border:"none",borderRadius:"50%",margin:"auto 5px auto 5px"});
var inputBtn = $("<button><i class='fa fa-camera'></i></button>").css(_imgCss);
var sendBtn = $("<button><i class='fa fa-paper-plane animated bounceIn'></i></button>").css(_imgCss); //{fontWeight:"1000",width:"5%",padding:"5px",background:"#eee",border:"none",borderRadius:"50%",margin:"auto 5px auto 5px"});
var cancel = $("<button></button>").css({color:"white",fontWeight:"1000",width:"20%",padding:"2px",background:"#eee",boxShadow:"0 1px 2px #aaa",border:"none",borderRadius:"100px"});
txtArea.focus();
console.append(img);
console.append(txtArea);
console.append(fileInput);
console.append(inputBtn);
console.append(sendBtn);
container.append(cancel);
container.append(console);
bg.append(container);
sendBtn.on("click",function(e){

var data = {
storeComment:true,
pid:pid,
uid:uid, //(isReply)?obj.params.replyTo.uid:uid,
comment:txtArea.val(),
isReply:isReply,
parent_id:(obj.params.parent_id == undefined)?"0":obj.params.parent_id
};
txtAreaInnerHtml = sendBtn.html();
$.ajax({
url:url,
type:"post",
dataType:"json",
data:data,
beforeSend:function(){
sendBtn.html("<i class='fa fa-hourglass-half animated bounceIn'></i>");
},
success:function(data){
//alert(data)
sendBtn.html(data.status);
setTimeout(function(){
sendBtn.html(txtAreaInnerHtml);
bg.addClass("animated slideOutDown faster");
}, 4000);
},
error:function(xhr, textStatus){
}
});
});
cancel.on({
click : function(e){
	e.preventDefault();
	bg.addClass("animated slideOutDown faster");
}
});
return bg;
};
 $.load.share = function(data,params){

var obj = data[0];
var _userName_ = obj.userName;
var _fullName_ = obj.fullName;
var _text_ = $.load.reduce_length(obj.text);
var _time_ = obj.time;
var _profilePic_ = obj.profilePic;
var pid = params.pid;
var who = params.who;

var _b_ = $('<div class="animated fadeInUpBig faster"></div>').css({
position:'fixed',
top:'0',
left:'0',
width:'100%',
height:'100%',
backgroundColor:'#FFF',
display:'flex',
flexFlow:'row nowrap',
zIndex:'99',
overflowY:'scroll',
//alignContent:'flex-end',
//justifyContent:'flex-end',
});

var _c_ =$('<div></div>').css({
width:'100%',
height:'auto',
backgroundColor:'#fff',
alignSelf:'flex-start',
padding:'5px',
});

var _ch_ =$("<div></div>").css({
width:'100%',
height:'auto',
display:'flex',
flexFlow:'row nowrap',
position:'relative',
//alignContent:'flex-end',
//justifyContent:'flex-end',
});
var _close_ = $('<button><i class="fa fa-times"></i></button>').css({
width:'auto',
height:'auto',
padding:'10px 15px',
border:'none',
borderRadius:'100px',
margin:'5px auto auto 0',
color:'black',
backgroundColor:'transparent',
fontSize:'large',
fontWeight:'200',
display:'block',
});

var _option_ = $('<button>Share to: <i class="fa fa-angle-down"></i></button>').css({
width:'auto',
height:'auto',
padding:'10px 15px',
border:'none',
borderRadius:'100px',
margin:'5px 0 auto auto',
color:'#08A8B8',
backgroundColor:'transparent',
fontSize:'medium',
fontWeight:'400',
});

var _option_list_cont_ =$('<div class="__list_container"></div>').css({
position:'absolute',
top:'40px',
right:'5px',
backgroundColor:'#fff',
borderRadius:'10px',
boxShadow:'0 5px 10px #aaa',
width:'auto',
minWidth:'200px',
height:'auto',
padding:'5px',
display:'block',
}).hide();

var _option_lists1_ = $('<p class="share_option __list"><label for="public_list">Public <small>Default</small></label><input type="radio" name="share_list" id="public_list" value="public" checked="checked"></p>');
var _option_lists2_ = $('<p class="share_option __list"><label for="friend_list">Friends </label><input type="radio" name="share_list" id="friend_list" value="friend"></p>');
var _option_lists3_ = $('<p class="share_option __list"><label for="other_list">Friends except: </label><input type="radio" name="share_list" id="other_list" value="others"></p>');
var _option_lists4_ = $('<div></div>');
var _uc_ =$('<div></div>').css({
width:'100%',
height:'auto',
alignSelf:'flex-start',
padding:'5px',
display:'flex',
flexFlow:'row nowrap',
alignContent:'flex-start',
justifyContent:'flex-start',
margin:'auto',
});
var _ucl_ =$('<div></div>').css({
width:'40px',
height:'40px',
minWidth:'40px',
minHeight:'40px',
borderRadius:'50%',
backgroundColor:'#eee',
backgroundPosition:'center',
backgroundRepeat:'no-repeat',
backgroundSize:'cover',
backgroundImage:'url("../uploads/profile/'+obj.profilePic+'")',
alignSelf:'flex-start',
margin:'5px auto',
border:'1px solid rgba(0,0,200,.05)',
});
var _ucr_ = $('<div><h2 style="max-width:250px;color:#aaa;font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><span style="color:#000;font-weight:700;">'+_fullName_+'</span> • @'+_userName_+' • '+_time_+' </span></h2><p style="font-size:medium;font-weight:400;">'+$.load.urlify(_text_)+'</p></div>').css({
width:'100%',
maxWidth:'80%',
height:'auto',
textOverflow:'ellipsis',
overflowX:'hidden',
alignSelf:'flex-start',
//border:'1px solid #aaa',
borderRadius:'10px',
padding:'5px',
wordBreak:'break-word',
textOverflow:'break-word',
});

var _textarea_ = $('<textarea id="share_textarea" placeholder="What\'s your opinion?"></textarea>').css({
width:'95%',
minHeight:'150px',
cols:'10',
rows:'30',
padding:'10px',
fontSize:'large',
fontFamily:'sans-serif',
borderRadius:'10px',
color:'black',
border:'2px solid rgba(0,0,200,.05)',
backgroundColor:'#FFF',
display:'block',
margin:'10% auto',
});

var _send_ = $('<button>Share &nbsp; <i class="fa fa-arrow-right"></i></button>').css({
width:'100%',
height:'auto',
padding:'10px',
border:'none',
borderRadius:'100px',
backgroundColor:'#08A8B8',
margin:'10px auto',
color:'white',
fontSize:'medium',
fontWeight:'400',
alignSelf:'flex-end',
});

_ch_.append(_close_);
_ch_.append(_option_);
_ch_.append(_option_list_cont_);
_option_list_cont_.append(_option_lists1_);
_option_list_cont_.append(_option_lists2_);
_option_list_cont_.append(_option_lists3_);
_option_list_cont_.append(_option_lists4_);
_c_.append(_ch_);
_uc_.append(_ucl_);
_uc_.append(_ucr_);
_c_.append(_uc_);
_c_.append(_textarea_);
_c_.append(_send_);
_b_.append(_c_);


var f_lists = '';

$('body').on('change','input[type=radio]',function(){
if($(this).val() == 'others'){
f_lists += '<br><br><p class="warning">These friends will not see this post.<p>';
f_lists += '<select class="show_lists" multiple>';
for(var i=0; i < 20; ++i){      
f_lists += '<option value="1">Friend '+i+'</option>';
}
f_lists += '</select>';
_option_lists4_.html($(f_lists));
}else{
_option_lists4_.empty();
f_lists = "";
}
});

_option_.on('click',function(){
if(_option_list_cont_.is(':hidden')){
_option_list_cont_.show('fast');
$(this).html('Share to: <i class="fa fa-angle-up"></i>');
}else{
_option_list_cont_.hide('fast');
$(this).html('Share to: <i class="fa fa-angle-down"></i>');
}
});
_close_.on('click',function(){
_b_.addClass('animated fadeOutDownBig faster').empty();
});

_send_.on('click',function(){
//alert("shared")
//return false;
$.ajax({
url: "./checkpoint/server.post_content.php",
type: "post",
dataType: "json",
data: {actionOnPost:"shared",pid:pid,msg:_textarea_.val().trim(),who:who},
success: function(data){
_textarea_.val('');
$.load.notification(data,function(c){
setTimeout(function(){
c.addClass('animated slideOutUp');
}, 3000)
});
},
error: function(error){
$.load.notification({msg:'Post could not be shared. Please try again.'},function(c){
setTimeout(function(){
c.addClass('animated slideOutUp');
}, 3000)
});
}
});
});

$(document.body).append(_b_);
};

/* Image preview in content creation Page*/
//uploadPreview("input[name=attachment]", null);
/* assists to click file upload button*/
uploadPost(".file-input-btn", ".file-input-input");
/* word count in content creation page*/
wordCount(".post-box", ".word-counter");
$(".card-body .card_post_photo_container>img").on("dblclick", function(event){
var element = $(this); //$(".card-body>img");
add_animation(element, 'bounceIn', ()=>{
like_system(element);
});
});
$("button i").click(function(event){
event.preventDefault();
var btn = $(this);
var btnName = btn.attr("class").replace("fa", "").trim();
var animationName;
switch(btnName){
case "fa-thumbs-up": animationName = "bounceOut";
break;
case "fa-share": animationName = "bounceIn";
default: animationName = "bounceIn";
}
add_animation(btn, animationName, function(){
like_share_comment(btn);
reply_system(btn);
like_system(btn);
submit_comment();
btn.on("animationend", function (){
btn.removeClass("animated bounceIn faster");
});
});
});
function reply_system(replyBtn){
if(replyBtn.attr("class").replace("fa", "").trim() == "fa-reply"){
var userId = replyBtn.parent().val(); //parent().next().prop("value"));
var replyTo = $("form[name='comment_form']").children(":nth-child(1)");
var textArea = $("form[name='comment_form']").children(":nth-child(2)");
var pre = "<Replying to Frank> ";
replyTo.val(userId);
textArea.focus();
textArea.val(pre);
return replyTo.val();
}}
function like_system(actionBtn){
var targetBtn = actionBtn.parent().parent().find("button[name='like_post']");
if(targetBtn != "undefined"){
like_share_comment(targetBtn.children(":first-child"));
}
}
$.load.animate = function(element, animationName, callback){
element.addClass("animated "+animationName+" faster");
function removeEvent(){
element.removeClass("animated "+animationName+" faster");
element.off("animationend", removeEvent);
callback();
}
element.on("animationend", removeEvent);
}
function like_share_comment(fa){
var color, className;
if((fa.attr("class").replace("fa ", "")) !== "undefined") {
className = fa.attr("class").replace("fa ", "");
if(className == "fa-heart"){
color = "rgb(255,0,0)";
}
if(className == "fa-share"){
color = "rgb(0,255,0)";
}
if(className == "fa-comments"){
color = "rgb(0,0,255)";
}
if(className == "fa-thumbs-up"){
color = "rgb(255,0,255)";
}
fa.css({color:color});
}
}
// Load more content when user scrolls down the page
$(window).scroll(function() {
  if($(window).scrollTop() + $(window).height() >= $(document).height()){
    var last_of_page_txt = $("#last_of_page");
    var text = last_of_page_txt.text();
    last_of_page_txt.text("Loading more content...");
  $.post("./checkpoint/server.post_content.php",{moreFeeds:true}, (data)=>{
    	var container =	$(document.body).find(".parent-container").append(data);
    		 last_of_page_txt.text(text);
  });
  }
});
/* Upload function*/
function uploadPost(button, fileInput){
$(button).on("click",(e)=>{
e.preventDefault();
$(fileInput).click();
});
}
var wordCount_ = 0;
var maxWordCount = 250;
var extra = 0;
var formData = new FormData(); 
function wordCount(textContainer, indicator){
$(textContainer).on("keyup",()=>{
extra += 2;
var fontSize = $(textContainer).css("fontSize").replace("px", '');
var textCount = $(textContainer).val().length;
if(textCount >= maxWordCount){
$(indicator).css({color:"red"});
}else if(textCount <= maxWordCount){
$(indicator).css({color:""});
}
if(textCount > 100 && textCount < 120){
$(textContainer).css({fontSize: (fontSize - ((fontSize / 100) * 2))+"px"});
}
if(textCount > 160 && textCount < 180){
$(textContainer).css({fontSize: (fontSize - ((fontSize / 100) * 2))+"px"});
}
wordCount_ = textCount;
extra = maxWordCount - wordCount_;
extra = (extra > 0)?0:extra;
$(indicator).html(textCount+"/250("+extra+")");
});
}
/*var fileSize = [];
function getFile(file){
$(file).change(function () {
        var imgPath = this.value;
        var ext = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
        if (ext == "gif" || ext == "png" || ext == "jpg" || ext == "jpeg" || ext == "mp4")
          return  readURL(this, ext);
        else
            alert("Please select image file (jpg, jpeg, png).")
    });
    function readURL(input, ext) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.readAsDataURL(input.files[0]);
            reader.onload = function (e) {
            fileSize.push(e.target.result);
            formData.append("post_files[]", input.files[0]);
            if(ext == "mp4"){
            $(".upload-preview-box").prepend('<video width="100" height="100" class="animated bounceInLeft" controls><source src="'+e.target.result+'" type="video/mp4"><video>');
            }else{
             $('.upload-preview-box').prepend("<img src='"+e.target.result+"' width='100' class='animated bounceInLeft' height='100' style='border-radius:5px;margin:auto 5px;'>");
            }
           };
        }
    }
}*/
//getFile("input[type='file'][multiple]");
$("form[name='postForm']").on("submit", function(e){
e.preventDefault();
var form = $(this);
var formBtn = $(this).children(":last-child");
var text_ = $("textarea[name='post-content']");
var text = text_.val();
if(wordCount_ >= maxWordCount) return false, alert("NB: 250 characters exceeded!");
formData.append("content", text);
formData.append("createFeeds", true);
if((text == "") && (fileSize.length < 1)){
$(document.body).css({background:"rgba(255,0,0,.05)"});
setTimeout(function(){
$(document.body).css({background:""});
}, 1000);
return false;
}
if(fileSize.length > 4){
alert("Maximum of 4 files is allowed. Please adjust and try again.");
return false;
}
var fBtnHtml = formBtn.html();
$.ajax({
url:"../checkpoint/server.post_content.php",
type:"POST",
dataType:"json",
contentType:false,
cache:false,
processData:false,
beforeSend: function(){
formBtn.html("<i class='fa fa-hourglass-half animated bounceInUp faster'></i>");
formBtn.attr("disabled", "disabled");
},
data: formData,
success:function(data){
//alert(data)
if(data.status){
formBtn.html("<i class='fa fa-check animated bounceInUp faster'><br>Done!</i>");
text_.val("");
}else{
formBtn.html("<i style='color:red;font-size:10px;' class='fa fa-hourglass-half animated bounceInUp faster'><br>Failed!</i>");
}
setTimeout(function(){
formBtn.html(fBtnHtml);
formBtn.removeAttr("disabled");
}, 5000);
},
error:function(jxHQR, textStatus){
//alert(textStatus);
formBtn.html("<i class='fa fa-check animated bounceInUp faster'><br>Done!</i>");
setTimeout(function(){
formBtn.html(fBtnHtml);
formBtn.removeAttr("disabled");
}, 5000);
}
});
});

/*
*Load page into div in profile.html
*/
function getPageIntoContainer(btn, feedContainer){
$(btn).on("click", function(event){
event.preventDefault();
var _btn = $(this); 
var pid = $(this).attr("href").replace("./","");
loadFeeds({feeds:pid, page:"profilePage"}, function(data){
$(feedContainer).html(data);
});
});
}


/*$.cergis = $.cergis || {};
$.cergis.loadContent = function () {
    $.ajax({
        url: pageUrl.attr("href"),
        success: function (data) {
            if(pageUrl.attr("name") == "menu"){
            $(".main-container").html(data);
            } else{
           $(document.body).html(data);
		     }
        }
    });
    if (pageUrl.attr("href") != window.location) {
        window.history.pushState({ path: pageUrl.attr("href") }, '', pageUrl.attr("href"));
    }
}
$.cergis.backForwardButtons = function () {
    $(window).on('popstate', function () {
        $.ajax({
            url: location.pathname,
            success: function (data) {
               if(pageUrl.attr("name") == "menu"){
               $(".main-container").html(data);
               } else{
             		$(document.body).html(data);
	             }
	          }
        });
    });
}*/
/*$("a").on('click', function (e) {
    pageUrl = $(this); //.attr('href');
    $.cergis.loadContent();
    e.preventDefault();
});
$.cergis.backForwardButtons();
*/


/*$.realMeet = $.realMeet || {};
$.realMeet.loadContent = function () {
         $("homepage-container").load(pageUrl.data("href"));
	 $.ajax({
        url: pageUrl.data("href"),
        success: function (data) {
        //alert(data)
          //  if(pageUrl.data("name") == "menu"){
       //     $(".main-container").html(data);
            //} else{
          //  $(document.body).html(data);
         $("div#homepage").html(data);
		// }
        }
    });
    if (pageUrl.data("href") != window.location) {
        window.history.pushState({ path: pageUrl.data("href") }, '', pageUrl.data("href"));
    }
}
*/

/*$("button").on("click",function(event){
 pageUrl = $(this);
   // alert(pageUrl.data("href")) 
   $.realMeet.loadContent();
   // event.preventDefault();
});

$.realMeet.backForwardButtons = function () {
    $(window).on('popstate', function () {
        $.ajax({
            url: location.pathname,      
            success: function (data) {
              $("div#homepage").html(data);
            }
        });
    });
}
$.realMeet.backForwardButtons();
*/
/****/

/*
*Load user Post to home.html
*/
loadFeeds({feeds:"userPosts", page:"publicPage"}, function(data){
$(".parent-container").append(data);
});
/****/

function loadFeeds(data, callback){
if(typeof data === "object" && typeof callback === "function"){
$.ajax({
url:"./checkpoint/server.post_content.php",
data:data,
type:"post",
timeout:"1000",
success:function(data){
callback(data);
//return data;
 },
error:function(xhr, textStatus){
//console.log(xhr.textStatus);
 }
});
}
}

loadFeeds({feeds:"./feeds.php", page:"profilePage"}, function(data){$(".main-container").html(data); });

/*
* Proceed button in register page.
*/

var no = 0;
function proceedToNext(proceedBtn){
$(proceedBtn).click((e)=>{
//alert($(proceedBtn).html());
//++no;
e.preventDefault();
var formContainer = $(proceedBtn).prev();
var form = formContainer.children(":nth-child(2)"); // find("select");
var formName = form.attr("name");
var formValue = form.val();
if(formValue == ""){
form.css({
border:"0.5px solid red",
background:"rgba(255,0,0,0.2)"
});
return false;
}else{
form.css({
border:"",
background:""
});
++no;
}
$.ajax({
url:"../checkpoint/server.post_content.php",
type:"post",
dataType:"json",
data: {nextPage:"nextPage", address:no+".php", formName:formName, formValue:formValue},
success: (data)=>{
//alert(data); 
if(data.data !== false){
formContainer.html(data.nextPage);
}else{
$.ajax({
url:"../checkpoint/server.post_content.php",
type: "post",
dataType:"json",
data: {nextPage:"dataValidation"},
success: (data)=>{ 
$(document.body).html(data.status); //data.status);
},
error:(xhr, textStatus)=>{
//$(document.body).html("An error has occurred: "+textStatus+". Please <b><a href='../register.html'>try again.</a></b>");
}
});
}
},
error:function(xhr, textStatus, errorCode){
//alert("An error has occurred: "+textStatus+": "+errorCode);
}
 });
});
}

proceedToNext("button[name='proceed']");



$("button").on("click",function(event){
//alert($("#homepage-container").html())
 pageUrl = $(this);
 $("button").removeClass("_taskbar_active");
 $(this).addClass("_taskbar_active");
  
   // alert(pageUrl.data("href")) 
   $.realMeet.loadContent();
  // if($(this).hasClass("_taskbar_active")){
   // }
   // event.preventDefault();
});


$.realMeet = $.realMeet || {};
$.realMeet.loadContent = function () {
	_this = $(this); 
	 $.ajax({
        url: pageUrl.data("href"),
        timeout : 5000,
        beforeSend:function(){
          $("#_body_").html(showLoader());
        },
         success: function (data) {
          $("#_body_").html(data); 
         
        },
        error: function(){
        $("#_body_").html($.load.reload());
        }
        
    });
    if (pageUrl.data("href") != window.location) {
        window.history.pushState({ path: pageUrl.data("href") }, pageUrl.data('title'), pageUrl.data("href"));
    }
}

$.realMeet.backForwardButtons = function () {
    $(window).on('popstate', function () {
        $.ajax({
            url: location.pathname, 
            timeout:5000, 
            beforeSend:function(){
            $("#_body_").html(showLoader());
            },
            success: function (data) {
            $("#_body_").html(data);
            },
            error: function(){
            $("#_body_").html($.load.reload());
            }
        });
    });
}
$.realMeet.backForwardButtons();



function showLoader(){
var _node = '<div class="modal loader" >';
 _node += '<div class="loader-console" >';
 _node += '<div class="outer" >';
 _node += '<div class="inner" ></div>';
 _node += '</div></div></div>';
return _node;
}


});