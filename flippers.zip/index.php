<?php

include "./header.php";
/*include_once "./includes/Handler.class.php";
$main = new Maintenance($_SESSION["id"]);
*/
$isLoggedin = (isset($_SESSION['id']) && array_key_exists('id',$_SESSION))?1:0;
?>


<input name="session" type="hidden" value="<?php echo $isLoggedin; ?>" id="session">


<script src="https://rawgit.com/mervick/emojionearea/master/dist/emojionearea.js"></script>
<script src="./script/jquery.js"></script>
<script src="./script/Handler.Java.js"></script>
<script src="./script/main.min.js"></script>

<script type="text/javascript">

$(document).ready(function(){
var isset_session = $('input#session').val();

$.load.delay(function(modal){
if(isset_session == 1){
location.href = '../ng/main?from=main;v='+isset_session;
}else{
location.href = '../signin?from=main;v='+isset_session;
}
modal.addClass('animated fadeOut faster');
});


});



</script>