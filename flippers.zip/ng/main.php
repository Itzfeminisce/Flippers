<?php 
session_start();
include "../header.php";
include_once "../includes/Handler.class.php";
$main = new Maintenance($_SESSION["id"]);
$sessPic = $main->data->profilePic;



/*if(isset($_GET["loadNewNotification"])){
$sessionId = $_SESSION["id"];
$data = [];*/
$data = [];
$sql = $main->con->query("select activity.*, 
					biodata.uid,
					 biodata.userName,
					biodata.profilePic, biodata.fullName,
					DATE_FORMAT(activity.time, '%a, %D %h:%i') as time 
					from activity join biodata 
					on activity.uid=biodata.uid
					where activity.sid='".$main->data->uid."' 
					or activity.uid='".$main->data->uid."' 
					order by activity.time desc limit 3");

if($sql->num_rows > 0){
while($rows = $sql->fetch_object()){


$arg1 = $main->con->query("SELECT uid FROM activity WHERE sid=".$main->data->uid." AND action='following' LIMIT 1");
$arg2 = $main->con->query("SELECT sid FROM activity WHERE uid=".$arg1->fetch_object()->sid." AND action='following' LIMIT 1");

//$arg3 = $arg1+$arg2;
if($arg2->num_rows > 0){
$rows->msg = "You and ". $main->search("userName", $arg2->fetch_object()->uid)." started following each other";
$rows->action = "eachOther";
}
$pid = $main->con->query("SELECT * FROM feeds WHERE pid=".$rows->pid)->fetch_object(); //$Main->getActions($rows->pid, "uid", "pid", "liked");
$commentObj = $main->con->query("SELECT * FROM comments WHERE (uid=".$_SESSION["id"]." AND pid=".$rows->pid.") OR (sid=".$_SESSION["id"]." AND pid=".$rows->pid.")")->fetch_object(); //$Main->getActions($rows->pid, "uid", "pid", "liked");
$fid = $main->con->query("SELECT fullName, profilePic FROM biodata WHERE uid=".$rows->sid)->fetch_object(); //$Main->getActions($rows->pid, "uid", "pid", "liked");
$rows->parent_comment = $main->con->query("SELECT comment_text FROM comments WHERE id=".$rows->parent_id)->fetch_object()->comment_text;
$rows->postPic = $pid->tmp_pic;
$rows->postText = $pid->text;
$rows->comment = $commentObj->comment_text;
$rows->ccidfn = $commentObj->id;
$rows->ssidfn = $commentObj->sid;
$rows->ddfn = $commentObj->date;
$rows->fidName = $fid->fullName;
$rows->fidPic = $fid->profilePic;
array_push($data, $rows);
}
}
/*else{
array_push($data);
}
echo json_encode($data);
}*/
//print_r($data)
switch($data[0]->action){
case 'liked': $action = 'liked your posts.';
break;
case 'following': $action = 'started following you.';
break;
case 'shared': $action = 'shared your post.';
break;
default : $action =  'are talking about you.';
}
?>
<style type="text/css">


.__refresh_btn {
display:block;
padding:10px;
width:auto;
border:none;
border-radius:5px;
background-color:#08a8b8;
color:white;
text-align:center;
margin:25% auto;
}
._h1{
font-size:large;
color:#08A8B8;
text-align:center;
margin-top:15%;
font-family:sans-serif;
font-weight:400;
}
.showNot {
width:80%;
background-color:;
padding:20px 10px;
display:flex;
flex-flow:row nowrap;
justify-content:center;
align-items:center;
margin:15% auto;
text-align:center;
}
.showNot p{
padding:0 5px;
color:;
font-size:small;
font-weight:400;
font-family:sans-serif;
}
.notPic {
width:30px;
height:30px;
border-radius:50%;
background-color:#aaa;
margin-left:-10px;
border:1px solid #fff;
background-size:100%;
background-repeat:no-repeat;
background-position:center;
}
.img_cont {
display:flex;
flex-flow:row nowrap;
justify-content:center;
align-items:center;
max-width:100px;
}

</style>



<div id="_moment_container_" class="_white_bg" ></div>
<div class="_body_" id="_body_"  >
<img class="siteIcon" src="../icons/flip-eagle.png" >
<style type="text/css">
._header_ {
background-color:;
color:;
}
body {
background:white;
}

</style>

<h1 class="_h1">A lot has been going on @<?php echo $main->data->userName; ?></h1>
<br>
<center><p id="___z"  style="color:red;"></p></center>
<div id="fbbb" ></div>
<div class="showNot" >
<div class="img_cont" >
<div style="background-image:url('../uploads/profile/<?php echo $data[1]->fidPic; ?>');" class="notPic" ></div>
<div style="background-image:url('../uploads/profile/<?php echo $data[2]->fidPic; ?>');" class="notPic" ></div>
<div style="background-image:url('../uploads/profile/<?php echo $data[0]->fidPic; ?>');" class="notPic" ></div>
</div>
<p><span style="font-weight:1000;" ><?php echo $data[0]->fidName; ?></span> and many others <?php echo $action; ?></p>
</div>
<button class="__refresh_btn" ><i class="fa fa-spinner" ></i> Load feeds now!</button>
</div>





<div style="visibility:hidden;" class="_taskbar_" >
<button id="uniqIdHome" class="_taskbar_active" data-title="Home" data-destination="home" data-href="../home" >
<i class="fa fa-home" ></i>
</button>
<button class="" data-title="Explore" data-destination="home" data-href="../explore" >
<i class="fa fa-search" ></i>
</button>
<button name="create" class="" data-title="Create" data-destination="create" data-href="../create" >
<i class="fa fa-plus" ></i>
</button>
<button style="display:none;" class="" data-title="Notification" data-destination="notification" data-href="../notification" ><i class="fa fa-heart" ></i></button>
<button name="chats"  class="" data-title="Chats" data-destination="chats" data-href="../chats" ><i class="fa fa-envelope" ></i><span id="MsgCount"  class="notifier" ></span></button>
<button style="background-image:url('../uploads/profile/<?php echo $sessPic; ?>');" class="" data-title="Profile" data-destination="profile" data-href="../p/<?php echo $main->data->userName; ?>" ></button>
</div>
</div>
</div>



<script src="https://rawgit.com/mervick/emojionearea/master/dist/emojionearea.js"></script>
<script src="../script/jquery.js"></script>
<script src="../script/Handler.Java.js"></script>
<script src="../script/main.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {


$.load.getUnreadNotification(function(count){
var _s = '';
if(count.unreadNot > 1 || count.unreadMsg > 1){
_s = 's';
}
if(count.unreadNot > 0) $('#___z').html("You have "+count.unreadNot+" unread notification"+_s+"<br /><br />");
 if(count.unreadMsg > 0) $('#___z').html(function(){
 return $(this).html() + "You have "+count.unreadMsg+" unread message"+_s;
 });
});
setInterval($.load.getUnreadNotification,5000)

$("button.__refresh_btn").click(function(e){
e.preventDefault();
$('div._header_').css({visibility:'visible'});
$('div._taskbar_').css({visibility:'visible'});
$('button#uniqIdHome').click();
$('#notifier-bell').css({visibility:'visible'});
});

    $.getJSON("http://jsonip.com/?callback=?", function (data) {
        //console.log(data);
        //alert(data.ip);
    });
    
});

</script>

</body>
</head>
</html>